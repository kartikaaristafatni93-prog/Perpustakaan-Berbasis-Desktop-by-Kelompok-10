package com.perpustakaan.dao;

import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.model.Petugas;
import com.perpustakaan.utils.PasswordUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PetugasDAO {

    public List<Petugas> getAll() throws SQLException {
        List<Petugas> list = new ArrayList<>();
        String sql = "SELECT * FROM petugas ORDER BY id_petugas DESC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    public Petugas getById(String id) throws SQLException {
        String sql = "SELECT * FROM petugas WHERE id_petugas = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSet(rs);
                }
            }
        }
        return null;
    }

    public List<Petugas> search(String keyword) throws SQLException {
        List<Petugas> list = new ArrayList<>();
        String sql = "SELECT * FROM petugas WHERE id_petugas LIKE ? OR nama_lengkap LIKE ? OR username LIKE ? ORDER BY id_petugas DESC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String param = "%" + keyword + "%";
            ps.setString(1, param);
            ps.setString(2, param);
            ps.setString(3, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    public boolean insert(Petugas p) throws SQLException {
        String hashedPassword = PasswordUtils.hashPassword(p.getPassword());
        String sqlPetugas = "INSERT INTO petugas (id_petugas, nama_lengkap, jenis_kelamin, alamat, no_telepon, username, password, role) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlUser = "INSERT INTO users (username, password, role, id_petugas) VALUES (?, ?, ?, ?) " +
                         "ON DUPLICATE KEY UPDATE password = VALUES(password), role = VALUES(role), id_petugas = VALUES(id_petugas)";

        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(sqlPetugas)) {
                ps.setString(1, p.getIdPetugas());
                ps.setString(2, p.getNamaLengkap());
                ps.setString(3, p.getJenisKelamin());
                ps.setString(4, p.getAlamat());
                ps.setString(5, p.getNoTelepon());
                ps.setString(6, p.getUsername());
                ps.setString(7, hashedPassword);
                ps.setString(8, p.getRole() != null ? p.getRole() : "Petugas");
                ps.executeUpdate();
            }

            try (PreparedStatement psUser = conn.prepareStatement(sqlUser)) {
                psUser.setString(1, p.getUsername());
                psUser.setString(2, hashedPassword);
                psUser.setString(3, p.getRole() != null ? p.getRole() : "Petugas");
                psUser.setString(4, p.getIdPetugas());
                psUser.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    public boolean update(Petugas p, boolean updatePassword) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);

            String sqlPetugas;
            if (updatePassword) {
                sqlPetugas = "UPDATE petugas SET nama_lengkap = ?, jenis_kelamin = ?, alamat = ?, " +
                             "no_telepon = ?, username = ?, password = ?, role = ? WHERE id_petugas = ?";
            } else {
                sqlPetugas = "UPDATE petugas SET nama_lengkap = ?, jenis_kelamin = ?, alamat = ?, " +
                             "no_telepon = ?, username = ?, role = ? WHERE id_petugas = ?";
            }

            String hashedPassword = updatePassword ? PasswordUtils.hashPassword(p.getPassword()) : null;

            try (PreparedStatement ps = conn.prepareStatement(sqlPetugas)) {
                ps.setString(1, p.getNamaLengkap());
                ps.setString(2, p.getJenisKelamin());
                ps.setString(3, p.getAlamat());
                ps.setString(4, p.getNoTelepon());
                ps.setString(5, p.getUsername());
                if (updatePassword) {
                    ps.setString(6, hashedPassword);
                    ps.setString(7, p.getRole() != null ? p.getRole() : "Petugas");
                    ps.setString(8, p.getIdPetugas());
                } else {
                    ps.setString(6, p.getRole() != null ? p.getRole() : "Petugas");
                    ps.setString(7, p.getIdPetugas());
                }
                ps.executeUpdate();
            }

            // Sync user table
            if (updatePassword) {
                String sqlUser = "UPDATE users SET username = ?, password = ?, role = ? WHERE id_petugas = ?";
                try (PreparedStatement psUser = conn.prepareStatement(sqlUser)) {
                    psUser.setString(1, p.getUsername());
                    psUser.setString(2, hashedPassword);
                    psUser.setString(3, p.getRole() != null ? p.getRole() : "Petugas");
                    psUser.setString(4, p.getIdPetugas());
                    psUser.executeUpdate();
                }
            } else {
                String sqlUser = "UPDATE users SET username = ?, role = ? WHERE id_petugas = ?";
                try (PreparedStatement psUser = conn.prepareStatement(sqlUser)) {
                    psUser.setString(1, p.getUsername());
                    psUser.setString(2, p.getRole() != null ? p.getRole() : "Petugas");
                    psUser.setString(3, p.getIdPetugas());
                    psUser.executeUpdate();
                }
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    public boolean delete(String id) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);
            // Delete associated user
            try (PreparedStatement psUser = conn.prepareStatement("DELETE FROM users WHERE id_petugas = ?")) {
                psUser.setString(1, id);
                psUser.executeUpdate();
            }
            // Delete petugas
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM petugas WHERE id_petugas = ?")) {
                ps.setString(1, id);
                ps.executeUpdate();
            }
            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    public String generateNextId() throws SQLException {
        String sql = "SELECT id_petugas FROM petugas WHERE id_petugas LIKE 'PTG-%' ORDER BY id_petugas DESC LIMIT 1";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String lastId = rs.getString("id_petugas");
                try {
                    int num = Integer.parseInt(lastId.substring(4));
                    return String.format("PTG-%03d", num + 1);
                } catch (Exception e) {}
            }
        }
        return "PTG-001";
    }

    private Petugas mapResultSet(ResultSet rs) throws SQLException {
        return new Petugas(
            rs.getString("id_petugas"),
            rs.getString("nama_lengkap"),
            rs.getString("jenis_kelamin"),
            rs.getString("alamat"),
            rs.getString("no_telepon"),
            rs.getString("username"),
            rs.getString("password"),
            rs.getString("role")
        );
    }
}
