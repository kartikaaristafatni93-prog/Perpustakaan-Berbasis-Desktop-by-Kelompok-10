package com.perpustakaan.view.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class ModernButton extends JButton {
    public enum Style {
        PRIMARY, SECONDARY, SUCCESS, DANGER, GHOST
    }

    private Style buttonStyle;
    private Color normalColor;
    private Color hoverColor;
    private Color pressedColor;
    private Color textColor;
    private Color borderColor = null;
    private boolean isHovered = false;
    private boolean isPressed = false;
    private int cornerRadius = 8;

    public ModernButton(String text, Style style) {
        super(text);
        this.buttonStyle = style;
        init();
    }

    public ModernButton(String text, Icon icon, Style style) {
        super(text, icon);
        this.buttonStyle = style;
        init();
    }

    private void init() {
        setOpaque(false);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setFont(UITheme.FONT_BOLD);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setMargin(new Insets(8, 16, 8, 16));

        switch (buttonStyle) {
            case PRIMARY:
                normalColor = UITheme.PRIMARY;
                hoverColor = UITheme.PRIMARY_DARK;
                pressedColor = new Color(0x1E, 0x51, 0xA8);
                textColor = Color.WHITE;
                break;
            case SUCCESS:
                normalColor = UITheme.SUCCESS;
                hoverColor = new Color(0x2E, 0xA5, 0x6B);
                pressedColor = new Color(0x24, 0x8A, 0x58);
                textColor = Color.WHITE;
                break;
            case DANGER:
                normalColor = UITheme.DANGER;
                hoverColor = UITheme.DANGER_HOVER;
                pressedColor = new Color(0xB8, 0x3E, 0x47);
                textColor = Color.WHITE;
                break;
            case GHOST:
                normalColor = new Color(0, 0, 0, 0);
                hoverColor = new Color(0, 0, 0, 10);
                pressedColor = new Color(0, 0, 0, 20);
                textColor = UITheme.TEXT_PRIMARY;
                break;
            case SECONDARY:
            default:
                normalColor = Color.WHITE;
                hoverColor = new Color(0xF4, 0xF6, 0xF9);
                pressedColor = new Color(0xEA, 0xEE, 0xF4);
                textColor = UITheme.TEXT_PRIMARY;
                borderColor = UITheme.BORDER;
                break;
        }
        setForeground(textColor);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isEnabled()) {
                    isHovered = true;
                    repaint();
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (isEnabled()) {
                    isPressed = true;
                    repaint();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                isPressed = false;
                repaint();
            }
        });
    }

    public void setCornerRadius(int r) {
        this.cornerRadius = r;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        Color bg;
        if (!isEnabled()) {
            bg = new Color(0xF1, 0xF5, 0xF9);
            g2.setColor(bg);
            g2.fill(new RoundRectangle2D.Float(0, 0, width, height, cornerRadius, cornerRadius));
            g2.setColor(UITheme.BORDER);
            g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, width - 1, height - 1, cornerRadius, cornerRadius));
            g2.dispose();
            super.paintComponent(g);
            return;
        }

        if (isPressed) {
            bg = pressedColor;
        } else if (isHovered) {
            bg = hoverColor;
        } else {
            bg = normalColor;
        }

        // Fill background
        g2.setColor(bg);
        g2.fill(new RoundRectangle2D.Float(0, 0, width, height, cornerRadius, cornerRadius));

        // Draw border if defined
        if (borderColor != null) {
            g2.setColor(isHovered ? UITheme.PRIMARY : borderColor);
            g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, width - 1, height - 1, cornerRadius, cornerRadius));
        }

        g2.dispose();
        super.paintComponent(g);
    }
}
