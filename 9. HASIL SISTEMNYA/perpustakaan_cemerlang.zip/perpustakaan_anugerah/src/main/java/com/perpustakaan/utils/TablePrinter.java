package com.perpustakaan.utils;

import javax.swing.*;
import java.awt.print.PrinterException;
import java.text.MessageFormat;

public class TablePrinter {

    public static void printTable(JTable table, String reportTitle) {
        try {
            MessageFormat header = new MessageFormat("PERPUSTAKAAN CEMERLANG - " + (reportTitle != null ? reportTitle.toUpperCase() : "LAPORAN"));
            MessageFormat footer = new MessageFormat("- Halaman {0} -");
            
            boolean complete = table.print(
                JTable.PrintMode.FIT_WIDTH,
                header,
                footer,
                true, // show print dialog
                null,
                true  // interactive
            );

            if (complete) {
                JOptionPane.showMessageDialog(null,
                    "Pencetakan berhasil dikirim ke printer.",
                    "Pencetakan Selesai", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(null,
                "Gagal mencetak dokumen:\n" + e.getMessage(),
                "Kesalahan Cetak", JOptionPane.ERROR_MESSAGE);
        }
    }
}
