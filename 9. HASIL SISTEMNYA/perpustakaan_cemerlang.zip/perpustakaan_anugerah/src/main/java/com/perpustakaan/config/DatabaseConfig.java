package com.perpustakaan.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Properties;

public class DatabaseConfig {
    private static final String CONFIG_FILE = "database.properties";
    private static Properties properties = new Properties();

    static {
        loadConfig();
    }

    public static void loadConfig() {
        // Defaults
        properties.setProperty("db.host", "localhost");
        properties.setProperty("db.port", "3306");
        properties.setProperty("db.database", "perpustakaan_anugerah");
        properties.setProperty("db.username", "root");
        properties.setProperty("db.password", "");
        properties.setProperty("db.useSSL", "false");
        properties.setProperty("db.allowPublicKeyRetrieval", "true");
        properties.setProperty("db.serverTimezone", "Asia/Jakarta");

        // Try to load from external file in working dir first
        File extFile = new File(CONFIG_FILE);
        if (extFile.exists()) {
            try (FileInputStream fis = new FileInputStream(extFile)) {
                properties.load(fis);
                return;
            } catch (Exception e) {
                System.err.println("Warning: Could not read external " + CONFIG_FILE + ": " + e.getMessage());
            }
        }

        // Otherwise load from classpath
        try (InputStream is = DatabaseConfig.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (is != null) {
                properties.load(is);
            }
        } catch (Exception e) {
            System.err.println("Warning: Could not read bundled " + CONFIG_FILE + ": " + e.getMessage());
        }
    }

    public static void saveConfig(String host, String port, String dbName, String user, String pass) {
        properties.setProperty("db.host", host);
        properties.setProperty("db.port", port);
        properties.setProperty("db.database", dbName);
        properties.setProperty("db.username", user);
        properties.setProperty("db.password", pass);

        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
            properties.store(fos, "Perpustakaan Cemerlang - Database Settings");
        } catch (Exception e) {
            System.err.println("Error saving " + CONFIG_FILE + ": " + e.getMessage());
        }
    }

    public static String getHost() { return properties.getProperty("db.host", "localhost"); }
    public static String getPort() { return properties.getProperty("db.port", "3306"); }
    public static String getDatabase() { return properties.getProperty("db.database", "perpustakaan_anugerah"); }
    public static String getUsername() { return properties.getProperty("db.username", "root"); }
    public static String getPassword() { return properties.getProperty("db.password", ""); }

    public static String getJdbcUrl() {
        return String.format(
            "jdbc:mysql://%s:%s/%s?useSSL=%s&allowPublicKeyRetrieval=%s&serverTimezone=%s&characterEncoding=UTF-8&autoReconnect=true",
            getHost(),
            getPort(),
            getDatabase(),
            properties.getProperty("db.useSSL", "false"),
            properties.getProperty("db.allowPublicKeyRetrieval", "true"),
            properties.getProperty("db.serverTimezone", "Asia/Jakarta")
        );
    }

    public static String getServerJdbcUrl() {
        return String.format(
            "jdbc:mysql://%s:%s/?useSSL=%s&allowPublicKeyRetrieval=%s&serverTimezone=%s&characterEncoding=UTF-8",
            getHost(),
            getPort(),
            properties.getProperty("db.useSSL", "false"),
            properties.getProperty("db.allowPublicKeyRetrieval", "true"),
            properties.getProperty("db.serverTimezone", "Asia/Jakarta")
        );
    }
}
