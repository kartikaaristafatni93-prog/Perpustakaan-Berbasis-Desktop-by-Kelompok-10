package com.perpustakaan.view;

import com.perpustakaan.model.Anggota;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class EmailNotificationDialog extends JDialog {
    private Anggota anggota;
    private String username;

    public EmailNotificationDialog(Window parent, Anggota anggota, String username) {
        super(parent, "Email Masuk: Pendaftaran Berhasil Bergabung", ModalityType.APPLICATION_MODAL);
        this.anggota = anggota;
        this.username = username;
        setSize(560, 620);
        setLocationRelativeTo(parent);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setBackground(new Color(0xF4, 0xF7, 0xFC));
        content.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Simulated Email Header
        JPanel emailHeader = new JPanel();
        emailHeader.setLayout(new BoxLayout(emailHeader, BoxLayout.Y_AXIS));
        emailHeader.setBackground(Color.WHITE);
        emailHeader.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER, 1),
            new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel lblSubject = new JLabel("📨 Pendaftaran Berhasil: Selamat Bergabung di Perpustakaan Cemerlang!");
        lblSubject.setFont(UITheme.FONT_HEADER);
        lblSubject.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblFrom = new JLabel("Dari: Perpustakaan Cemerlang <sistem@perpustakaancemerlang.id>");
        lblFrom.setFont(UITheme.FONT_SMALL);
        lblFrom.setForeground(UITheme.TEXT_SECONDARY);

        String toEmail = anggota != null && anggota.getEmail() != null ? anggota.getEmail() : "anggota@email.com";
        String toName = anggota != null ? anggota.getNamaLengkap() : "Anggota Baru";
        JLabel lblTo = new JLabel("Kepada: " + toName + " <" + toEmail + ">");
        lblTo.setFont(UITheme.FONT_SMALL);
        lblTo.setForeground(UITheme.TEXT_SECONDARY);

        JLabel lblDate = new JLabel("Waktu: " + DateUtils.formatDisplay(DateUtils.today()));
        lblDate.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblDate.setForeground(UITheme.TEXT_MUTED);

        emailHeader.add(lblSubject);
        emailHeader.add(Box.createVerticalStrut(6));
        emailHeader.add(lblFrom);
        emailHeader.add(Box.createVerticalStrut(3));
        emailHeader.add(lblTo);
        emailHeader.add(Box.createVerticalStrut(3));
        emailHeader.add(lblDate);

        content.add(emailHeader, BorderLayout.NORTH);

        // Email Body Card
        JPanel emailBody = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 12, 12));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        emailBody.setOpaque(false);
        emailBody.setLayout(new BoxLayout(emailBody, BoxLayout.Y_AXIS));
        emailBody.setBorder(new EmptyBorder(20, 24, 20, 24));

        JLabel lblGreeting = new JLabel("Halo, " + toName + "!");
        lblGreeting.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblGreeting.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblIntro = new JLabel("<html>Selamat! Akun keanggotaan Anda di <b>Perpustakaan Cemerlang</b> telah berhasil dibuat dan aktif. Anda sekarang dapat mengakses katalog buku dan meminjam buku koleksi kami.</html>");
        lblIntro.setFont(UITheme.FONT_REGULAR);
        lblIntro.setForeground(UITheme.TEXT_PRIMARY);

        // Detail Table Box
        JPanel detailBox = new JPanel(new GridLayout(6, 2, 8, 8));
        detailBox.setBackground(new Color(0xF8, 0xFA, 0xFC));
        detailBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0xE2, 0xE8, 0xF0), 1),
            new EmptyBorder(12, 16, 12, 16)
        ));

        addDetailRow(detailBox, "ID Anggota:", anggota != null ? anggota.getIdAnggota() : "-");
        addDetailRow(detailBox, "Nama Lengkap:", toName);
        addDetailRow(detailBox, "Username Login:", username != null ? username : "-");
        addDetailRow(detailBox, "Nomor Telepon:", anggota != null && anggota.getNoTelepon() != null ? anggota.getNoTelepon() : "-");
        addDetailRow(detailBox, "Alamat:", anggota != null && anggota.getAlamat() != null ? anggota.getAlamat() : "-");
        addDetailRow(detailBox, "Status Keanggotaan:", "AKTIF (Resmi)");

        JLabel lblNotes = new JLabel("<html><small>Catatan: Simpan ID Anggota dan Username Anda dengan baik. Anda dapat mencetak Kartu Tanda Anggota sekarang untuk dibawa saat berkunjung ke perpustakaan.</small></html>");
        lblNotes.setFont(UITheme.FONT_SMALL);
        lblNotes.setForeground(UITheme.TEXT_MUTED);

        emailBody.add(lblGreeting);
        emailBody.add(Box.createVerticalStrut(10));
        emailBody.add(lblIntro);
        emailBody.add(Box.createVerticalStrut(16));
        emailBody.add(detailBox);
        emailBody.add(Box.createVerticalStrut(14));
        emailBody.add(lblNotes);

        content.add(emailBody, BorderLayout.CENTER);

        // Bottom Actions
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        actionPanel.setOpaque(false);

        ModernButton btnPrintCard = new ModernButton("🖨️ Cetak Kartu Anggota Sekarang", ModernButton.Style.PRIMARY);
        btnPrintCard.setPreferredSize(new Dimension(240, 42));
        btnPrintCard.addActionListener(e -> {
            new MemberCardDialog(this, anggota).setVisible(true);
        });

        ModernButton btnDone = new ModernButton("Lanjut ke Login", ModernButton.Style.SECONDARY);
        btnDone.setPreferredSize(new Dimension(140, 42));
        btnDone.addActionListener(e -> dispose());

        actionPanel.add(btnPrintCard);
        actionPanel.add(btnDone);
        content.add(actionPanel, BorderLayout.SOUTH);

        setContentPane(content);
    }

    private void addDetailRow(JPanel container, String label, String value) {
        JLabel lblL = new JLabel(label);
        lblL.setFont(UITheme.FONT_BOLD);
        lblL.setForeground(UITheme.TEXT_SECONDARY);

        JLabel lblV = new JLabel(value);
        lblV.setFont(UITheme.FONT_REGULAR);
        lblV.setForeground(UITheme.TEXT_PRIMARY);

        container.add(lblL);
        container.add(lblV);
    }
}
