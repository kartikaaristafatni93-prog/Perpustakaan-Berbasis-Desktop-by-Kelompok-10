package com.perpustakaan.dao;

import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.model.Peminjaman;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PeminjamanDAO {

    public List<Peminjaman> getAll() throws SQLException {
        List<Peminjaman> list = new ArrayList<>();
        String sql = "SELECT p.*, a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
                     "FROM peminjaman p " +
                     "JOIN anggota a ON p.id_anggota = a.id_anggota " +
                     "JOIN buku b ON p.id_buku = b.id_buku " +
                     "JOIN petugas pt ON p.id_petugas = pt.id_petugas " +
                     "ORDER BY p.tanggal_pinjam DESC, p.id_peminjaman DESC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    public List<Peminjaman> getActiveBorrowings() throws SQLException {
        List<Peminjaman> list = new ArrayList<>();
        String sql = "SELECT p.*, a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
                     "FROM peminjaman p " +
                     "JOIN anggota a ON p.id_anggota = a.id_anggota " +
                     "JOIN buku b ON p.id_buku = b.id_buku " +
                     "JOIN petugas pt ON p.id_petugas = pt.id_petugas " +
                     "WHERE p.status_peminjaman = 'Dipinjam' " +
                     "ORDER BY p.tanggal_jatuh_tempo ASC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    public Peminjaman getById(String id) throws SQLException {
        String sql = "SELECT p.*, a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
                     "FROM peminjaman p " +
                     "JOIN anggota a ON p.id_anggota = a.id_anggota " +
                     "JOIN buku b ON p.id_buku = b.id_buku " +
                     "JOIN petugas pt ON p.id_petugas = pt.id_petugas " +
                     "WHERE p.id_peminjaman = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSet(rs);
                }
            }
        }
        return null;
    }

    public List<Peminjaman> search(String keyword, String statusFilter) throws SQLException {
        List<Peminjaman> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT p.*, a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
            "FROM peminjaman p " +
            "JOIN anggota a ON p.id_anggota = a.id_anggota " +
            "JOIN buku b ON p.id_buku = b.id_buku " +
            "JOIN petugas pt ON p.id_petugas = pt.id_petugas " +
            "WHERE (p.id_peminjaman LIKE ? OR a.nama_lengkap LIKE ? OR b.judul_buku LIKE ? OR p.tanggal_pinjam LIKE ?) "
        );

        if (statusFilter != null && !statusFilter.equalsIgnoreCase("Semua") && !statusFilter.isEmpty()) {
            sql.append("AND p.status_peminjaman = ? ");
        }
        sql.append("ORDER BY p.tanggal_pinjam DESC, p.id_peminjaman DESC");

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            String param = "%" + keyword + "%";
            ps.setString(1, param);
            ps.setString(2, param);
            ps.setString(3, param);
            ps.setString(4, param);
            if (statusFilter != null && !statusFilter.equalsIgnoreCase("Semua") && !statusFilter.isEmpty()) {
                ps.setString(5, statusFilter);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    /**
     * Atomically creates a borrowing transaction:
     * 1. Checks available stock > 0
     * 2. Decrements available stock by 1
     * 3. Inserts borrowing record
     */
    public boolean insert(Peminjaman p) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);

            // 1. Verify stock and lock book row
            String checkStockSql = "SELECT sisa_stok FROM buku WHERE id_buku = ? FOR UPDATE";
            int availableStock = 0;
            try (PreparedStatement psCheck = conn.prepareStatement(checkStockSql)) {
                psCheck.setString(1, p.getIdBuku());
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next()) {
                        availableStock = rs.getInt("sisa_stok");
                    } else {
                        throw new SQLException("Buku dengan ID " + p.getIdBuku() + " tidak ditemukan!");
                    }
                }
            }

            if (availableStock <= 0) {
                throw new SQLException("Stok buku tidak tersedia! (Sisa stok: 0)");
            }

            // 2. Decrement available stock
            String decStockSql = "UPDATE buku SET sisa_stok = sisa_stok - 1 WHERE id_buku = ? AND sisa_stok > 0";
            try (PreparedStatement psDec = conn.prepareStatement(decStockSql)) {
                psDec.setString(1, p.getIdBuku());
                int rows = psDec.executeUpdate();
                if (rows == 0) {
                    throw new SQLException("Gagal mengurangi stok buku. Stok habis.");
                }
            }

            // 3. Insert transaction
            String insertSql = "INSERT INTO peminjaman (id_peminjaman, id_anggota, id_buku, id_petugas, " +
                               "tanggal_pinjam, tanggal_jatuh_tempo, status_peminjaman) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement psInsert = conn.prepareStatement(insertSql)) {
                psInsert.setString(1, p.getIdPeminjaman());
                psInsert.setString(2, p.getIdAnggota());
                psInsert.setString(3, p.getIdBuku());
                psInsert.setString(4, p.getIdPetugas());
                psInsert.setDate(5, p.getTanggalPinjam());
                psInsert.setDate(6, p.getTanggalJatuhTempo());
                psInsert.setString(7, p.getStatusPeminjaman() != null ? p.getStatusPeminjaman() : "Dipinjam");
                psInsert.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    /**
     * Updates an existing borrowing transaction. If the book was changed, adjusts stock accordingly.
     */
    public boolean update(Peminjaman p) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);

            // Fetch current state
            String oldBookId = null;
            String oldStatus = null;
            try (PreparedStatement psOld = conn.prepareStatement("SELECT id_buku, status_peminjaman FROM peminjaman WHERE id_peminjaman = ? FOR UPDATE")) {
                psOld.setString(1, p.getIdPeminjaman());
                try (ResultSet rs = psOld.executeQuery()) {
                    if (rs.next()) {
                        oldBookId = rs.getString("id_buku");
                        oldStatus = rs.getString("status_peminjaman");
                    } else {
                        throw new SQLException("Transaksi peminjaman tidak ditemukan.");
                    }
                }
            }

            // If book changed and previous status was Dipinjam
            if (oldBookId != null && !oldBookId.equals(p.getIdBuku()) && "Dipinjam".equals(oldStatus)) {
                // Restore old book stock
                try (PreparedStatement psRest = conn.prepareStatement("UPDATE buku SET sisa_stok = sisa_stok + 1 WHERE id_buku = ?")) {
                    psRest.setString(1, oldBookId);
                    psRest.executeUpdate();
                }
                // Decrement new book stock
                try (PreparedStatement psDec = conn.prepareStatement("UPDATE buku SET sisa_stok = sisa_stok - 1 WHERE id_buku = ? AND sisa_stok > 0")) {
                    psDec.setString(1, p.getIdBuku());
                    if (psDec.executeUpdate() == 0) {
                        throw new SQLException("Stok buku pengganti tidak tersedia.");
                    }
                }
            }

            String sql = "UPDATE peminjaman SET id_anggota = ?, id_buku = ?, id_petugas = ?, " +
                         "tanggal_pinjam = ?, tanggal_jatuh_tempo = ?, status_peminjaman = ? WHERE id_peminjaman = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, p.getIdAnggota());
                ps.setString(2, p.getIdBuku());
                ps.setString(3, p.getIdPetugas());
                ps.setDate(4, p.getTanggalPinjam());
                ps.setDate(5, p.getTanggalJatuhTempo());
                ps.setString(6, p.getStatusPeminjaman());
                ps.setString(7, p.getIdPeminjaman());
                ps.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    /**
     * Atomically deletes a borrowing transaction. If it was active ("Dipinjam"), restores book stock.
     */
    public boolean delete(String idPeminjaman) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);

            String bookId = null;
            String status = null;
            try (PreparedStatement psCheck = conn.prepareStatement("SELECT id_buku, status_peminjaman FROM peminjaman WHERE id_peminjaman = ? FOR UPDATE")) {
                psCheck.setString(1, idPeminjaman);
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next()) {
                        bookId = rs.getString("id_buku");
                        status = rs.getString("status_peminjaman");
                    } else {
                        return false;
                    }
                }
            }

            // Also delete any return record if exists
            try (PreparedStatement psDelRet = conn.prepareStatement("DELETE FROM pengembalian WHERE id_peminjaman = ?")) {
                psDelRet.setString(1, idPeminjaman);
                psDelRet.executeUpdate();
            }

            // Delete borrowing
            try (PreparedStatement psDel = conn.prepareStatement("DELETE FROM peminjaman WHERE id_peminjaman = ?")) {
                psDel.setString(1, idPeminjaman);
                psDel.executeUpdate();
            }

            // If it was currently borrowed, return stock back
            if ("Dipinjam".equalsIgnoreCase(status) && bookId != null) {
                try (PreparedStatement psInc = conn.prepareStatement("UPDATE buku SET sisa_stok = sisa_stok + 1 WHERE id_buku = ? AND sisa_stok < total_stok")) {
                    psInc.setString(1, bookId);
                    psInc.executeUpdate();
                }
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    public String generateNextId() throws SQLException {
        String todayStr = new SimpleDateFormat("yyyyMMdd").format(new java.util.Date());
        String prefix = "PJM-" + todayStr + "-";
        String sql = "SELECT id_peminjaman FROM peminjaman WHERE id_peminjaman LIKE ? ORDER BY id_peminjaman DESC LIMIT 1";

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, prefix + "%");
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String lastId = rs.getString("id_peminjaman");
                    try {
                        int num = Integer.parseInt(lastId.substring(prefix.length()));
                        return String.format("%s%04d", prefix, num + 1);
                    } catch (Exception e) {}
                }
            }
        }
        return prefix + "0001";
    }

    private Peminjaman mapResultSet(ResultSet rs) throws SQLException {
        Peminjaman p = new Peminjaman(
            rs.getString("id_peminjaman"),
            rs.getString("id_anggota"),
            rs.getString("id_buku"),
            rs.getString("id_petugas"),
            rs.getDate("tanggal_pinjam"),
            rs.getDate("tanggal_jatuh_tempo"),
            rs.getString("status_peminjaman")
        );
        p.setNamaAnggota(rs.getString("nama_anggota"));
        p.setJudulBuku(rs.getString("judul_buku"));
        p.setNamaPetugas(rs.getString("nama_petugas"));
        return p;
    }
}
