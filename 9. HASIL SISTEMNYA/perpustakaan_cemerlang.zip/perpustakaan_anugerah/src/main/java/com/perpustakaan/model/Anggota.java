package com.perpustakaan.model;

import java.sql.Date;

public class Anggota {
    private String idAnggota;
    private String namaLengkap;
    private String jenisKelamin;
    private String alamat;
    private String noTelepon;
    private String email;
    private Date tanggalDaftar;

    public Anggota() {}

    public Anggota(String idAnggota, String namaLengkap, String jenisKelamin, String alamat,
                   String noTelepon, String email, Date tanggalDaftar) {
        this.idAnggota = idAnggota;
        this.namaLengkap = namaLengkap;
        this.jenisKelamin = jenisKelamin;
        this.alamat = alamat;
        this.noTelepon = noTelepon;
        this.email = email;
        this.tanggalDaftar = tanggalDaftar;
    }

    public String getIdAnggota() { return idAnggota; }
    public void setIdAnggota(String idAnggota) { this.idAnggota = idAnggota; }

    public String getNamaLengkap() { return namaLengkap; }
    public void setNamaLengkap(String namaLengkap) { this.namaLengkap = namaLengkap; }

    public String getJenisKelamin() { return jenisKelamin; }
    public void setJenisKelamin(String jenisKelamin) { this.jenisKelamin = jenisKelamin; }

    public String getAlamat() { return alamat; }
    public void setAlamat(String alamat) { this.alamat = alamat; }

    public String getNoTelepon() { return noTelepon; }
    public void setNoTelepon(String noTelepon) { this.noTelepon = noTelepon; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Date getTanggalDaftar() { return tanggalDaftar; }
    public void setTanggalDaftar(Date tanggalDaftar) { this.tanggalDaftar = tanggalDaftar; }

    @Override
    public String toString() {
        return idAnggota + " - " + namaLengkap;
    }
}
