package com.perpustakaan.dao;

import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.model.DashboardStats;
import com.perpustakaan.model.Peminjaman;
import com.perpustakaan.model.Pengembalian;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DashboardDAO {

    public DashboardStats getStats() throws SQLException {
        DashboardStats stats = new DashboardStats();
        Connection conn = DatabaseConnection.getConnection();

        // 1. Total copies & Active Borrowed copies & Available copies
        // Auto-reconcile book stock with active borrowings to prevent any desynchronization
        try (PreparedStatement psSync = conn.prepareStatement(
                "UPDATE buku b SET sisa_stok = total_stok - (" +
                "SELECT COUNT(*) FROM peminjaman p WHERE p.id_buku = b.id_buku AND p.status_peminjaman = 'Dipinjam')")) {
            psSync.executeUpdate();
        } catch (Exception ignored) {}

        // Total book copies from buku table
        int totalBuku = 0;
        String bookSql = "SELECT COALESCE(SUM(total_stok), 0) AS total_buku FROM buku";
        try (PreparedStatement ps = conn.prepareStatement(bookSql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                totalBuku = rs.getInt("total_buku");
            }
        }

        // Active borrowed count directly from peminjaman
        int dipinjamCount = 0;
        try (PreparedStatement psPjm = conn.prepareStatement(
                "SELECT COUNT(*) FROM peminjaman WHERE status_peminjaman = 'Dipinjam'");
             ResultSet rsPjm = psPjm.executeQuery()) {
            if (rsPjm.next()) {
                dipinjamCount = rsPjm.getInt(1);
            }
        }

        stats.setTotalBuku(totalBuku);
        stats.setBukuDipinjam(dipinjamCount);
        stats.setBukuTersedia(Math.max(0, totalBuku - dipinjamCount));

        // 2. Total members
        try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM anggota");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                stats.setTotalAnggota(rs.getInt(1));
            }
        }

        // 3. Total staff
        try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM petugas");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                stats.setTotalPetugas(rs.getInt(1));
            }
        }

        // 4. Total shelves
        try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM rak");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                stats.setTotalRak(rs.getInt(1));
            }
        }

        // 5. Activity data for chart (past 6 months)
        Map<String, int[]> activity = new LinkedHashMap<>();
        LocalDate now = LocalDate.now();
        DateTimeFormatter monthKeyFormat = DateTimeFormatter.ofPattern("yyyy-MM");
        DateTimeFormatter monthDisplayFormat = DateTimeFormatter.ofPattern("MMM yyyy");

        // Initialize last 6 months with 0s
        for (int i = 5; i >= 0; i--) {
            LocalDate d = now.minusMonths(i);
            activity.put(d.format(monthDisplayFormat), new int[]{0, 0});
        }

        // Monthly borrowings
        String pjmMonthlySql = "SELECT DATE_FORMAT(tanggal_pinjam, '%b %Y') AS bln, COUNT(*) AS jml " +
                               "FROM peminjaman " +
                               "WHERE tanggal_pinjam >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) " +
                               "GROUP BY DATE_FORMAT(tanggal_pinjam, '%Y-%m'), DATE_FORMAT(tanggal_pinjam, '%b %Y')";
        try (PreparedStatement ps = conn.prepareStatement(pjmMonthlySql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String bln = rs.getString("bln");
                if (activity.containsKey(bln)) {
                    activity.get(bln)[0] = rs.getInt("jml");
                }
            }
        }

        // Monthly returns
        String kblMonthlySql = "SELECT DATE_FORMAT(tanggal_kembali, '%b %Y') AS bln, COUNT(*) AS jml " +
                               "FROM pengembalian " +
                               "WHERE tanggal_kembali >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) " +
                               "GROUP BY DATE_FORMAT(tanggal_kembali, '%Y-%m'), DATE_FORMAT(tanggal_kembali, '%b %Y')";
        try (PreparedStatement ps = conn.prepareStatement(kblMonthlySql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String bln = rs.getString("bln");
                if (activity.containsKey(bln)) {
                    activity.get(bln)[1] = rs.getInt("jml");
                }
            }
        }

        stats.setAktivitasBulanan(activity);
        return stats;
    }

    public List<Peminjaman> getRecentBorrowings(int limit) throws SQLException {
        List<Peminjaman> list = new ArrayList<>();
        String sql = "SELECT p.*, a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
                     "FROM peminjaman p " +
                     "JOIN anggota a ON p.id_anggota = a.id_anggota " +
                     "JOIN buku b ON p.id_buku = b.id_buku " +
                     "JOIN petugas pt ON p.id_petugas = pt.id_petugas " +
                     "ORDER BY p.tanggal_pinjam DESC, p.id_peminjaman DESC LIMIT ?";

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Peminjaman p = new Peminjaman(
                        rs.getString("id_peminjaman"),
                        rs.getString("id_anggota"),
                        rs.getString("id_buku"),
                        rs.getString("id_petugas"),
                        rs.getDate("tanggal_pinjam"),
                        rs.getDate("tanggal_jatuh_tempo"),
                        rs.getString("status_peminjaman")
                    );
                    p.setNamaAnggota(rs.getString("nama_anggota"));
                    p.setJudulBuku(rs.getString("judul_buku"));
                    p.setNamaPetugas(rs.getString("nama_petugas"));
                    list.add(p);
                }
            }
        }
        return list;
    }

    public List<Pengembalian> getRecentReturns(int limit) throws SQLException {
        List<Pengembalian> list = new ArrayList<>();
        String sql = "SELECT k.*, p.tanggal_pinjam, p.tanggal_jatuh_tempo, " +
                     "a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
                     "FROM pengembalian k " +
                     "JOIN peminjaman p ON k.id_peminjaman = p.id_peminjaman " +
                     "JOIN anggota a ON p.id_anggota = a.id_anggota " +
                     "JOIN buku b ON p.id_buku = b.id_buku " +
                     "LEFT JOIN petugas pt ON k.id_petugas = pt.id_petugas " +
                     "ORDER BY k.tanggal_kembali DESC, k.id_pengembalian DESC LIMIT ?";

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Pengembalian k = new Pengembalian(
                        rs.getString("id_pengembalian"),
                        rs.getString("id_peminjaman"),
                        rs.getDate("tanggal_kembali"),
                        rs.getInt("terlambat_hari"),
                        rs.getBigDecimal("denda"),
                        rs.getString("status_pengembalian"),
                        rs.getString("id_petugas")
                    );
                    k.setTanggalPinjam(rs.getDate("tanggal_pinjam"));
                    k.setTanggalJatuhTempo(rs.getDate("tanggal_jatuh_tempo"));
                    k.setNamaAnggota(rs.getString("nama_anggota"));
                    k.setJudulBuku(rs.getString("judul_buku"));
                    k.setNamaPetugas(rs.getString("nama_petugas"));
                    list.add(k);
                }
            }
        }
        return list;
    }
}
