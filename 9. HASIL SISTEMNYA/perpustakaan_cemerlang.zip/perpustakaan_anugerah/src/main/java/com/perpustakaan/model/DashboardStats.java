package com.perpustakaan.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class DashboardStats {
    private int totalBuku;
    private int bukuTersedia;
    private int bukuDipinjam;
    private int totalAnggota;
    private int totalPetugas;
    private int totalRak;

    // Monthly activity for chart (e.g. Month -> [borrowCount, returnCount])
    private Map<String, int[]> aktivitasBulanan = new LinkedHashMap<>();

    public DashboardStats() {}

    public int getTotalBuku() { return totalBuku; }
    public void setTotalBuku(int totalBuku) { this.totalBuku = totalBuku; }

    public int getBukuTersedia() { return bukuTersedia; }
    public void setBukuTersedia(int bukuTersedia) { this.bukuTersedia = bukuTersedia; }

    public int getBukuDipinjam() { return bukuDipinjam; }
    public void setBukuDipinjam(int bukuDipinjam) { this.bukuDipinjam = bukuDipinjam; }

    public int getTotalAnggota() { return totalAnggota; }
    public void setTotalAnggota(int totalAnggota) { this.totalAnggota = totalAnggota; }

    public int getTotalPetugas() { return totalPetugas; }
    public void setTotalPetugas(int totalPetugas) { this.totalPetugas = totalPetugas; }

    public int getTotalRak() { return totalRak; }
    public void setTotalRak(int totalRak) { this.totalRak = totalRak; }

    public Map<String, int[]> getAktivitasBulanan() { return aktivitasBulanan; }
    public void setAktivitasBulanan(Map<String, int[]> aktivitasBulanan) { this.aktivitasBulanan = aktivitasBulanan; }
}
