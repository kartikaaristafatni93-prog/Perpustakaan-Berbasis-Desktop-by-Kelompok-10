package com.perpustakaan.model;

import java.math.BigDecimal;
import java.sql.Date;

public class Pengembalian {
    private String idPengembalian;
    private String idPeminjaman;
    private String namaAnggota;    // Joined
    private String judulBuku;      // Joined
    private Date tanggalPinjam;    // Joined
    private Date tanggalJatuhTempo;// Joined
    private Date tanggalKembali;
    private int terlambatHari;
    private BigDecimal denda;
    private String statusPengembalian; // 'Tepat Waktu', 'Terlambat'
    private String idPetugas;
    private String namaPetugas;    // Joined

    public Pengembalian() {}

    public Pengembalian(String idPengembalian, String idPeminjaman, Date tanggalKembali,
                        int terlambatHari, BigDecimal denda, String statusPengembalian, String idPetugas) {
        this.idPengembalian = idPengembalian;
        this.idPeminjaman = idPeminjaman;
        this.tanggalKembali = tanggalKembali;
        this.terlambatHari = terlambatHari;
        this.denda = denda;
        this.statusPengembalian = statusPengembalian;
        this.idPetugas = idPetugas;
    }

    public String getIdPengembalian() { return idPengembalian; }
    public void setIdPengembalian(String idPengembalian) { this.idPengembalian = idPengembalian; }

    public String getIdPeminjaman() { return idPeminjaman; }
    public void setIdPeminjaman(String idPeminjaman) { this.idPeminjaman = idPeminjaman; }

    public String getNamaAnggota() { return namaAnggota; }
    public void setNamaAnggota(String namaAnggota) { this.namaAnggota = namaAnggota; }

    public String getJudulBuku() { return judulBuku; }
    public void setJudulBuku(String judulBuku) { this.judulBuku = judulBuku; }

    public Date getTanggalPinjam() { return tanggalPinjam; }
    public void setTanggalPinjam(Date tanggalPinjam) { this.tanggalPinjam = tanggalPinjam; }

    public Date getTanggalJatuhTempo() { return tanggalJatuhTempo; }
    public void setTanggalJatuhTempo(Date tanggalJatuhTempo) { this.tanggalJatuhTempo = tanggalJatuhTempo; }

    public Date getTanggalKembali() { return tanggalKembali; }
    public void setTanggalKembali(Date tanggalKembali) { this.tanggalKembali = tanggalKembali; }

    public int getTerlambatHari() { return terlambatHari; }
    public void setTerlambatHari(int terlambatHari) { this.terlambatHari = terlambatHari; }

    public BigDecimal getDenda() { return denda; }
    public void setDenda(BigDecimal denda) { this.denda = denda; }

    public String getStatusPengembalian() { return statusPengembalian; }
    public void setStatusPengembalian(String statusPengembalian) { this.statusPengembalian = statusPengembalian; }

    public String getIdPetugas() { return idPetugas; }
    public void setIdPetugas(String idPetugas) { this.idPetugas = idPetugas; }

    public String getNamaPetugas() { return namaPetugas; }
    public void setNamaPetugas(String namaPetugas) { this.namaPetugas = namaPetugas; }
}
