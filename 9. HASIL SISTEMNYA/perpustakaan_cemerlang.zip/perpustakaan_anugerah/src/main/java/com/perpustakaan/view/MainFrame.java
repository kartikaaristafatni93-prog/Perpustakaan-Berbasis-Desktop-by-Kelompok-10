package com.perpustakaan.view;

import com.perpustakaan.model.Anggota;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.utils.SessionManager;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.ModernTextField;
import com.perpustakaan.view.components.UITheme;
import com.perpustakaan.view.panels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel contentCards;

    // Panels
    private DashboardPanel dashboardPanel;
    private AnggotaPanel anggotaPanel;
    private PetugasPanel petugasPanel;
    private BukuPanel bukuPanel;
    private RakPanel rakPanel;
    private PeminjamanPanel peminjamanPanel;
    private PengembalianPanel pengembalianPanel;
    private LaporanPanel laporanPanel;

    // Sidebar navigation tracking
    private List<NavItemPanel> navItems = new ArrayList<>();
    private JLabel lblPageTitle;

    public MainFrame() {
        super("Perpustakaan Cemerlang - Sistem Informasi Manajemen Perpustakaan");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1320, 840);
        setMinimumSize(new Dimension(1080, 700));
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UITheme.BG_MAIN_TOP);

        // 1. Sidebar Navigation (Left - Clean White SaaS Style)
        JPanel sidebar = createSidebar();
        rootPanel.add(sidebar, BorderLayout.WEST);

        // 2. Right Main Container (Top Header + Center Content Area)
        JPanel rightContainer = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Soft pastel gradient background (#F4F7FC -> #EEF2F8)
                GradientPaint gp = new GradientPaint(0, 0, UITheme.BG_MAIN_TOP,
                                                     0, getHeight(), UITheme.BG_MAIN_BOTTOM);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };

        // Top Header
        JPanel topHeader = createTopHeader();
        rightContainer.add(topHeader, BorderLayout.NORTH);

        // CardLayout for panels
        cardLayout = new CardLayout();
        contentCards = new JPanel(cardLayout);
        contentCards.setOpaque(false);

        // Global refresh callback
        Runnable onDataChanged = () -> {
            if (dashboardPanel != null) dashboardPanel.refreshData();
            if (bukuPanel != null) bukuPanel.loadData();
            if (peminjamanPanel != null) {
                peminjamanPanel.loadDropdowns();
                peminjamanPanel.loadData();
            }
            if (pengembalianPanel != null) {
                pengembalianPanel.loadActiveBorrowings();
                pengembalianPanel.loadData();
            }
            if (laporanPanel != null) laporanPanel.loadAllReports();
        };

        // Initialize Panels
        bukuPanel = new BukuPanel(onDataChanged);
        contentCards.add(bukuPanel, "BUKU");

        if (!SessionManager.isPengguna()) {
            dashboardPanel = new DashboardPanel();
            anggotaPanel = new AnggotaPanel(onDataChanged);
            petugasPanel = new PetugasPanel(onDataChanged);
            rakPanel = new RakPanel(onDataChanged);
            peminjamanPanel = new PeminjamanPanel(onDataChanged);
            pengembalianPanel = new PengembalianPanel(onDataChanged);
            laporanPanel = new LaporanPanel();

            contentCards.add(dashboardPanel, "DASHBOARD");
            contentCards.add(anggotaPanel, "ANGGOTA");
            contentCards.add(petugasPanel, "PETUGAS");
            contentCards.add(rakPanel, "RAK");
            contentCards.add(peminjamanPanel, "PEMINJAMAN");
            contentCards.add(pengembalianPanel, "PENGEMBALIAN");
            contentCards.add(laporanPanel, "LAPORAN");
        }

        rightContainer.add(contentCards, BorderLayout.CENTER);
        rootPanel.add(rightContainer, BorderLayout.CENTER);

        setContentPane(rootPanel);

        // Default initial landing page based on role
        if (SessionManager.isPengguna()) {
            navigateTo("BUKU", "Katalog Buku & Informasi Koleksi");
        } else {
            navigateTo("DASHBOARD", "Dashboard Ringkasan");
        }
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(UITheme.BG_SIDEBAR);
        sidebar.setPreferredSize(new Dimension(240, 800));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UITheme.BORDER));

        // Brand / Logo Top
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 20));
        brandPanel.setOpaque(false);
        JLabel brandIcon = new JLabel(IconFactory.createIcon("library", 28, UITheme.PRIMARY));
        JPanel brandText = new JPanel(new GridLayout(2, 1, 0, 2));
        brandText.setOpaque(false);

        JLabel lblB1 = new JLabel("PERPUSTAKAAN");
        lblB1.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblB1.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblB2 = new JLabel("CEMERLANG");
        lblB2.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblB2.setForeground(UITheme.PRIMARY);

        brandText.add(lblB1);
        brandText.add(lblB2);

        brandPanel.add(brandIcon);
        brandPanel.add(brandText);
        sidebar.add(brandPanel, BorderLayout.NORTH);

        // Menu items in center
        JPanel menuContainer = new JPanel();
        menuContainer.setOpaque(false);
        menuContainer.setLayout(new BoxLayout(menuContainer, BoxLayout.Y_AXIS));
        menuContainer.setBorder(new EmptyBorder(10, 12, 10, 12));

        if (SessionManager.isPengguna()) {
            // === MENU PENGGUNA (HANYA KATALOG BUKU & KARTU ANGGOTA) ===
            addSectionHeader(menuContainer, "LAYANAN ANGGOTA");
            addNavItem(menuContainer, "Katalog Buku", "buku", "BUKU", "Katalog Buku & Ketersediaan Stok");
            addCustomActionItem(menuContainer, "Kartu Anggota Saya", "anggota", () -> {
                Anggota current = SessionManager.getCurrentAnggota();
                new MemberCardDialog(this, current).setVisible(true);
            });
        } else {
            // === MENU ADMIN / PETUGAS ===
            // 1. Dashboard
            addSectionHeader(menuContainer, "UTAMA");
            addNavItem(menuContainer, "Dashboard", "dashboard", "DASHBOARD", "Dashboard Ringkasan");

            // 2. Master Data
            addSectionHeader(menuContainer, "MASTER DATA");
            addNavItem(menuContainer, "Data Anggota", "anggota", "ANGGOTA", "Master Data - Anggota Perpustakaan");
            if (SessionManager.isAdmin()) {
                addNavItem(menuContainer, "Data Petugas", "petugas", "PETUGAS", "Master Data - Petugas & Staff");
            }
            addNavItem(menuContainer, "Data Buku", "buku", "BUKU", "Master Data - Katalog Buku");
            addNavItem(menuContainer, "Data Rak Buku", "rak", "RAK", "Master Data - Rak & Lokasi");

            // 3. Transactions
            addSectionHeader(menuContainer, "TRANSAKSI");
            addNavItem(menuContainer, "Peminjaman", "peminjaman", "PEMINJAMAN", "Transaksi - Peminjaman Buku");
            addNavItem(menuContainer, "Pengembalian", "return", "PENGEMBALIAN", "Transaksi - Pengembalian & Denda");

            // 4. Reports
            addSectionHeader(menuContainer, "LAPORAN");
            addNavItem(menuContainer, "Pusat Laporan", "report", "LAPORAN", "Laporan & Rekapitulasi Data");
        }

        JScrollPane scrollMenu = new JScrollPane(menuContainer);
        scrollMenu.setOpaque(false);
        scrollMenu.getViewport().setOpaque(false);
        scrollMenu.setBorder(null);
        scrollMenu.getVerticalScrollBar().setUnitIncrement(12);
        sidebar.add(scrollMenu, BorderLayout.CENTER);

        // User Profile & Logout Bottom
        JPanel userPanel = new JPanel(new BorderLayout(10, 0));
        userPanel.setOpaque(false);
        userPanel.setBorder(new EmptyBorder(14, 16, 16, 16));

        JPanel userInfo = new JPanel(new GridLayout(2, 1, 0, 2));
        userInfo.setOpaque(false);

        String staffName = SessionManager.getLoggedStaffName();
        if (staffName.length() > 16) staffName = staffName.substring(0, 14) + "...";
        JLabel lblUser = new JLabel(staffName);
        lblUser.setFont(UITheme.FONT_BOLD);
        lblUser.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblRole = new JLabel(SessionManager.getLoggedRoleName());
        lblRole.setFont(UITheme.FONT_SMALL);
        lblRole.setForeground(UITheme.PRIMARY_DARK);

        userInfo.add(lblUser);
        userInfo.add(lblRole);
        userPanel.add(userInfo, BorderLayout.CENTER);

        ModernButton btnLogout = new ModernButton("", IconFactory.createIcon("logout", 18, UITheme.DANGER), ModernButton.Style.GHOST);
        btnLogout.setToolTipText("Keluar dari Sistem");
        btnLogout.setPreferredSize(new Dimension(36, 36));
        btnLogout.addActionListener(e -> logout());
        userPanel.add(btnLogout, BorderLayout.EAST);

        sidebar.add(userPanel, BorderLayout.SOUTH);
        return sidebar;
    }

    private void addSectionHeader(JPanel container, String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
        lbl.setForeground(UITheme.TEXT_MUTED);
        lbl.setBorder(new EmptyBorder(14, 12, 6, 0));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        container.add(lbl);
    }

    private void addNavItem(JPanel container, String title, String iconName, String cardKey, String pageTitle) {
        NavItemPanel item = new NavItemPanel(title, iconName, cardKey, pageTitle);
        navItems.add(item);
        item.setAlignmentX(Component.LEFT_ALIGNMENT);
        container.add(item);
        container.add(Box.createVerticalStrut(3));
    }

    private void addCustomActionItem(JPanel container, String title, String iconName, Runnable action) {
        JPanel item = new JPanel(new BorderLayout(12, 0)) {
            private boolean isHovered = false;

            {
                setOpaque(false);
                setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
                setPreferredSize(new Dimension(216, 40));
                setBorder(new EmptyBorder(8, 14, 8, 14));
                setCursor(new Cursor(Cursor.HAND_CURSOR));

                JLabel lblIcon = new JLabel(IconFactory.createIcon(iconName, 18, UITheme.TEXT_SECONDARY));
                JLabel lblText = new JLabel(title);
                lblText.setFont(UITheme.FONT_BOLD);
                lblText.setForeground(UITheme.TEXT_SECONDARY);

                add(lblIcon, BorderLayout.WEST);
                add(lblText, BorderLayout.CENTER);

                addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        isHovered = true;
                        lblText.setForeground(UITheme.PRIMARY);
                        lblIcon.setIcon(IconFactory.createIcon(iconName, 18, UITheme.PRIMARY));
                        repaint();
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        isHovered = false;
                        lblText.setForeground(UITheme.TEXT_SECONDARY);
                        lblIcon.setIcon(IconFactory.createIcon(iconName, 18, UITheme.TEXT_SECONDARY));
                        repaint();
                    }

                    @Override
                    public void mouseClicked(MouseEvent e) {
                        action.run();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                if (isHovered) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(new Color(0xF4, 0xF6, 0xFA));
                    g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
                    g2.dispose();
                }
                super.paintComponent(g);
            }
        };
        item.setAlignmentX(Component.LEFT_ALIGNMENT);
        container.add(item);
        container.add(Box.createVerticalStrut(3));
    }

    private JPanel createTopHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setPreferredSize(new Dimension(1000, 60));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER));

        lblPageTitle = new JLabel("Dashboard Ringkasan");
        lblPageTitle.setFont(UITheme.FONT_HEADER);
        lblPageTitle.setForeground(UITheme.TEXT_PRIMARY);
        lblPageTitle.setBorder(new EmptyBorder(0, 24, 0, 0));
        header.add(lblPageTitle, BorderLayout.WEST);

        // Header Right: Search bar, notification, role badge, user profile
        JPanel headerRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 10));
        headerRight.setOpaque(false);

        // Search Bar Input
        ModernTextField searchField = new ModernTextField("Cari cepat di sistem...");
        searchField.setPreferredSize(new Dimension(200, 36));
        headerRight.add(searchField);

        // Notification Icon (Bell)
        JLabel lblBell = new JLabel(IconFactory.createIcon("dashboard", 18, UITheme.TEXT_SECONDARY));
        lblBell.setToolTipText("Notifikasi Sistem");
        lblBell.setCursor(new Cursor(Cursor.HAND_CURSOR));
        headerRight.add(lblBell);

        // Role Badge Pill
        JPanel rolePill = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.PRIMARY_LIGHT);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        rolePill.setOpaque(false);
        rolePill.setBorder(new EmptyBorder(4, 10, 4, 10));
        JLabel lblRoleText = new JLabel(SessionManager.getLoggedRoleName());
        lblRoleText.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblRoleText.setForeground(UITheme.PRIMARY_DARK);
        rolePill.add(lblRoleText);
        headerRight.add(rolePill);

        // Date Display
        JLabel lblDate = new JLabel("📅 " + DateUtils.formatDisplay(DateUtils.today()));
        lblDate.setFont(UITheme.FONT_SMALL);
        lblDate.setForeground(UITheme.TEXT_SECONDARY);
        headerRight.add(lblDate);

        // Database Configuration button (for Staff/Admin)
        if (!SessionManager.isPengguna()) {
            ModernButton btnDb = new ModernButton("⚙ Database", ModernButton.Style.SECONDARY);
            btnDb.setPreferredSize(new Dimension(100, 36));
            btnDb.addActionListener(e -> new DatabaseConfigDialog(this).setVisible(true));
            headerRight.add(btnDb);
        }

        header.add(headerRight, BorderLayout.EAST);
        return header;
    }

    public void navigateTo(String cardKey, String pageTitle) {
        cardLayout.show(contentCards, cardKey);
        if (lblPageTitle != null) {
            lblPageTitle.setText(pageTitle);
        }
        for (NavItemPanel item : navItems) {
            item.setActive(item.getCardKey().equals(cardKey));
        }

        // Auto-refresh when opening dashboard or reports
        if ("DASHBOARD".equals(cardKey) && dashboardPanel != null) {
            dashboardPanel.refreshData();
        } else if ("LAPORAN".equals(cardKey) && laporanPanel != null) {
            laporanPanel.loadAllReports();
        }
    }

    private void logout() {
        int opt = JOptionPane.showConfirmDialog(this,
            "Apakah Anda yakin ingin keluar dari sistem Perpustakaan Cemerlang?",
            "Konfirmasi Logout", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (opt == JOptionPane.YES_OPTION) {
            SessionManager.clearSession();
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
        }
    }

    // Sidebar navigation button item
    private class NavItemPanel extends JPanel {
        private String cardKey;
        private String pageTitle;
        private boolean isActive = false;
        private boolean isHovered = false;
        private JLabel lblText;
        private JLabel lblIcon;
        private String iconName;

        public NavItemPanel(String text, String iconName, String cardKey, String pageTitle) {
            this.cardKey = cardKey;
            this.pageTitle = pageTitle;
            this.iconName = iconName;

            setOpaque(false);
            setLayout(new BorderLayout(12, 0));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            setPreferredSize(new Dimension(216, 40));
            setBorder(new EmptyBorder(8, 14, 8, 14));
            setCursor(new Cursor(Cursor.HAND_CURSOR));

            lblIcon = new JLabel(IconFactory.createIcon(iconName, 18, UITheme.TEXT_SECONDARY));
            lblText = new JLabel(text);
            lblText.setFont(UITheme.FONT_BOLD);
            lblText.setForeground(UITheme.TEXT_SECONDARY);

            add(lblIcon, BorderLayout.WEST);
            add(lblText, BorderLayout.CENTER);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    isHovered = true;
                    if (!isActive) {
                        lblText.setForeground(UITheme.PRIMARY);
                        lblIcon.setIcon(IconFactory.createIcon(iconName, 18, UITheme.PRIMARY));
                    }
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    if (!isActive) {
                        lblText.setForeground(UITheme.TEXT_SECONDARY);
                        lblIcon.setIcon(IconFactory.createIcon(iconName, 18, UITheme.TEXT_SECONDARY));
                    }
                    repaint();
                }

                @Override
                public void mouseClicked(MouseEvent e) {
                    navigateTo(cardKey, pageTitle);
                }
            });
        }

        public String getCardKey() { return cardKey; }

        public void setActive(boolean active) {
            this.isActive = active;
            lblText.setForeground(active ? Color.WHITE : UITheme.TEXT_SECONDARY);
            lblIcon.setIcon(IconFactory.createIcon(iconName, 18, active ? Color.WHITE : UITheme.TEXT_SECONDARY));
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (isActive) {
                // Active Menu: Blue rounded highlight (#3478E5)
                g2.setColor(UITheme.PRIMARY);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
            } else if (isHovered) {
                g2.setColor(new Color(0xF4, 0xF6, 0xFA));
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }
}
