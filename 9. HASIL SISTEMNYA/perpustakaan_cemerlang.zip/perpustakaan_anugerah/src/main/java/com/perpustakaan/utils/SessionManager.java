package com.perpustakaan.utils;

import com.perpustakaan.model.Anggota;
import com.perpustakaan.model.Petugas;
import com.perpustakaan.model.User;

public class SessionManager {
    private static User currentUser = null;
    private static Petugas currentPetugas = null;
    private static Anggota currentAnggota = null;

    public static void setSession(User user, Petugas petugas) {
        currentUser = user;
        currentPetugas = petugas;
        currentAnggota = null;
    }

    public static void setMemberSession(User user, Anggota anggota) {
        currentUser = user;
        currentPetugas = null;
        currentAnggota = anggota;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static Petugas getCurrentPetugas() {
        return currentPetugas;
    }

    public static Anggota getCurrentAnggota() {
        return currentAnggota;
    }

    public static boolean isPengguna() {
        return currentUser != null && "PENGGUNA".equalsIgnoreCase(currentUser.getRole());
    }

    public static boolean isPetugas() {
        return currentUser != null && "PETUGAS".equalsIgnoreCase(currentUser.getRole());
    }

    public static boolean isAdmin() {
        return currentUser != null && "ADMIN".equalsIgnoreCase(currentUser.getRole());
    }

    public static String getLoggedStaffId() {
        if (currentPetugas != null && currentPetugas.getIdPetugas() != null) {
            return currentPetugas.getIdPetugas();
        }
        if (currentAnggota != null && currentAnggota.getIdAnggota() != null) {
            return currentAnggota.getIdAnggota();
        }
        if (currentUser != null) {
            if (currentUser.getIdPetugas() != null) return currentUser.getIdPetugas();
            if (currentUser.getIdAnggota() != null) return currentUser.getIdAnggota();
        }
        return "PTG-001";
    }

    public static String getLoggedStaffName() {
        if (currentPetugas != null && currentPetugas.getNamaLengkap() != null) {
            return currentPetugas.getNamaLengkap();
        }
        if (currentAnggota != null && currentAnggota.getNamaLengkap() != null) {
            return currentAnggota.getNamaLengkap();
        }
        if (currentUser != null) {
            return currentUser.getUsername();
        }
        return "Pengguna";
    }

    public static String getLoggedRoleName() {
        if (currentUser == null) return "Guest";
        String r = currentUser.getRole();
        if ("ADMIN".equalsIgnoreCase(r)) return "Administrator";
        if ("PETUGAS".equalsIgnoreCase(r)) return "Petugas Perpustakaan";
        if ("PENGGUNA".equalsIgnoreCase(r)) return "Anggota Perpustakaan";
        return r;
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    public static void clearSession() {
        currentUser = null;
        currentPetugas = null;
        currentAnggota = null;
    }
}
