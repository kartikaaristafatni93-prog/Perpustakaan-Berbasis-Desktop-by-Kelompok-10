package com.perpustakaan.model;

public class Buku {
    private String idBuku;
    private String isbn;
    private String judulBuku;
    private String pengarang;
    private String penerbit;
    private int tahunTerbit;
    private String kategori;
    private String idRak;
    private String namaRak; // For join/display
    private int totalStok;
    private int sisaStok;

    public Buku() {}

    public Buku(String idBuku, String isbn, String judulBuku, String pengarang, String penerbit,
                int tahunTerbit, String kategori, String idRak, int totalStok, int sisaStok) {
        this.idBuku = idBuku;
        this.isbn = isbn;
        this.judulBuku = judulBuku;
        this.pengarang = pengarang;
        this.penerbit = penerbit;
        this.tahunTerbit = tahunTerbit;
        this.kategori = kategori;
        this.idRak = idRak;
        this.totalStok = totalStok;
        this.sisaStok = sisaStok;
    }

    public String getIdBuku() { return idBuku; }
    public void setIdBuku(String idBuku) { this.idBuku = idBuku; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public String getJudulBuku() { return judulBuku; }
    public void setJudulBuku(String judulBuku) { this.judulBuku = judulBuku; }

    public String getPengarang() { return pengarang; }
    public void setPengarang(String pengarang) { this.pengarang = pengarang; }

    public String getPenerbit() { return penerbit; }
    public void setPenerbit(String penerbit) { this.penerbit = penerbit; }

    public int getTahunTerbit() { return tahunTerbit; }
    public void setTahunTerbit(int tahunTerbit) { this.tahunTerbit = tahunTerbit; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public String getIdRak() { return idRak; }
    public void setIdRak(String idRak) { this.idRak = idRak; }

    public String getNamaRak() { return namaRak; }
    public void setNamaRak(String namaRak) { this.namaRak = namaRak; }

    public int getTotalStok() { return totalStok; }
    public void setTotalStok(int totalStok) { this.totalStok = totalStok; }

    public int getSisaStok() { return sisaStok; }
    public void setSisaStok(int sisaStok) { this.sisaStok = sisaStok; }

    public int getDipinjamStok() {
        return Math.max(0, totalStok - sisaStok);
    }

    @Override
    public String toString() {
        return idBuku + " - " + judulBuku + " (Tersedia: " + sisaStok + ")";
    }
}
