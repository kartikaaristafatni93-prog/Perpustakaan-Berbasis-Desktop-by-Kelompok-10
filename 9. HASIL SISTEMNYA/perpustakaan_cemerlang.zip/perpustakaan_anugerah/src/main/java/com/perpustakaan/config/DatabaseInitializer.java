package com.perpustakaan.config;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DatabaseInitializer {

    public static boolean initializeDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // 1. Connect to MySQL Server (without database selected) to ensure database exists
            try (Connection serverConn = DriverManager.getConnection(
                    DatabaseConfig.getServerJdbcUrl(),
                    DatabaseConfig.getUsername(),
                    DatabaseConfig.getPassword());
                 Statement stmt = serverConn.createStatement()) {
                
                String createDbSql = "CREATE DATABASE IF NOT EXISTS `" + DatabaseConfig.getDatabase() + 
                                     "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
                stmt.executeUpdate(createDbSql);
            }

            // 2. Connect to the actual database and run the schema script
            try (Connection dbConn = DriverManager.getConnection(
                    DatabaseConfig.getJdbcUrl(),
                    DatabaseConfig.getUsername(),
                    DatabaseConfig.getPassword())) {
                
                executeScript(dbConn, "database.sql");

                // Seamless migration: Ensure id_anggota exists on users table
                try (Statement stmt = dbConn.createStatement()) {
                    stmt.executeUpdate("ALTER TABLE users ADD COLUMN id_anggota VARCHAR(20) NULL AFTER id_petugas");
                } catch (Exception ignored) {
                    // Column already exists
                }

                // Update official name setting to Perpustakaan Cemerlang
                try (Statement stmt = dbConn.createStatement()) {
                    stmt.executeUpdate("INSERT INTO pengaturan (kunci, nilai, keterangan) " +
                                       "VALUES ('nama_perpustakaan', 'Perpustakaan Cemerlang', 'Nama resmi perpustakaan') " +
                                       "ON DUPLICATE KEY UPDATE nilai='Perpustakaan Cemerlang'");
                } catch (Exception ignored) {}

                // Auto-synchronize book sisa_stok with active borrowings
                try (Statement stmt = dbConn.createStatement()) {
                    stmt.executeUpdate("UPDATE buku b SET sisa_stok = total_stok - (" +
                                       "SELECT COUNT(*) FROM peminjaman p WHERE p.id_buku = b.id_buku AND p.status_peminjaman = 'Dipinjam')");
                } catch (Exception ignored) {}

                return true;
            }
        } catch (Exception e) {
            System.err.println("Database initialization notice: " + e.getMessage());
            return false;
        }
    }

    private static void executeScript(Connection conn, String scriptPath) {
        try (InputStream is = DatabaseInitializer.class.getClassLoader().getResourceAsStream(scriptPath)) {
            if (is == null) {
                System.err.println("Script " + scriptPath + " not found in classpath.");
                return;
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("--") || line.startsWith("//") || line.isEmpty()) {
                    continue;
                }
                sb.append(line).append(" ");
                if (line.endsWith(";")) {
                    String sql = sb.toString().trim();
                    // Strip the trailing semicolon
                    sql = sql.substring(0, sql.length() - 1).trim();
                    if (!sql.isEmpty() && !sql.toLowerCase().startsWith("create database") && !sql.toLowerCase().startsWith("use ")) {
                        try (Statement st = conn.createStatement()) {
                            st.execute(sql);
                        } catch (Exception ex) {
                            // Non-fatal, e.g. duplicate key or table exists
                        }
                    }
                    sb.setLength(0);
                }
            }
        } catch (Exception e) {
            System.err.println("Error reading SQL script: " + e.getMessage());
        }
    }
}
