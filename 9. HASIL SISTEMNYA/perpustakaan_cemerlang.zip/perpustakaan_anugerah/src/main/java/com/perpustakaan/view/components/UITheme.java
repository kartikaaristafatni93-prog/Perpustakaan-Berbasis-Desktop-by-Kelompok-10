package com.perpustakaan.view.components;

import java.awt.*;

/**
 * Modern Light SaaS Color Palette & Typography for Perpustakaan Cemerlang
 */
public class UITheme {
    // Main Brand Colors
    public static final Color PRIMARY = new Color(0x34, 0x78, 0xE5);       // #3478E5 Primary Blue
    public static final Color PRIMARY_DARK = new Color(0x25, 0x63, 0xC5);  // #2563C5 Dark Blue / Hover
    public static final Color PRIMARY_HOVER = new Color(0x25, 0x63, 0xC5);
    public static final Color PRIMARY_LIGHT = new Color(0xEB, 0xF3, 0xFD); // Soft blue tint

    // Background & Containers (Light SaaS)
    public static final Color BG_SIDEBAR = new Color(0xFF, 0xFF, 0xFF);    // #FFFFFF Sidebar
    public static final Color BG_MAIN_TOP = new Color(0xF4, 0xF7, 0xFC);   // Gradient Start (Soft Pastel)
    public static final Color BG_MAIN_BOTTOM = new Color(0xEE, 0xF2, 0xF8);// Gradient End
    public static final Color BG_DARK = new Color(0xF4, 0xF7, 0xFC);       // Fallback background
    public static final Color BG_CARD = new Color(0xFF, 0xFF, 0xFF);       // #FFFFFF Content Container / Card
    public static final Color BG_CARD_ALT = new Color(0xF8, 0xFA, 0xFC);   // #F8FAFC Alternate row / Section
    public static final Color BG_INPUT = new Color(0xF9, 0xFA, 0xFB);      // Light clean input field

    // Borders
    public static final Color BORDER = new Color(0xEA, 0xEA, 0xEA);        // #EAEAEA Subtle Border
    public static final Color BORDER_FOCUS = new Color(0x34, 0x78, 0xE5);  // #3478E5 Focus Border

    // Typography Colors
    public static final Color TEXT_PRIMARY = new Color(0x25, 0x25, 0x25);  // #252525 Dark Primary Text
    public static final Color TEXT_SECONDARY = new Color(0x66, 0x66, 0x66);// #666666 Subtitle / Field labels
    public static final Color TEXT_MUTED = new Color(0x88, 0x88, 0x88);    // #888888 Placeholders / Secondary

    // Status & Accent Colors
    public static final Color SUCCESS = new Color(0x36, 0xB8, 0x79);       // #36B879 Success Green
    public static final Color SUCCESS_BG = new Color(0xEA, 0xF8, 0xF1);    // Soft Green pill bg
    public static final Color WARNING = new Color(0xF5, 0xB8, 0x4B);       // #F5B84B Warning Amber
    public static final Color WARNING_BG = new Color(0xFE, 0xF7, 0xEC);    // Soft Amber pill bg
    public static final Color DANGER = new Color(0xE7, 0x6B, 0x75);        // #E76B75 Danger Red
    public static final Color DANGER_HOVER = new Color(0xD2, 0x4E, 0x59);
    public static final Color DANGER_BG = new Color(0xFD, 0xEE, 0xF0);     // Soft Red pill bg
    public static final Color INFORMATION = new Color(0x69, 0xA7, 0xE8);   // #69A7E8 Information Blue
    public static final Color INFORMATION_BG = new Color(0xEE, 0xF5, 0xFD);

    // Section Accent Colors for Cards
    public static final Color ACCENT_PURPLE = new Color(0x8B, 0x5C, 0xF6); // Shelf card
    public static final Color ACCENT_CYAN = new Color(0x06, 0xB6, 0xD4);   // Member card
    public static final Color ACCENT_ORANGE = new Color(0xF9, 0x73, 0x16); // Borrowed card

    // Standard Fonts
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 15);
    public static final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_CARD_NUMBER = new Font("Segoe UI", Font.BOLD, 26);
}
