package com.perpustakaan.view.panels;

import com.perpustakaan.dao.AnggotaDAO;
import com.perpustakaan.model.Anggota;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.utils.ValidationUtils;
import com.perpustakaan.view.MemberCardDialog;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.ModernTable;
import com.perpustakaan.view.components.ModernTextField;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.Date;
import java.util.List;

public class AnggotaPanel extends JPanel {
    private AnggotaDAO anggotaDAO = new AnggotaDAO();

    // Form inputs
    private ModernTextField txtId;
    private ModernTextField txtNama;
    private JComboBox<String> cmbGender;
    private ModernTextField txtAlamat;
    private ModernTextField txtTelepon;
    private ModernTextField txtEmail;
    private ModernTextField txtTanggalDaftar;

    // Search & Table
    private ModernTextField txtSearch;
    private ModernTable table;
    private DefaultTableModel tableModel;

    // Buttons
    private ModernButton btnSave;
    private ModernButton btnUpdate;
    private ModernButton btnDelete;
    private ModernButton btnReset;
    private ModernButton btnRefresh;

    private Runnable onChangeListener;

    public AnggotaPanel(Runnable onChangeListener) {
        this.onChangeListener = onChangeListener;
        setOpaque(false);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        initUI();
        loadData();
        generateNewId();
    }

    private void initUI() {
        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titleGrp = new JPanel(new GridLayout(2, 1, 0, 4));
        titleGrp.setOpaque(false);
        JLabel lblTitle = new JLabel("Manajemen Data Anggota");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel("Kelola informasi keanggotaan, registrasi baru, dan cetak kartu anggota resmi.");
        lblSub.setFont(UITheme.FONT_SUBTITLE);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);

        titleGrp.add(lblTitle);
        titleGrp.add(lblSub);
        headerPanel.add(titleGrp, BorderLayout.CENTER);

        // Search Bar & Refresh & Print Card
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBar.setOpaque(false);

        txtSearch = new ModernTextField("Cari ID / Nama / Email / Telepon...");
        txtSearch.setPreferredSize(new Dimension(260, 38));
        txtSearch.addActionListener(e -> searchData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> searchData());

        btnRefresh = new ModernButton("Refresh", IconFactory.createIcon("refresh", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            loadData();
            resetForm();
        });

        ModernButton btnCetakKartu = new ModernButton("🖨️ Cetak Kartu Anggota", ModernButton.Style.PRIMARY);
        btnCetakKartu.addActionListener(e -> cetakKartuTerpilih());

        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnRefresh);
        searchBar.add(btnCetakKartu);

        headerPanel.add(searchBar, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Center Split: Left = Input Form (380px), Right = Data Table
        JPanel mainContent = new JPanel(new BorderLayout(20, 0));
        mainContent.setOpaque(false);

        // 1. Form Card
        JPanel formCard = createFormCard();
        mainContent.add(formCard, BorderLayout.WEST);

        // 2. Table Container
        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setOpaque(false);

        tableModel = new DefaultTableModel(
            new String[]{"ID Anggota", "Nama Lengkap", "Gender", "Telepon", "Email", "Alamat", "Tgl Daftar"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new ModernTable(tableModel);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                populateFormFromSelectedRow();
            }
        });

        tableContainer.add(ModernTable.wrap(table), BorderLayout.CENTER);
        mainContent.add(tableContainer, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createFormCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 12, 12));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(380, 560));
        card.setLayout(new BorderLayout(0, 12));
        card.setBorder(new EmptyBorder(18, 20, 18, 20));

        JLabel lblFormTitle = new JLabel("Form Data Anggota");
        lblFormTitle.setFont(UITheme.FONT_HEADER);
        lblFormTitle.setForeground(UITheme.TEXT_PRIMARY);
        card.add(lblFormTitle, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel();
        fieldsPanel.setOpaque(false);
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));

        txtId = new ModernTextField();
        txtId.setEditable(false);
        txtId.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtNama = new ModernTextField("Nama lengkap anggota");
        txtNama.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        cmbGender = new JComboBox<>(new String[]{"Laki-laki", "Perempuan"});
        cmbGender.setFont(UITheme.FONT_REGULAR);
        cmbGender.setBackground(UITheme.BG_INPUT);
        cmbGender.setForeground(UITheme.TEXT_PRIMARY);
        cmbGender.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtTelepon = new ModernTextField("Nomor HP / WhatsApp");
        txtTelepon.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtEmail = new ModernTextField("Alamat email aktif");
        txtEmail.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtAlamat = new ModernTextField("Alamat tempat tinggal");
        txtAlamat.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtTanggalDaftar = new ModernTextField(DateUtils.formatSql(DateUtils.today()));
        txtTanggalDaftar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        fieldsPanel.add(createFieldLabel("ID Anggota"));
        fieldsPanel.add(txtId);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Nama Lengkap *"));
        fieldsPanel.add(txtNama);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Jenis Kelamin *"));
        fieldsPanel.add(cmbGender);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("No. Telepon"));
        fieldsPanel.add(txtTelepon);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Email"));
        fieldsPanel.add(txtEmail);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Alamat"));
        fieldsPanel.add(txtAlamat);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Tanggal Daftar (YYYY-MM-DD) *"));
        fieldsPanel.add(txtTanggalDaftar);

        card.add(fieldsPanel, BorderLayout.CENTER);

        // Action Buttons Grid
        JPanel btnGrid = new JPanel(new GridLayout(2, 2, 8, 8));
        btnGrid.setOpaque(false);

        btnSave = new ModernButton("Simpan", IconFactory.createIcon("add", 14, Color.WHITE), ModernButton.Style.PRIMARY);
        btnSave.addActionListener(e -> saveData());

        btnUpdate = new ModernButton("Ubah", IconFactory.createIcon("edit", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnUpdate.setEnabled(false);
        btnUpdate.addActionListener(e -> updateData());

        btnDelete = new ModernButton("Hapus", IconFactory.createIcon("delete", 14, Color.WHITE), ModernButton.Style.DANGER);
        btnDelete.setEnabled(false);
        btnDelete.addActionListener(e -> deleteData());

        btnReset = new ModernButton("Batal / Baru", ModernButton.Style.SECONDARY);
        btnReset.addActionListener(e -> resetForm());

        btnGrid.add(btnSave);
        btnGrid.add(btnUpdate);
        btnGrid.add(btnDelete);
        btnGrid.add(btnReset);

        card.add(btnGrid, BorderLayout.SOUTH);
        return card;
    }

    private JLabel createFieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UITheme.FONT_SMALL);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    public void loadData() {
        SwingWorker<List<Anggota>, Void> worker = new SwingWorker<List<Anggota>, Void>() {
            @Override
            protected List<Anggota> doInBackground() throws Exception {
                return anggotaDAO.getAll();
            }

            @Override
            protected void done() {
                try {
                    List<Anggota> list = get();
                    tableModel.setRowCount(0);
                    for (Anggota a : list) {
                        tableModel.addRow(new Object[]{
                            a.getIdAnggota(),
                            a.getNamaLengkap(),
                            a.getJenisKelamin(),
                            a.getNoTelepon() != null ? a.getNoTelepon() : "-",
                            a.getEmail() != null ? a.getEmail() : "-",
                            a.getAlamat() != null ? a.getAlamat() : "-",
                            DateUtils.formatDisplay(a.getTanggalDaftar())
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    private void searchData() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) {
            loadData();
            return;
        }

        SwingWorker<List<Anggota>, Void> worker = new SwingWorker<List<Anggota>, Void>() {
            @Override
            protected List<Anggota> doInBackground() throws Exception {
                return anggotaDAO.search(keyword);
            }

            @Override
            protected void done() {
                try {
                    List<Anggota> list = get();
                    tableModel.setRowCount(0);
                    for (Anggota a : list) {
                        tableModel.addRow(new Object[]{
                            a.getIdAnggota(),
                            a.getNamaLengkap(),
                            a.getJenisKelamin(),
                            a.getNoTelepon() != null ? a.getNoTelepon() : "-",
                            a.getEmail() != null ? a.getEmail() : "-",
                            a.getAlamat() != null ? a.getAlamat() : "-",
                            DateUtils.formatDisplay(a.getTanggalDaftar())
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    private void populateFormFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        String id = (String) tableModel.getValueAt(row, 0);
        try {
            Anggota a = anggotaDAO.getById(id);
            if (a != null) {
                txtId.setText(a.getIdAnggota());
                txtNama.setText(a.getNamaLengkap());
                cmbGender.setSelectedItem(a.getJenisKelamin());
                txtTelepon.setText(a.getNoTelepon() != null ? a.getNoTelepon() : "");
                txtEmail.setText(a.getEmail() != null ? a.getEmail() : "");
                txtAlamat.setText(a.getAlamat() != null ? a.getAlamat() : "");
                txtTanggalDaftar.setText(DateUtils.formatSql(a.getTanggalDaftar()));

                btnSave.setEnabled(false);
                btnUpdate.setEnabled(true);
                btnDelete.setEnabled(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveData() {
        if (!validateInput()) return;

        try {
            Anggota a = new Anggota(
                txtId.getText().trim(),
                txtNama.getText().trim(),
                (String) cmbGender.getSelectedItem(),
                txtAlamat.getText().trim(),
                txtTelepon.getText().trim(),
                txtEmail.getText().trim(),
                Date.valueOf(txtTanggalDaftar.getText().trim())
            );

            boolean success = anggotaDAO.insert(a);
            if (success) {
                JOptionPane.showMessageDialog(this, "Data anggota berhasil disimpan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                resetForm();
                if (onChangeListener != null) onChangeListener.run();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menyimpan data anggota.", "Gagal", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saat menyimpan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateData() {
        if (!validateInput()) return;

        try {
            Anggota a = new Anggota(
                txtId.getText().trim(),
                txtNama.getText().trim(),
                (String) cmbGender.getSelectedItem(),
                txtAlamat.getText().trim(),
                txtTelepon.getText().trim(),
                txtEmail.getText().trim(),
                Date.valueOf(txtTanggalDaftar.getText().trim())
            );

            boolean success = anggotaDAO.update(a);
            if (success) {
                JOptionPane.showMessageDialog(this, "Data anggota berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                resetForm();
                if (onChangeListener != null) onChangeListener.run();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal memperbarui data anggota.", "Gagal", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saat memperbarui: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteData() {
        String id = txtId.getText().trim();
        if (id.isEmpty()) return;

        int opt = JOptionPane.showConfirmDialog(this,
            "Apakah Anda yakin ingin menghapus anggota '" + txtNama.getText() + "' (" + id + ")?",
            "Konfirmasi Hapus Anggota", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (opt == JOptionPane.YES_OPTION) {
            try {
                boolean success = anggotaDAO.delete(id);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Data anggota berhasil dihapus!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    loadData();
                    resetForm();
                    if (onChangeListener != null) onChangeListener.run();
                } else {
                    JOptionPane.showMessageDialog(this, "Anggota tidak dapat dihapus karena masih memiliki riwayat transaksi peminjaman aktif.", "Gagal Menghapus", JOptionPane.WARNING_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error saat menghapus: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void cetakKartuTerpilih() {
        int row = table.getSelectedRow();
        String id = row != -1 ? (String) tableModel.getValueAt(row, 0) : txtId.getText().trim();

        if (id == null || id.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Silakan pilih data anggota pada tabel terlebih dahulu untuk mencetak kartu anggota.",
                "Pilih Anggota", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Anggota a = anggotaDAO.getById(id);
            if (a != null) {
                Window win = SwingUtilities.getWindowAncestor(this);
                new MemberCardDialog(win, a).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Data anggota tidak ditemukan di database.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error saat memuat kartu anggota: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void resetForm() {
        generateNewId();
        txtNama.setText("");
        cmbGender.setSelectedIndex(0);
        txtAlamat.setText("");
        txtTelepon.setText("");
        txtEmail.setText("");
        txtTanggalDaftar.setText(DateUtils.formatSql(DateUtils.today()));
        table.clearSelection();

        btnSave.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }

    private void generateNewId() {
        try {
            txtId.setText(anggotaDAO.generateNewId());
        } catch (Exception e) {
            txtId.setText("AGT-001");
        }
    }

    private boolean validateInput() {
        if (ValidationUtils.isEmpty(txtNama.getText())) {
            JOptionPane.showMessageDialog(this, "Nama lengkap tidak boleh kosong!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtNama.requestFocus();
            return false;
        }
        if (!ValidationUtils.isEmpty(txtEmail.getText()) && !ValidationUtils.isValidEmail(txtEmail.getText())) {
            JOptionPane.showMessageDialog(this, "Format email tidak valid (contoh: nama@domain.com)!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtEmail.requestFocus();
            return false;
        }
        if (!ValidationUtils.isEmpty(txtTelepon.getText()) && !ValidationUtils.isNumeric(txtTelepon.getText())) {
            JOptionPane.showMessageDialog(this, "Nomor telepon harus berupa angka!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtTelepon.requestFocus();
            return false;
        }
        if (!ValidationUtils.isValidDate(txtTanggalDaftar.getText())) {
            JOptionPane.showMessageDialog(this, "Format tanggal daftar harus YYYY-MM-DD!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtTanggalDaftar.requestFocus();
            return false;
        }
        return true;
    }
}
