package com.perpustakaan.view.components;

import com.perpustakaan.utils.IconFactory;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class StatCard extends JPanel {
    private JLabel lblTitle;
    private JLabel lblValue;
    private JLabel lblSubtitle;
    private Icon icon;
    private Color accentColor;

    public StatCard(String title, String initialValue, String subtitle, String iconName, Color accentColor) {
        this.accentColor = accentColor;
        this.icon = IconFactory.createIcon(iconName, 24, accentColor);

        setOpaque(false);
        setLayout(new BorderLayout(14, 0));
        setBorder(new EmptyBorder(16, 18, 16, 18));
        setPreferredSize(new Dimension(220, 105));

        // Text container
        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

        lblTitle = new JLabel(title);
        lblTitle.setFont(UITheme.FONT_SMALL);
        lblTitle.setForeground(UITheme.TEXT_SECONDARY);

        lblValue = new JLabel(initialValue);
        lblValue.setFont(UITheme.FONT_CARD_NUMBER);
        lblValue.setForeground(UITheme.TEXT_PRIMARY);

        lblSubtitle = new JLabel(subtitle);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblSubtitle.setForeground(UITheme.TEXT_MUTED);

        textPanel.add(lblTitle);
        textPanel.add(Box.createVerticalStrut(4));
        textPanel.add(lblValue);
        textPanel.add(Box.createVerticalStrut(4));
        textPanel.add(lblSubtitle);

        add(textPanel, BorderLayout.CENTER);

        // Icon circular badge
        JPanel iconPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Subtle pastel circular accent background
                g2.setColor(new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), 28));
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), 60));
                g2.drawOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        iconPanel.setOpaque(false);
        iconPanel.setPreferredSize(new Dimension(50, 50));
        iconPanel.setLayout(new GridBagLayout());
        JLabel iconLbl = new JLabel(icon);
        iconPanel.add(iconLbl);

        add(iconPanel, BorderLayout.EAST);
    }

    public void setValue(String val) {
        lblValue.setText(val);
        repaint();
    }

    public void setSubtitle(String sub) {
        lblSubtitle.setText(sub);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // White card background
        g2.setColor(UITheme.BG_CARD);
        g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));

        // Subtle Border
        g2.setColor(UITheme.BORDER);
        g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 12, 12));

        g2.dispose();
        super.paintComponent(g);
    }
}
