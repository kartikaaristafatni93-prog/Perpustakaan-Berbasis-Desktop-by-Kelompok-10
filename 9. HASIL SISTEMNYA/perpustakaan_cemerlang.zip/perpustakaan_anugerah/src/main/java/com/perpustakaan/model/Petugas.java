package com.perpustakaan.model;

public class Petugas {
    private String idPetugas;
    private String namaLengkap;
    private String jenisKelamin;
    private String alamat;
    private String noTelepon;
    private String username;
    private String password;
    private String role;

    public Petugas() {}

    public Petugas(String idPetugas, String namaLengkap, String jenisKelamin, String alamat,
                   String noTelepon, String username, String password, String role) {
        this.idPetugas = idPetugas;
        this.namaLengkap = namaLengkap;
        this.jenisKelamin = jenisKelamin;
        this.alamat = alamat;
        this.noTelepon = noTelepon;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public String getIdPetugas() { return idPetugas; }
    public void setIdPetugas(String idPetugas) { this.idPetugas = idPetugas; }

    public String getNamaLengkap() { return namaLengkap; }
    public void setNamaLengkap(String namaLengkap) { this.namaLengkap = namaLengkap; }

    public String getJenisKelamin() { return jenisKelamin; }
    public void setJenisKelamin(String jenisKelamin) { this.jenisKelamin = jenisKelamin; }

    public String getAlamat() { return alamat; }
    public void setAlamat(String alamat) { this.alamat = alamat; }

    public String getNoTelepon() { return noTelepon; }
    public void setNoTelepon(String noTelepon) { this.noTelepon = noTelepon; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    @Override
    public String toString() {
        return idPetugas + " - " + namaLengkap;
    }
}
