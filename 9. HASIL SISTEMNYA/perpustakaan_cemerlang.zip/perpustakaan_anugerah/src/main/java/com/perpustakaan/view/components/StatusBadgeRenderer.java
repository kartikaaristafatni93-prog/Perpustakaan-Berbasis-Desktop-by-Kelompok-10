package com.perpustakaan.view.components;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class StatusBadgeRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus, int row, int column) {
        String text = value != null ? value.toString() : "-";

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                Color bg = isSelected ? table.getSelectionBackground() : (row % 2 == 1 ? UITheme.BG_CARD_ALT : UITheme.BG_CARD);
                g2.setColor(bg);
                g2.fillRect(0, 0, getWidth(), getHeight());

                Color badgeBg;
                Color badgeText;

                if ("Dipinjam".equalsIgnoreCase(text)) {
                    badgeBg = UITheme.WARNING_BG;
                    badgeText = new Color(0xB4, 0x53, 0x09);
                } else if ("Dikembalikan".equalsIgnoreCase(text) || "Tepat Waktu".equalsIgnoreCase(text) || "Tersedia".equalsIgnoreCase(text)) {
                    badgeBg = UITheme.SUCCESS_BG;
                    badgeText = new Color(0x15, 0x80, 0x3D);
                } else if ("Terlambat".equalsIgnoreCase(text) || "Habis".equalsIgnoreCase(text) || "Kosong".equalsIgnoreCase(text)) {
                    badgeBg = UITheme.DANGER_BG;
                    badgeText = new Color(0xB9, 0x1C, 0x1C);
                } else {
                    badgeBg = UITheme.PRIMARY_LIGHT;
                    badgeText = UITheme.PRIMARY_DARK;
                }

                // Center pill
                g2.setFont(UITheme.FONT_BOLD);
                FontMetrics fm = g2.getFontMetrics();
                int pillWidth = fm.stringWidth(text) + 20;
                int pillHeight = 24;
                int pillX = (getWidth() - pillWidth) / 2;
                int pillY = (getHeight() - pillHeight) / 2;

                g2.setColor(badgeBg);
                g2.fill(new RoundRectangle2D.Float(pillX, pillY, pillWidth, pillHeight, 12, 12));

                g2.setColor(badgeText);
                g2.drawString(text, pillX + 10, pillY + 16);

                g2.dispose();
            }
        };

        panel.setOpaque(true);
        return panel;
    }
}
