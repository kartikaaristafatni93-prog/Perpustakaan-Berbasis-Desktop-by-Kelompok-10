package com.perpustakaan.dao;

import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.model.Pengembalian;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PengembalianDAO {

    public List<Pengembalian> getAll() throws SQLException {
        List<Pengembalian> list = new ArrayList<>();
        String sql = "SELECT k.*, p.tanggal_pinjam, p.tanggal_jatuh_tempo, " +
                     "a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
                     "FROM pengembalian k " +
                     "JOIN peminjaman p ON k.id_peminjaman = p.id_peminjaman " +
                     "JOIN anggota a ON p.id_anggota = a.id_anggota " +
                     "JOIN buku b ON p.id_buku = b.id_buku " +
                     "LEFT JOIN petugas pt ON k.id_petugas = pt.id_petugas " +
                     "ORDER BY k.tanggal_kembali DESC, k.id_pengembalian DESC";

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    public Pengembalian getById(String id) throws SQLException {
        String sql = "SELECT k.*, p.tanggal_pinjam, p.tanggal_jatuh_tempo, " +
                     "a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
                     "FROM pengembalian k " +
                     "JOIN peminjaman p ON k.id_peminjaman = p.id_peminjaman " +
                     "JOIN anggota a ON p.id_anggota = a.id_anggota " +
                     "JOIN buku b ON p.id_buku = b.id_buku " +
                     "LEFT JOIN petugas pt ON k.id_petugas = pt.id_petugas " +
                     "WHERE k.id_pengembalian = ?";

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSet(rs);
                }
            }
        }
        return null;
    }

    public List<Pengembalian> search(String keyword) throws SQLException {
        List<Pengembalian> list = new ArrayList<>();
        String sql = "SELECT k.*, p.tanggal_pinjam, p.tanggal_jatuh_tempo, " +
                     "a.nama_lengkap AS nama_anggota, b.judul_buku, pt.nama_lengkap AS nama_petugas " +
                     "FROM pengembalian k " +
                     "JOIN peminjaman p ON k.id_peminjaman = p.id_peminjaman " +
                     "JOIN anggota a ON p.id_anggota = a.id_anggota " +
                     "JOIN buku b ON p.id_buku = b.id_buku " +
                     "LEFT JOIN petugas pt ON k.id_petugas = pt.id_petugas " +
                     "WHERE k.id_pengembalian LIKE ? OR k.id_peminjaman LIKE ? " +
                     "OR a.nama_lengkap LIKE ? OR b.judul_buku LIKE ? OR k.tanggal_kembali LIKE ? " +
                     "ORDER BY k.tanggal_kembali DESC, k.id_pengembalian DESC";

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String param = "%" + keyword + "%";
            ps.setString(1, param);
            ps.setString(2, param);
            ps.setString(3, param);
            ps.setString(4, param);
            ps.setString(5, param);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    /**
     * Atomically executes a return transaction:
     * 1. Check if borrowing exists and is still "Dipinjam" (prevent duplicate return)
     * 2. Update peminjaman status to "Dikembalikan"
     * 3. Increment book sisa_stok by 1
     * 4. Insert into pengembalian table
     */
    public boolean insert(Pengembalian k) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);

            // 1. Check borrowing status and book ID
            String checkBorrowSql = "SELECT id_buku, status_peminjaman FROM peminjaman WHERE id_peminjaman = ? FOR UPDATE";
            String bookId = null;
            String borrowStatus = null;

            try (PreparedStatement psCheck = conn.prepareStatement(checkBorrowSql)) {
                psCheck.setString(1, k.getIdPeminjaman());
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next()) {
                        bookId = rs.getString("id_buku");
                        borrowStatus = rs.getString("status_peminjaman");
                    } else {
                        throw new SQLException("Peminjaman dengan ID " + k.getIdPeminjaman() + " tidak ditemukan!");
                    }
                }
            }

            if ("Dikembalikan".equalsIgnoreCase(borrowStatus)) {
                throw new SQLException("Transaksi peminjaman ini sudah pernah dikembalikan!");
            }

            // Also verify no duplicate in pengembalian table
            String checkDupSql = "SELECT COUNT(*) FROM pengembalian WHERE id_peminjaman = ?";
            try (PreparedStatement psDup = conn.prepareStatement(checkDupSql)) {
                psDup.setString(1, k.getIdPeminjaman());
                try (ResultSet rs = psDup.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        throw new SQLException("Data pengembalian untuk peminjaman ini sudah tercatat!");
                    }
                }
            }

            // 2. Update borrowing status
            String updateBorrowSql = "UPDATE peminjaman SET status_peminjaman = 'Dikembalikan' WHERE id_peminjaman = ?";
            try (PreparedStatement psUp = conn.prepareStatement(updateBorrowSql)) {
                psUp.setString(1, k.getIdPeminjaman());
                psUp.executeUpdate();
            }

            // 3. Increment book stock
            String incStockSql = "UPDATE buku SET sisa_stok = sisa_stok + 1 WHERE id_buku = ? AND sisa_stok < total_stok";
            try (PreparedStatement psInc = conn.prepareStatement(incStockSql)) {
                psInc.setString(1, bookId);
                psInc.executeUpdate();
            }

            // 4. Insert return record
            String insertSql = "INSERT INTO pengembalian (id_pengembalian, id_peminjaman, tanggal_kembali, " +
                               "terlambat_hari, denda, status_pengembalian, id_petugas) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement psIns = conn.prepareStatement(insertSql)) {
                psIns.setString(1, k.getIdPengembalian());
                psIns.setString(2, k.getIdPeminjaman());
                psIns.setDate(3, k.getTanggalKembali());
                psIns.setInt(4, k.getTerlambatHari());
                psIns.setBigDecimal(5, k.getDenda());
                psIns.setString(6, k.getStatusPengembalian());
                psIns.setString(7, k.getIdPetugas());
                psIns.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    /**
     * Atomically deletes a return record and reverts borrowing status to "Dipinjam", decrementing book stock.
     */
    public boolean delete(String idPengembalian) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);

            String idPeminjaman = null;
            try (PreparedStatement ps = conn.prepareStatement("SELECT id_peminjaman FROM pengembalian WHERE id_pengembalian = ? FOR UPDATE")) {
                ps.setString(1, idPengembalian);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        idPeminjaman = rs.getString("id_peminjaman");
                    } else {
                        return false;
                    }
                }
            }

            String bookId = null;
            if (idPeminjaman != null) {
                try (PreparedStatement psB = conn.prepareStatement("SELECT id_buku FROM peminjaman WHERE id_peminjaman = ? FOR UPDATE")) {
                    psB.setString(1, idPeminjaman);
                    try (ResultSet rs = psB.executeQuery()) {
                        if (rs.next()) {
                            bookId = rs.getString("id_buku");
                        }
                    }
                }
            }

            // Delete return record
            try (PreparedStatement psDel = conn.prepareStatement("DELETE FROM pengembalian WHERE id_pengembalian = ?")) {
                psDel.setString(1, idPengembalian);
                psDel.executeUpdate();
            }

            // Revert borrowing status back to Dipinjam
            if (idPeminjaman != null) {
                try (PreparedStatement psRev = conn.prepareStatement("UPDATE peminjaman SET status_peminjaman = 'Dipinjam' WHERE id_peminjaman = ?")) {
                    psRev.setString(1, idPeminjaman);
                    psRev.executeUpdate();
                }
            }

            // Decrement book stock back
            if (bookId != null) {
                try (PreparedStatement psDec = conn.prepareStatement("UPDATE buku SET sisa_stok = sisa_stok - 1 WHERE id_buku = ? AND sisa_stok > 0")) {
                    psDec.setString(1, bookId);
                    psDec.executeUpdate();
                }
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    public double getLateFeePerDay() throws SQLException {
        String sql = "SELECT nilai FROM pengaturan WHERE kunci = 'denda_per_hari'";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                try {
                    return Double.parseDouble(rs.getString("nilai"));
                } catch (NumberFormatException e) {}
            }
        }
        return 1000.0; // default Rp 1.000 / day
    }

    public boolean updateLateFeePerDay(double fee) throws SQLException {
        String sql = "INSERT INTO pengaturan (kunci, nilai, keterangan) VALUES ('denda_per_hari', ?, 'Tarif denda per hari') " +
                     "ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, String.valueOf((long) fee));
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextId() throws SQLException {
        String todayStr = new SimpleDateFormat("yyyyMMdd").format(new java.util.Date());
        String prefix = "KBL-" + todayStr + "-";
        String sql = "SELECT id_pengembalian FROM pengembalian WHERE id_pengembalian LIKE ? ORDER BY id_pengembalian DESC LIMIT 1";

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, prefix + "%");
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String lastId = rs.getString("id_pengembalian");
                    try {
                        int num = Integer.parseInt(lastId.substring(prefix.length()));
                        return String.format("%s%04d", prefix, num + 1);
                    } catch (Exception e) {}
                }
            }
        }
        return prefix + "0001";
    }

    private Pengembalian mapResultSet(ResultSet rs) throws SQLException {
        Pengembalian k = new Pengembalian(
            rs.getString("id_pengembalian"),
            rs.getString("id_peminjaman"),
            rs.getDate("tanggal_kembali"),
            rs.getInt("terlambat_hari"),
            rs.getBigDecimal("denda"),
            rs.getString("status_pengembalian"),
            rs.getString("id_petugas")
        );
        k.setTanggalPinjam(rs.getDate("tanggal_pinjam"));
        k.setTanggalJatuhTempo(rs.getDate("tanggal_jatuh_tempo"));
        k.setNamaAnggota(rs.getString("nama_anggota"));
        k.setJudulBuku(rs.getString("judul_buku"));
        k.setNamaPetugas(rs.getString("nama_petugas"));
        return k;
    }
}
