package com.perpustakaan.view;

import com.perpustakaan.dao.AnggotaDAO;
import com.perpustakaan.dao.UserDAO;
import com.perpustakaan.model.Anggota;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.utils.ValidationUtils;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.ModernPasswordField;
import com.perpustakaan.view.components.ModernTextField;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.Date;

public class RegisterDialog extends JDialog {
    private ModernTextField txtUsername;
    private ModernPasswordField txtPassword;
    private ModernPasswordField txtConfirmPassword;
    private ModernTextField txtNama;
    private JComboBox<String> cmbGender;
    private ModernTextField txtAlamat;
    private ModernTextField txtEmail;
    private ModernTextField txtTelepon;
    private JLabel lblError;
    private ModernButton btnSubmit;

    private UserDAO userDAO = new UserDAO();
    private AnggotaDAO anggotaDAO = new AnggotaDAO();

    public RegisterDialog(Window parent) {
        super(parent, "Daftar Akun Anggota Baru - Perpustakaan Cemerlang", ModalityType.APPLICATION_MODAL);
        setSize(520, 680);
        setLocationRelativeTo(parent);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(new Color(0xF4, 0xF7, 0xFC));
        root.setBorder(new EmptyBorder(20, 28, 20, 28));

        // Center White Container Card
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 16, 16));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(22, 24, 22, 24));

        // Header Title
        JLabel lblTitle = new JLabel("Pendaftaran Anggota Baru");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 19));
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        lblTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblSub = new JLabel("Lengkapi data formulir di bawah untuk bergabung sebagai anggota resmi.");
        lblSub.setFont(UITheme.FONT_SMALL);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);
        lblSub.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblError = new JLabel(" ");
        lblError.setFont(UITheme.FONT_SMALL);
        lblError.setForeground(UITheme.DANGER);
        lblError.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(lblTitle);
        card.add(Box.createVerticalStrut(4));
        card.add(lblSub);
        card.add(Box.createVerticalStrut(8));
        card.add(lblError);
        card.add(Box.createVerticalStrut(10));

        // Fields Container
        JPanel formGrid = new JPanel(new GridLayout(8, 2, 10, 10));
        formGrid.setOpaque(false);
        formGrid.setAlignmentX(Component.LEFT_ALIGNMENT);

        // 1. Username
        txtUsername = new ModernTextField("Username unik");
        addFormRow(formGrid, "Username *", txtUsername);

        // 2. Password
        txtPassword = new ModernPasswordField("Minimal 4 karakter");
        addFormRow(formGrid, "Kata Sandi *", txtPassword);

        // 3. Konfirmasi Password
        txtConfirmPassword = new ModernPasswordField("Ulangi kata sandi");
        addFormRow(formGrid, "Ulangi Sandi *", txtConfirmPassword);

        // 4. Nama Lengkap
        txtNama = new ModernTextField("Nama lengkap sesuai identitas");
        addFormRow(formGrid, "Nama Lengkap *", txtNama);

        // 5. Jenis Kelamin
        cmbGender = new JComboBox<>(new String[]{"Laki-laki", "Perempuan"});
        cmbGender.setFont(UITheme.FONT_REGULAR);
        addFormRow(formGrid, "Jenis Kelamin *", cmbGender);

        // 6. Alamat
        txtAlamat = new ModernTextField("Alamat domisili lengkap");
        addFormRow(formGrid, "Alamat *", txtAlamat);

        // 7. Email
        txtEmail = new ModernTextField("contoh@email.com");
        addFormRow(formGrid, "Alamat Email *", txtEmail);

        // 8. No HP
        txtTelepon = new ModernTextField("08xxxxxxxxxx");
        addFormRow(formGrid, "No. Handphone / WA *", txtTelepon);

        card.add(formGrid);
        card.add(Box.createVerticalStrut(20));

        // Action Buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionPanel.setOpaque(false);
        actionPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        ModernButton btnCancel = new ModernButton("Batal", ModernButton.Style.SECONDARY);
        btnCancel.setPreferredSize(new Dimension(100, 40));
        btnCancel.addActionListener(e -> dispose());

        btnSubmit = new ModernButton("Daftar Sekarang", ModernButton.Style.PRIMARY);
        btnSubmit.setPreferredSize(new Dimension(160, 40));
        btnSubmit.addActionListener(e -> processRegistration());

        actionPanel.add(btnCancel);
        actionPanel.add(btnSubmit);
        card.add(actionPanel);

        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void addFormRow(JPanel container, String label, JComponent comp) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(UITheme.FONT_BOLD);
        lbl.setForeground(UITheme.TEXT_SECONDARY);
        container.add(lbl);
        container.add(comp);
    }

    private void processRegistration() {
        String username = txtUsername.getText().trim();
        String pass = new String(txtPassword.getPassword());
        String confirmPass = new String(txtConfirmPassword.getPassword());
        String nama = txtNama.getText().trim();
        String gender = (String) cmbGender.getSelectedItem();
        String alamat = txtAlamat.getText().trim();
        String email = txtEmail.getText().trim();
        String telp = txtTelepon.getText().trim();

        // Validation
        if (username.isEmpty()) {
            showError("Silakan isi Username akun.");
            txtUsername.requestFocus();
            return;
        }
        if (pass.isEmpty() || pass.length() < 4) {
            showError("Kata sandi minimal terdiri dari 4 karakter.");
            txtPassword.requestFocus();
            return;
        }
        if (!pass.equals(confirmPass)) {
            showError("Konfirmasi kata sandi tidak cocok!");
            txtConfirmPassword.requestFocus();
            return;
        }
        if (nama.isEmpty()) {
            showError("Silakan isi Nama Lengkap.");
            txtNama.requestFocus();
            return;
        }
        if (alamat.isEmpty()) {
            showError("Silakan isi Alamat lengkap.");
            txtAlamat.requestFocus();
            return;
        }
        if (email.isEmpty() || !ValidationUtils.isValidEmail(email)) {
            showError("Format alamat email tidak valid (contoh@email.com).");
            txtEmail.requestFocus();
            return;
        }
        if (telp.isEmpty() || !ValidationUtils.isValidPhone(telp)) {
            showError("Nomor HP harus berupa angka telepon yang valid (10-15 digit).");
            txtTelepon.requestFocus();
            return;
        }

        btnSubmit.setEnabled(false);
        lblError.setText("Memproses pendaftaran anggota...");
        lblError.setForeground(UITheme.TEXT_SECONDARY);

        SwingWorker<Anggota, Void> worker = new SwingWorker<Anggota, Void>() {
            private String errorMsg = null;

            @Override
            protected Anggota doInBackground() {
                try {
                    // Check username uniqueness
                    if (userDAO.isUsernameTaken(username)) {
                        errorMsg = "Username '" + username + "' sudah digunakan. Silakan pilih username lain.";
                        return null;
                    }

                    // Generate new ID Anggota
                    String idAnggota = anggotaDAO.generateNewId();
                    Date today = DateUtils.today();

                    Anggota newAnggota = new Anggota(
                        idAnggota,
                        nama,
                        gender,
                        alamat,
                        telp,
                        email,
                        today
                    );

                    boolean success = userDAO.registerMemberUser(newAnggota, username, pass);
                    if (success) {
                        return newAnggota;
                    } else {
                        errorMsg = "Gagal menyimpan data pendaftaran anggota.";
                        return null;
                    }
                } catch (Exception ex) {
                    errorMsg = "Terjadi kesalahan database: " + ex.getMessage();
                    return null;
                }
            }

            @Override
            protected void done() {
                btnSubmit.setEnabled(true);
                try {
                    Anggota result = get();
                    if (result != null) {
                        // Registration success!
                        dispose();
                        // Open Welcome Email Dialog
                        SwingUtilities.invokeLater(() -> {
                            Window win = SwingUtilities.getWindowAncestor(RegisterDialog.this);
                            new EmailNotificationDialog(win, result, username).setVisible(true);
                        });
                    } else {
                        showError(errorMsg != null ? errorMsg : "Pendaftaran gagal.");
                    }
                } catch (Exception e) {
                    showError("Error: " + e.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void showError(String msg) {
        lblError.setText(msg);
        lblError.setForeground(UITheme.DANGER);
    }
}
