package com.perpustakaan.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.io.File;
import java.io.FileOutputStream;

public class ExcelExporter {

    public static boolean exportTable(JTable table, String sheetTitle, File targetFile) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet(sheetTitle != null ? sheetTitle : "Laporan");

            // Fonts & Styles
            Font titleFont = workbook.createFont();
            titleFont.setBold(true);
            titleFont.setFontHeightInPoints((short) 14);

            CellStyle titleStyle = workbook.createCellStyle();
            titleStyle.setFont(titleFont);

            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.WHITE.getIndex());

            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.GREY_80_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setAlignment(HorizontalAlignment.CENTER);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderTop(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);

            CellStyle dataStyle = workbook.createCellStyle();
            dataStyle.setBorderBottom(BorderStyle.THIN);
            dataStyle.setBorderTop(BorderStyle.THIN);
            dataStyle.setBorderLeft(BorderStyle.THIN);
            dataStyle.setBorderRight(BorderStyle.THIN);

            CellStyle altDataStyle = workbook.createCellStyle();
            altDataStyle.cloneStyleFrom(dataStyle);
            altDataStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            altDataStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Title Row
            Row titleRow = sheet.createRow(0);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("PERPUSTAKAAN CEMERLANG - " + (sheetTitle != null ? sheetTitle.toUpperCase() : "LAPORAN"));
            titleCell.setCellStyle(titleStyle);

            Row subRow = sheet.createRow(1);
            Cell subCell = subRow.createCell(0);
            subCell.setCellValue("Dicetak pada: " + DateUtils.formatDisplay(DateUtils.today()));

            // Header Row (Row 3)
            TableModel model = table.getModel();
            int colCount = model.getColumnCount();
            Row headerRow = sheet.createRow(3);

            for (int col = 0; col < colCount; col++) {
                Cell cell = headerRow.createCell(col);
                cell.setCellValue(model.getColumnName(col));
                cell.setCellStyle(headerStyle);
            }

            // Data Rows (Row 4 onwards)
            int rowCount = model.getRowCount();
            for (int row = 0; row < rowCount; row++) {
                Row dataRow = sheet.createRow(row + 4);
                boolean isAlt = (row % 2 == 1);
                CellStyle currentStyle = isAlt ? altDataStyle : dataStyle;

                for (int col = 0; col < colCount; col++) {
                    Cell cell = dataRow.createCell(col);
                    Object val = model.getValueAt(row, col);
                    if (val == null) {
                        cell.setCellValue("");
                    } else if (val instanceof Number) {
                        cell.setCellValue(((Number) val).doubleValue());
                    } else {
                        cell.setCellValue(val.toString());
                    }
                    cell.setCellStyle(currentStyle);
                }
            }

            // Auto-size columns
            for (int col = 0; col < colCount; col++) {
                sheet.autoSizeColumn(col);
            }

            try (FileOutputStream fos = new FileOutputStream(targetFile)) {
                workbook.write(fos);
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Gagal mengekspor data ke Excel:\n" + e.getMessage(),
                "Kesalahan Ekspor", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
