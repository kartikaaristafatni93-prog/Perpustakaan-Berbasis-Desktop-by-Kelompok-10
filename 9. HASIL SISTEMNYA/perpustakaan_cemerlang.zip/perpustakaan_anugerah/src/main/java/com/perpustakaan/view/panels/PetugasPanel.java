package com.perpustakaan.view.panels;

import com.perpustakaan.dao.PetugasDAO;
import com.perpustakaan.model.Petugas;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.ModernPasswordField;
import com.perpustakaan.view.components.ModernTable;
import com.perpustakaan.view.components.ModernTextField;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

public class PetugasPanel extends JPanel {
    private PetugasDAO petugasDAO = new PetugasDAO();

    // Form inputs
    private ModernTextField txtId;
    private ModernTextField txtNama;
    private JComboBox<String> cmbGender;
    private ModernTextField txtAlamat;
    private ModernTextField txtTelepon;
    private ModernTextField txtUsername;
    private ModernPasswordField txtPassword;
    private JComboBox<String> cmbRole;

    // Search & Table
    private ModernTextField txtSearch;
    private ModernTable table;
    private DefaultTableModel tableModel;

    // Buttons
    private ModernButton btnSave;
    private ModernButton btnUpdate;
    private ModernButton btnDelete;
    private ModernButton btnReset;
    private ModernButton btnRefresh;

    private Runnable onChangeListener;

    public PetugasPanel(Runnable onChangeListener) {
        this.onChangeListener = onChangeListener;
        setOpaque(false);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        initUI();
        loadData();
        generateNewId();
    }

    private void initUI() {
        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titleGrp = new JPanel(new GridLayout(2, 1, 0, 4));
        titleGrp.setOpaque(false);
        JLabel lblTitle = new JLabel("Manajemen Data Petugas & Administrator");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel("Kelola akun pengelola perpustakaan, hak akses, dan autentikasi sistem.");
        lblSub.setFont(UITheme.FONT_SUBTITLE);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);

        titleGrp.add(lblTitle);
        titleGrp.add(lblSub);
        headerPanel.add(titleGrp, BorderLayout.CENTER);

        // Search Bar & Refresh
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBar.setOpaque(false);

        txtSearch = new ModernTextField("Cari ID / Nama / Username...");
        txtSearch.setPreferredSize(new Dimension(240, 38));
        txtSearch.addActionListener(e -> searchData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> searchData());

        btnRefresh = new ModernButton("Refresh", IconFactory.createIcon("refresh", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            loadData();
            resetForm();
        });

        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnRefresh);

        headerPanel.add(searchBar, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Center Split: Left = Input Form (360px), Right = Data Table
        JPanel mainContent = new JPanel(new BorderLayout(20, 0));
        mainContent.setOpaque(false);

        // 1. Form Card
        JPanel formCard = createFormCard();
        mainContent.add(formCard, BorderLayout.WEST);

        // 2. Table Container
        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setOpaque(false);

        tableModel = new DefaultTableModel(
            new String[]{"ID Petugas", "Nama Lengkap", "Gender", "Username", "Role", "Telepon", "Alamat"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new ModernTable(tableModel);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                populateFormFromSelectedRow();
            }
        });

        tableContainer.add(ModernTable.wrap(table), BorderLayout.CENTER);
        mainContent.add(tableContainer, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createFormCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 12, 12));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(360, 520));
        card.setLayout(new BorderLayout(0, 16));
        card.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel lblFormTitle = new JLabel("Form Akun Petugas");
        lblFormTitle.setFont(UITheme.FONT_HEADER);
        lblFormTitle.setForeground(UITheme.TEXT_PRIMARY);
        card.add(lblFormTitle, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel();
        fieldsPanel.setOpaque(false);
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));

        txtId = new ModernTextField();
        txtId.setEditable(false);
        txtId.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtNama = new ModernTextField("Nama lengkap petugas");
        txtNama.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        cmbGender = new JComboBox<>(new String[]{"Laki-laki", "Perempuan"});
        cmbGender.setFont(UITheme.FONT_REGULAR);
        cmbGender.setBackground(UITheme.BG_INPUT);
        cmbGender.setForeground(UITheme.TEXT_PRIMARY);
        cmbGender.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        cmbRole = new JComboBox<>(new String[]{"Petugas", "Admin"});
        cmbRole.setFont(UITheme.FONT_REGULAR);
        cmbRole.setBackground(UITheme.BG_INPUT);
        cmbRole.setForeground(UITheme.TEXT_PRIMARY);
        cmbRole.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtUsername = new ModernTextField("Username untuk login");
        txtUsername.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtPassword = new ModernPasswordField("Kata sandi");
        txtPassword.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtTelepon = new ModernTextField("Nomor telepon");
        txtTelepon.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtAlamat = new ModernTextField("Alamat");
        txtAlamat.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        fieldsPanel.add(createFieldLabel("ID Petugas"));
        fieldsPanel.add(txtId);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Nama Lengkap *"));
        fieldsPanel.add(txtNama);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Jenis Kelamin *"));
        fieldsPanel.add(cmbGender);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Peran / Hak Akses *"));
        fieldsPanel.add(cmbRole);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Username *"));
        fieldsPanel.add(txtUsername);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Kata Sandi *"));
        fieldsPanel.add(txtPassword);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("No. Telepon"));
        fieldsPanel.add(txtTelepon);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Alamat"));
        fieldsPanel.add(txtAlamat);

        card.add(fieldsPanel, BorderLayout.CENTER);

        // Action Buttons Grid
        JPanel btnGrid = new JPanel(new GridLayout(2, 2, 8, 8));
        btnGrid.setOpaque(false);

        btnSave = new ModernButton("Simpan", IconFactory.createIcon("add", 14, Color.WHITE), ModernButton.Style.PRIMARY);
        btnSave.addActionListener(e -> saveData());

        btnUpdate = new ModernButton("Ubah", IconFactory.createIcon("edit", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnUpdate.setEnabled(false);
        btnUpdate.addActionListener(e -> updateData());

        btnDelete = new ModernButton("Hapus", IconFactory.createIcon("delete", 14, Color.WHITE), ModernButton.Style.DANGER);
        btnDelete.setEnabled(false);
        btnDelete.addActionListener(e -> deleteData());

        btnReset = new ModernButton("Batal / Baru", ModernButton.Style.SECONDARY);
        btnReset.addActionListener(e -> resetForm());

        btnGrid.add(btnSave);
        btnGrid.add(btnUpdate);
        btnGrid.add(btnDelete);
        btnGrid.add(btnReset);

        card.add(btnGrid, BorderLayout.SOUTH);
        return card;
    }

    private JLabel createFieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UITheme.FONT_SMALL);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    public void loadData() {
        SwingWorker<List<Petugas>, Void> worker = new SwingWorker<List<Petugas>, Void>() {
            @Override
            protected List<Petugas> doInBackground() throws Exception {
                return petugasDAO.getAll();
            }

            @Override
            protected void done() {
                try {
                    List<Petugas> list = get();
                    tableModel.setRowCount(0);
                    for (Petugas p : list) {
                        tableModel.addRow(new Object[]{
                            p.getIdPetugas(),
                            p.getNamaLengkap(),
                            p.getJenisKelamin(),
                            p.getUsername(),
                            p.getRole() != null ? p.getRole() : "Petugas",
                            p.getNoTelepon() != null ? p.getNoTelepon() : "-",
                            p.getAlamat() != null ? p.getAlamat() : "-"
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(PetugasPanel.this,
                        "Gagal memuat data petugas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void searchData() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) {
            loadData();
            return;
        }

        SwingWorker<List<Petugas>, Void> worker = new SwingWorker<List<Petugas>, Void>() {
            @Override
            protected List<Petugas> doInBackground() throws Exception {
                return petugasDAO.search(keyword);
            }

            @Override
            protected void done() {
                try {
                    List<Petugas> list = get();
                    tableModel.setRowCount(0);
                    for (Petugas p : list) {
                        tableModel.addRow(new Object[]{
                            p.getIdPetugas(),
                            p.getNamaLengkap(),
                            p.getJenisKelamin(),
                            p.getUsername(),
                            p.getRole(),
                            p.getNoTelepon(),
                            p.getAlamat()
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(PetugasPanel.this,
                        "Gagal mencari data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void populateFormFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row != -1) {
            String id = table.getValueAt(row, 0).toString();
            try {
                Petugas p = petugasDAO.getById(id);
                if (p != null) {
                    txtId.setText(p.getIdPetugas());
                    txtNama.setText(p.getNamaLengkap());
                    cmbGender.setSelectedItem(p.getJenisKelamin());
                    cmbRole.setSelectedItem(p.getRole() != null ? p.getRole() : "Petugas");
                    txtUsername.setText(p.getUsername());
                    txtPassword.setText(""); // Keep empty unless updating
                    txtPassword.setPlaceholder("(Kosongkan jika tidak diubah)");
                    txtTelepon.setText(p.getNoTelepon());
                    txtAlamat.setText(p.getAlamat());

                    btnSave.setEnabled(false);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void saveData() {
        String nama = txtNama.getText().trim();
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (nama.isEmpty() || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama, username, dan kata sandi wajib diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Petugas p = new Petugas(
            txtId.getText().trim(),
            nama,
            (String) cmbGender.getSelectedItem(),
            txtAlamat.getText().trim(),
            txtTelepon.getText().trim(),
            username,
            password,
            (String) cmbRole.getSelectedItem()
        );

        try {
            if (petugasDAO.insert(p)) {
                JOptionPane.showMessageDialog(this, "Akun petugas berhasil dibuat!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                resetForm();
                if (onChangeListener != null) onChangeListener.run();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal membuat petugas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateData() {
        String nama = txtNama.getText().trim();
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (nama.isEmpty() || username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama dan username wajib diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean updatePass = !password.isEmpty();

        Petugas p = new Petugas(
            txtId.getText().trim(),
            nama,
            (String) cmbGender.getSelectedItem(),
            txtAlamat.getText().trim(),
            txtTelepon.getText().trim(),
            username,
            password,
            (String) cmbRole.getSelectedItem()
        );

        try {
            if (petugasDAO.update(p, updatePass)) {
                JOptionPane.showMessageDialog(this, "Data petugas berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                resetForm();
                if (onChangeListener != null) onChangeListener.run();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memperbarui data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteData() {
        String id = txtId.getText().trim();
        int opt = JOptionPane.showConfirmDialog(this,
            "Apakah Anda yakin ingin menghapus petugas dengan ID " + id + "?",
            "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (opt == JOptionPane.YES_OPTION) {
            try {
                if (petugasDAO.delete(id)) {
                    JOptionPane.showMessageDialog(this, "Petugas berhasil dihapus!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    loadData();
                    resetForm();
                    if (onChangeListener != null) onChangeListener.run();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus petugas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void resetForm() {
        generateNewId();
        txtNama.setText("");
        cmbGender.setSelectedIndex(0);
        cmbRole.setSelectedIndex(0);
        txtUsername.setText("");
        txtPassword.setText("");
        txtPassword.setPlaceholder("Kata sandi");
        txtTelepon.setText("");
        txtAlamat.setText("");
        table.clearSelection();

        btnSave.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }

    private void generateNewId() {
        try {
            txtId.setText(petugasDAO.generateNextId());
        } catch (Exception e) {
            txtId.setText("PTG-001");
        }
    }
}
