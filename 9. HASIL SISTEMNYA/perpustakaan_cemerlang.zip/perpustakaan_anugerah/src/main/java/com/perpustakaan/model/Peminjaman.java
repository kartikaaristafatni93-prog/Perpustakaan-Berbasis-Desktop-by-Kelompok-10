package com.perpustakaan.model;

import java.sql.Date;

public class Peminjaman {
    private String idPeminjaman;
    private String idAnggota;
    private String namaAnggota; // Joined
    private String idBuku;
    private String judulBuku;   // Joined
    private String idPetugas;
    private String namaPetugas; // Joined
    private Date tanggalPinjam;
    private Date tanggalJatuhTempo;
    private String statusPeminjaman; // 'Dipinjam', 'Dikembalikan'

    public Peminjaman() {}

    public Peminjaman(String idPeminjaman, String idAnggota, String idBuku, String idPetugas,
                      Date tanggalPinjam, Date tanggalJatuhTempo, String statusPeminjaman) {
        this.idPeminjaman = idPeminjaman;
        this.idAnggota = idAnggota;
        this.idBuku = idBuku;
        this.idPetugas = idPetugas;
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalJatuhTempo = tanggalJatuhTempo;
        this.statusPeminjaman = statusPeminjaman;
    }

    public String getIdPeminjaman() { return idPeminjaman; }
    public void setIdPeminjaman(String idPeminjaman) { this.idPeminjaman = idPeminjaman; }

    public String getIdAnggota() { return idAnggota; }
    public void setIdAnggota(String idAnggota) { this.idAnggota = idAnggota; }

    public String getNamaAnggota() { return namaAnggota; }
    public void setNamaAnggota(String namaAnggota) { this.namaAnggota = namaAnggota; }

    public String getIdBuku() { return idBuku; }
    public void setIdBuku(String idBuku) { this.idBuku = idBuku; }

    public String getJudulBuku() { return judulBuku; }
    public void setJudulBuku(String judulBuku) { this.judulBuku = judulBuku; }

    public String getIdPetugas() { return idPetugas; }
    public void setIdPetugas(String idPetugas) { this.idPetugas = idPetugas; }

    public String getNamaPetugas() { return namaPetugas; }
    public void setNamaPetugas(String namaPetugas) { this.namaPetugas = namaPetugas; }

    public Date getTanggalPinjam() { return tanggalPinjam; }
    public void setTanggalPinjam(Date tanggalPinjam) { this.tanggalPinjam = tanggalPinjam; }

    public Date getTanggalJatuhTempo() { return tanggalJatuhTempo; }
    public void setTanggalJatuhTempo(Date tanggalJatuhTempo) { this.tanggalJatuhTempo = tanggalJatuhTempo; }

    public String getStatusPeminjaman() { return statusPeminjaman; }
    public void setStatusPeminjaman(String statusPeminjaman) { this.statusPeminjaman = statusPeminjaman; }

    @Override
    public String toString() {
        return idPeminjaman + " - " + namaAnggota + " (" + judulBuku + ")";
    }
}
