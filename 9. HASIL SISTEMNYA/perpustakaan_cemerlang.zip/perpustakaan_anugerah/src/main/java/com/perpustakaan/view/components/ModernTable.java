package com.perpustakaan.view.components;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import java.awt.*;

public class ModernTable extends JTable {

    public ModernTable() {
        super();
        initStyle();
    }

    public ModernTable(TableModel model) {
        super(model);
        initStyle();
    }

    private void initStyle() {
        setRowHeight(40);
        setShowGrid(true);
        setGridColor(UITheme.BORDER);
        setIntercellSpacing(new Dimension(1, 1));
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setFont(UITheme.FONT_REGULAR);
        setForeground(UITheme.TEXT_PRIMARY);
        setBackground(UITheme.BG_CARD);
        setSelectionBackground(UITheme.PRIMARY_LIGHT);
        setSelectionForeground(UITheme.PRIMARY_DARK);
        setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // Header Styling
        JTableHeader header = getTableHeader();
        header.setPreferredSize(new Dimension(header.getWidth(), 42));
        header.setFont(UITheme.FONT_BOLD);
        header.setBackground(new Color(0xF4, 0xF6, 0xFA));
        header.setForeground(UITheme.TEXT_PRIMARY);
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER));

        ((DefaultTableCellRenderer) header.getDefaultRenderer()).setHorizontalAlignment(JLabel.LEFT);

        // Cell Renderer for standard columns
        setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBorder(new EmptyBorder(0, 12, 0, 12));

                if (isSelected) {
                    c.setBackground(table.getSelectionBackground());
                    c.setForeground(table.getSelectionForeground());
                    setFont(UITheme.FONT_BOLD);
                } else {
                    c.setBackground(row % 2 == 1 ? UITheme.BG_CARD_ALT : UITheme.BG_CARD);
                    c.setForeground(UITheme.TEXT_PRIMARY);
                    setFont(UITheme.FONT_REGULAR);
                }
                return c;
            }
        });
    }

    public static JScrollPane wrap(JTable table) {
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER, 1));
        scroll.getViewport().setBackground(UITheme.BG_CARD);
        scroll.setBackground(UITheme.BG_CARD);
        return scroll;
    }
}
