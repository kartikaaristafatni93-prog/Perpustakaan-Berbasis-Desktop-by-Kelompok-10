package com.perpustakaan;

import com.formdev.flatlaf.FlatLightLaf;
import com.perpustakaan.config.DatabaseInitializer;
import com.perpustakaan.view.LoginFrame;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        // Set high-DPI and smooth rendering properties
        System.setProperty("sun.java2d.uiScale.enabled", "true");
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        // Apply Modern FlatLaf Light Theme
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());

            // Global UI Tweaks for Modern Clean SaaS elegance
            UIManager.put("Button.arc", 8);
            UIManager.put("Component.arc", 8);
            UIManager.put("ProgressBar.arc", 8);
            UIManager.put("TextComponent.arc", 8);
            UIManager.put("ScrollBar.showButtons", false);
            UIManager.put("ScrollBar.width", 10);
            UIManager.put("TabbedPane.showTabSeparators", true);
            UIManager.put("TabbedPane.tabHeight", 38);
            UIManager.put("Table.selectionBackground", new Color(0xEB, 0xF3, 0xFD));
            UIManager.put("Table.selectionForeground", new Color(0x25, 0x63, 0xC5));
        } catch (Throwable t) {
            System.err.println("Notice: Could not load FlatLaf, falling back to System Look and Feel: " + t.getMessage());
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}
        }

        // Initialize Database Schema and default seeds in background
        SwingUtilities.invokeLater(() -> {
            new Thread(() -> {
                try {
                    DatabaseInitializer.initializeDatabase();
                } catch (Exception e) {
                    System.err.println("Notice on DB startup init: " + e.getMessage());
                }
            }).start();

            // Display Login Screen
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
