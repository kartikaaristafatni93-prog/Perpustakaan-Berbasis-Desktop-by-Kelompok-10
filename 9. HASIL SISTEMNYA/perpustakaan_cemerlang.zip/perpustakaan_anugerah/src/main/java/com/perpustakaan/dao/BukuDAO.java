package com.perpustakaan.dao;

import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.model.Buku;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BukuDAO {

    public List<Buku> getAll() throws SQLException {
        List<Buku> list = new ArrayList<>();
        String sql = "SELECT b.*, r.nama_rak FROM buku b " +
                     "LEFT JOIN rak r ON b.id_rak = r.id_rak " +
                     "ORDER BY b.id_buku DESC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    public List<Buku> getAvailableBooks() throws SQLException {
        List<Buku> list = new ArrayList<>();
        String sql = "SELECT b.*, r.nama_rak FROM buku b " +
                     "LEFT JOIN rak r ON b.id_rak = r.id_rak " +
                     "WHERE b.sisa_stok > 0 " +
                     "ORDER BY b.judul_buku ASC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    public Buku getById(String id) throws SQLException {
        String sql = "SELECT b.*, r.nama_rak FROM buku b " +
                     "LEFT JOIN rak r ON b.id_rak = r.id_rak " +
                     "WHERE b.id_buku = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSet(rs);
                }
            }
        }
        return null;
    }

    public List<Buku> search(String keyword) throws SQLException {
        List<Buku> list = new ArrayList<>();
        String sql = "SELECT b.*, r.nama_rak FROM buku b " +
                     "LEFT JOIN rak r ON b.id_rak = r.id_rak " +
                     "WHERE b.id_buku LIKE ? OR b.isbn LIKE ? OR b.judul_buku LIKE ? " +
                     "OR b.pengarang LIKE ? OR b.kategori LIKE ? " +
                     "ORDER BY b.id_buku DESC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String param = "%" + keyword + "%";
            ps.setString(1, param);
            ps.setString(2, param);
            ps.setString(3, param);
            ps.setString(4, param);
            ps.setString(5, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    public boolean insert(Buku b) throws SQLException {
        String sql = "INSERT INTO buku (id_buku, isbn, judul_buku, pengarang, penerbit, tahun_terbit, " +
                     "kategori, id_rak, total_stok, sisa_stok) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, b.getIdBuku());
            String isbnVal = (b.getIsbn() != null && !b.getIsbn().trim().isEmpty()) ? b.getIsbn() : b.getIdBuku();
            ps.setString(2, isbnVal);
            ps.setString(3, b.getJudulBuku());
            ps.setString(4, b.getPengarang());
            ps.setString(5, b.getPenerbit());
            ps.setInt(6, b.getTahunTerbit());
            ps.setString(7, b.getKategori());
            ps.setString(8, b.getIdRak());
            ps.setInt(9, b.getTotalStok());
            ps.setInt(10, b.getSisaStok());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(Buku b) throws SQLException {
        String sql = "UPDATE buku SET isbn = ?, judul_buku = ?, pengarang = ?, penerbit = ?, " +
                     "tahun_terbit = ?, kategori = ?, id_rak = ?, total_stok = ?, sisa_stok = ? " +
                     "WHERE id_buku = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String isbnVal = (b.getIsbn() != null && !b.getIsbn().trim().isEmpty()) ? b.getIsbn() : b.getIdBuku();
            ps.setString(1, isbnVal);
            ps.setString(2, b.getJudulBuku());
            ps.setString(3, b.getPengarang());
            ps.setString(4, b.getPenerbit());
            ps.setInt(5, b.getTahunTerbit());
            ps.setString(6, b.getKategori());
            ps.setString(7, b.getIdRak());
            ps.setInt(8, b.getTotalStok());
            ps.setInt(9, b.getSisaStok());
            ps.setString(10, b.getIdBuku());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(String id) throws SQLException {
        String sql = "DELETE FROM buku WHERE id_buku = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextId() throws SQLException {
        String sql = "SELECT id_buku FROM buku WHERE id_buku LIKE 'BK-%' ORDER BY id_buku DESC LIMIT 1";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String lastId = rs.getString("id_buku");
                try {
                    int num = Integer.parseInt(lastId.substring(3));
                    return String.format("BK-%03d", num + 1);
                } catch (Exception e) {}
            }
        }
        return "BK-001";
    }

    public String generateNewId() throws SQLException {
        return generateNextId();
    }

    private Buku mapResultSet(ResultSet rs) throws SQLException {
        Buku b = new Buku(
            rs.getString("id_buku"),
            rs.getString("isbn"),
            rs.getString("judul_buku"),
            rs.getString("pengarang"),
            rs.getString("penerbit"),
            rs.getInt("tahun_terbit"),
            rs.getString("kategori"),
            rs.getString("id_rak"),
            rs.getInt("total_stok"),
            rs.getInt("sisa_stok")
        );
        b.setNamaRak(rs.getString("nama_rak"));
        return b;
    }
}
