package com.perpustakaan.view.panels;

import com.perpustakaan.dao.PeminjamanDAO;
import com.perpustakaan.dao.PengembalianDAO;
import com.perpustakaan.model.Peminjaman;
import com.perpustakaan.model.Pengembalian;
import com.perpustakaan.utils.CurrencyUtils;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.utils.SessionManager;
import com.perpustakaan.view.ReceiptDialog;
import com.perpustakaan.view.components.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

public class PengembalianPanel extends JPanel {
    private PengembalianDAO pengembalianDAO = new PengembalianDAO();
    private PeminjamanDAO peminjamanDAO = new PeminjamanDAO();

    // Form inputs
    private ModernTextField txtId;
    private JComboBox<BorrowItem> cmbPinjam;
    private ModernTextField txtPeminjam;
    private ModernTextField txtJudulBuku;
    private ModernTextField txtTglPinjam;
    private ModernTextField txtTglTempo;
    private ModernTextField txtTglKembali;
    private ModernTextField txtTerlambat;
    private ModernTextField txtDenda;
    private ModernTextField txtStatusKembali;

    // Search & Table
    private ModernTextField txtSearch;
    private ModernTable table;
    private DefaultTableModel tableModel;

    // Buttons
    private ModernButton btnSave;
    private ModernButton btnDelete;
    private ModernButton btnReset;
    private ModernButton btnRefresh;
    private ModernButton btnConfigFee;

    private double lateFeePerDay = 1000.0;
    private Runnable onChangeListener;

    public static class BorrowItem {
        private Peminjaman peminjaman;

        public BorrowItem(Peminjaman p) {
            this.peminjaman = p;
        }

        public Peminjaman getPeminjaman() { return peminjaman; }

        @Override
        public String toString() {
            return peminjaman.getIdPeminjaman() + " | " + peminjaman.getNamaAnggota() + " - " + peminjaman.getJudulBuku();
        }
    }

    public PengembalianPanel(Runnable onChangeListener) {
        this.onChangeListener = onChangeListener;
        setOpaque(false);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        initUI();
        loadLateFeeSetting();
        loadActiveBorrowings();
        loadData();
        generateNewId();
    }

    private void initUI() {
        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titleGrp = new JPanel(new GridLayout(2, 1, 0, 4));
        titleGrp.setOpaque(false);
        JLabel lblTitle = new JLabel("Transaksi Pengembalian Buku & Denda");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel("Pencatatan pengembalian buku, kalkulasi otomatis denda keterlambatan, dan pemulihan stok.");
        lblSub.setFont(UITheme.FONT_SUBTITLE);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);

        titleGrp.add(lblTitle);
        titleGrp.add(lblSub);
        headerPanel.add(titleGrp, BorderLayout.CENTER);

        // Header Right: Late fee config + Search + Refresh
        JPanel headerRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        headerRight.setOpaque(false);

        btnConfigFee = new ModernButton("Tarif Denda: Rp 1.000/hari", IconFactory.createIcon("report", 14, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnConfigFee.addActionListener(e -> showConfigFeeDialog());

        txtSearch = new ModernTextField("Cari ID Kembali / Pinjam / Anggota...");
        txtSearch.setPreferredSize(new Dimension(220, 38));
        txtSearch.addActionListener(e -> searchData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> searchData());

        btnRefresh = new ModernButton("Refresh", IconFactory.createIcon("refresh", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            loadLateFeeSetting();
            loadActiveBorrowings();
            loadData();
            resetForm();
        });

        ModernButton btnCetakStruk = new ModernButton("🖨️ Cetak Struk", ModernButton.Style.PRIMARY);
        btnCetakStruk.addActionListener(e -> cetakStrukTerpilih());

        headerRight.add(btnConfigFee);
        headerRight.add(txtSearch);
        headerRight.add(btnSearch);
        headerRight.add(btnRefresh);
        headerRight.add(btnCetakStruk);

        headerPanel.add(headerRight, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Center Split: Left = Input Form (380px), Right = Data Table
        JPanel mainContent = new JPanel(new BorderLayout(20, 0));
        mainContent.setOpaque(false);

        // 1. Form Card
        JPanel formCard = createFormCard();
        mainContent.add(formCard, BorderLayout.WEST);

        // 2. Table Container
        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setOpaque(false);

        tableModel = new DefaultTableModel(
            new String[]{"ID Kembali", "ID Pinjam", "Nama Peminjam", "Judul Buku", "Tgl Kembali", "Terlambat", "Denda", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new ModernTable(tableModel);
        table.getColumnModel().getColumn(7).setCellRenderer(new StatusBadgeRenderer());
        table.getColumnModel().getColumn(0).setPreferredWidth(110);
        table.getColumnModel().getColumn(1).setPreferredWidth(110);
        table.getColumnModel().getColumn(2).setPreferredWidth(130);
        table.getColumnModel().getColumn(3).setPreferredWidth(160);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                String id = table.getValueAt(row, 0).toString();
                txtId.setText(id);
                btnSave.setEnabled(false);
                btnDelete.setEnabled(true);
            }
        });

        tableContainer.add(ModernTable.wrap(table), BorderLayout.CENTER);
        mainContent.add(tableContainer, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createFormCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 12, 12));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(380, 560));
        card.setLayout(new BorderLayout(0, 12));
        card.setBorder(new EmptyBorder(18, 20, 18, 20));

        JLabel lblFormTitle = new JLabel("Form Pengembalian & Denda");
        lblFormTitle.setFont(UITheme.FONT_HEADER);
        lblFormTitle.setForeground(UITheme.TEXT_PRIMARY);
        card.add(lblFormTitle, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel();
        fieldsPanel.setOpaque(false);
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));

        txtId = new ModernTextField();
        txtId.setEditable(false);
        txtId.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        cmbPinjam = new JComboBox<>();
        cmbPinjam.setFont(UITheme.FONT_REGULAR);
        cmbPinjam.setBackground(UITheme.BG_INPUT);
        cmbPinjam.setForeground(UITheme.TEXT_PRIMARY);
        cmbPinjam.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        cmbPinjam.addActionListener(e -> onBorrowingSelected());

        txtPeminjam = new ModernTextField();
        txtPeminjam.setEditable(false);
        txtPeminjam.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtJudulBuku = new ModernTextField();
        txtJudulBuku.setEditable(false);
        txtJudulBuku.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtTglPinjam = new ModernTextField();
        txtTglPinjam.setEditable(false);
        txtTglPinjam.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtTglTempo = new ModernTextField();
        txtTglTempo.setEditable(false);
        txtTglTempo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtTglKembali = new ModernTextField("YYYY-MM-DD");
        txtTglKembali.setText(DateUtils.formatSql(DateUtils.today()));
        txtTglKembali.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        txtTglKembali.addActionListener(e -> calculateLateAndFee());

        txtTerlambat = new ModernTextField("0 Hari");
        txtTerlambat.setEditable(false);
        txtTerlambat.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtDenda = new ModernTextField("Rp 0");
        txtDenda.setEditable(false);
        txtDenda.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtStatusKembali = new ModernTextField("Tepat Waktu");
        txtStatusKembali.setEditable(false);
        txtStatusKembali.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        fieldsPanel.add(createFieldLabel("ID Pengembalian"));
        fieldsPanel.add(txtId);
        fieldsPanel.add(Box.createVerticalStrut(6));

        fieldsPanel.add(createFieldLabel("Pilih Transaksi Peminjaman *"));
        fieldsPanel.add(cmbPinjam);
        fieldsPanel.add(Box.createVerticalStrut(6));

        // Peminjam & Judul
        fieldsPanel.add(createFieldLabel("Nama Peminjam"));
        fieldsPanel.add(txtPeminjam);
        fieldsPanel.add(Box.createVerticalStrut(6));

        fieldsPanel.add(createFieldLabel("Judul Buku"));
        fieldsPanel.add(txtJudulBuku);
        fieldsPanel.add(Box.createVerticalStrut(6));

        // Two dates: Pinjam & Tempo
        JPanel rowDates = new JPanel(new GridLayout(1, 2, 8, 0));
        rowDates.setOpaque(false);
        rowDates.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));

        JPanel pnlP = new JPanel(new BorderLayout(0, 2));
        pnlP.setOpaque(false);
        pnlP.add(createFieldLabel("Tgl Pinjam"), BorderLayout.NORTH);
        pnlP.add(txtTglPinjam, BorderLayout.CENTER);

        JPanel pnlT = new JPanel(new BorderLayout(0, 2));
        pnlT.setOpaque(false);
        pnlT.add(createFieldLabel("Jatuh Tempo"), BorderLayout.NORTH);
        pnlT.add(txtTglTempo, BorderLayout.CENTER);

        rowDates.add(pnlP);
        rowDates.add(pnlT);
        fieldsPanel.add(rowDates);
        fieldsPanel.add(Box.createVerticalStrut(6));

        // Tgl Kembali & Terlambat
        JPanel rowReturn = new JPanel(new GridLayout(1, 2, 8, 0));
        rowReturn.setOpaque(false);
        rowReturn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));

        JPanel pnlK = new JPanel(new BorderLayout(0, 2));
        pnlK.setOpaque(false);
        pnlK.add(createFieldLabel("Tgl Kembali (Hari Ini) *"), BorderLayout.NORTH);
        pnlK.add(txtTglKembali, BorderLayout.CENTER);

        JPanel pnlL = new JPanel(new BorderLayout(0, 2));
        pnlL.setOpaque(false);
        pnlL.add(createFieldLabel("Keterlambatan"), BorderLayout.NORTH);
        pnlL.add(txtTerlambat, BorderLayout.CENTER);

        rowReturn.add(pnlK);
        rowReturn.add(pnlL);
        fieldsPanel.add(rowReturn);
        fieldsPanel.add(Box.createVerticalStrut(6));

        // Denda & Status
        JPanel rowFee = new JPanel(new GridLayout(1, 2, 8, 0));
        rowFee.setOpaque(false);
        rowFee.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));

        JPanel pnlD = new JPanel(new BorderLayout(0, 2));
        pnlD.setOpaque(false);
        pnlD.add(createFieldLabel("Total Denda"), BorderLayout.NORTH);
        pnlD.add(txtDenda, BorderLayout.CENTER);

        JPanel pnlS = new JPanel(new BorderLayout(0, 2));
        pnlS.setOpaque(false);
        pnlS.add(createFieldLabel("Status"), BorderLayout.NORTH);
        pnlS.add(txtStatusKembali, BorderLayout.CENTER);

        rowFee.add(pnlD);
        rowFee.add(pnlS);
        fieldsPanel.add(rowFee);

        card.add(fieldsPanel, BorderLayout.CENTER);

        // Action Buttons Grid
        JPanel btnGrid = new JPanel(new GridLayout(1, 3, 8, 0));
        btnGrid.setOpaque(false);

        btnSave = new ModernButton("Proses Kembali", IconFactory.createIcon("return", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnSave.addActionListener(e -> saveData());

        btnDelete = new ModernButton("Hapus", IconFactory.createIcon("delete", 14, Color.WHITE), ModernButton.Style.DANGER);
        btnDelete.setEnabled(false);
        btnDelete.addActionListener(e -> deleteData());

        btnReset = new ModernButton("Batal / Baru", ModernButton.Style.SECONDARY);
        btnReset.addActionListener(e -> resetForm());

        btnGrid.add(btnSave);
        btnGrid.add(btnDelete);
        btnGrid.add(btnReset);

        card.add(btnGrid, BorderLayout.SOUTH);
        return card;
    }

    private JLabel createFieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UITheme.FONT_SMALL);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    public void loadLateFeeSetting() {
        try {
            lateFeePerDay = pengembalianDAO.getLateFeePerDay();
            btnConfigFee.setText("Tarif Denda: " + CurrencyUtils.formatRupiah(lateFeePerDay) + "/hari");
        } catch (Exception e) {
            lateFeePerDay = 1000.0;
        }
    }

    public void loadActiveBorrowings() {
        cmbPinjam.removeAllItems();
        try {
            List<Peminjaman> activeList = peminjamanDAO.getActiveBorrowings();
            for (Peminjaman p : activeList) {
                cmbPinjam.addItem(new BorrowItem(p));
            }
            if (cmbPinjam.getItemCount() > 0) {
                onBorrowingSelected();
            } else {
                txtPeminjam.setText("");
                txtJudulBuku.setText("");
                txtTglPinjam.setText("");
                txtTglTempo.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void onBorrowingSelected() {
        BorrowItem item = (BorrowItem) cmbPinjam.getSelectedItem();
        if (item != null) {
            Peminjaman p = item.getPeminjaman();
            txtPeminjam.setText(p.getNamaAnggota());
            txtJudulBuku.setText(p.getJudulBuku());
            txtTglPinjam.setText(DateUtils.formatDisplay(p.getTanggalPinjam()));
            txtTglTempo.setText(DateUtils.formatSql(p.getTanggalJatuhTempo()));
            calculateLateAndFee();
        }
    }

    private void calculateLateAndFee() {
        BorrowItem item = (BorrowItem) cmbPinjam.getSelectedItem();
        if (item == null) return;

        Date tglTempo = item.getPeminjaman().getTanggalJatuhTempo();
        Date tglKembali = DateUtils.parseSqlDate(txtTglKembali.getText());
        if (tglKembali == null) tglKembali = DateUtils.today();

        int lateDays = DateUtils.calculateDaysBetween(tglTempo, tglKembali);
        if (lateDays > 0) {
            double totalFee = lateDays * lateFeePerDay;
            txtTerlambat.setText(lateDays + " Hari");
            txtDenda.setText(CurrencyUtils.formatRupiah(totalFee));
            txtStatusKembali.setText("Terlambat");
        } else {
            txtTerlambat.setText("0 Hari");
            txtDenda.setText("Rp 0");
            txtStatusKembali.setText("Tepat Waktu");
        }
    }

    private void showConfigFeeDialog() {
        String input = JOptionPane.showInputDialog(this,
            "Masukkan tarif denda keterlambatan buku per hari (Rupiah):",
            (long) lateFeePerDay);
        if (input != null && !input.trim().isEmpty()) {
            try {
                double newFee = Double.parseDouble(input.trim());
                if (newFee < 0) throw new NumberFormatException();
                pengembalianDAO.updateLateFeePerDay(newFee);
                lateFeePerDay = newFee;
                btnConfigFee.setText("Tarif Denda: " + CurrencyUtils.formatRupiah(lateFeePerDay) + "/hari");
                calculateLateAndFee();
                JOptionPane.showMessageDialog(this, "Tarif denda berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Tarif denda harus berupa angka valid!", "Validasi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void loadData() {
        SwingWorker<List<Pengembalian>, Void> worker = new SwingWorker<List<Pengembalian>, Void>() {
            @Override
            protected List<Pengembalian> doInBackground() throws Exception {
                return pengembalianDAO.getAll();
            }

            @Override
            protected void done() {
                try {
                    List<Pengembalian> list = get();
                    tableModel.setRowCount(0);
                    for (Pengembalian k : list) {
                        tableModel.addRow(new Object[]{
                            k.getIdPengembalian(),
                            k.getIdPeminjaman(),
                            k.getNamaAnggota(),
                            k.getJudulBuku(),
                            DateUtils.formatDisplay(k.getTanggalKembali()),
                            k.getTerlambatHari() + " Hari",
                            CurrencyUtils.formatRupiah(k.getDenda()),
                            k.getStatusPengembalian()
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(PengembalianPanel.this,
                        "Gagal memuat transaksi pengembalian: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void searchData() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) {
            loadData();
            return;
        }

        SwingWorker<List<Pengembalian>, Void> worker = new SwingWorker<List<Pengembalian>, Void>() {
            @Override
            protected List<Pengembalian> doInBackground() throws Exception {
                return pengembalianDAO.search(keyword);
            }

            @Override
            protected void done() {
                try {
                    List<Pengembalian> list = get();
                    tableModel.setRowCount(0);
                    for (Pengembalian k : list) {
                        tableModel.addRow(new Object[]{
                            k.getIdPengembalian(),
                            k.getIdPeminjaman(),
                            k.getNamaAnggota(),
                            k.getJudulBuku(),
                            DateUtils.formatDisplay(k.getTanggalKembali()),
                            k.getTerlambatHari() + " Hari",
                            CurrencyUtils.formatRupiah(k.getDenda()),
                            k.getStatusPengembalian()
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(PengembalianPanel.this,
                        "Gagal mencari transaksi: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void saveData() {
        BorrowItem item = (BorrowItem) cmbPinjam.getSelectedItem();
        if (item == null) {
            JOptionPane.showMessageDialog(this, "Pilih transaksi peminjaman yang akan dikembalikan!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Date tglKembali = DateUtils.parseSqlDate(txtTglKembali.getText());
        if (tglKembali == null) {
            JOptionPane.showMessageDialog(this, "Format tanggal kembali tidak valid (gunakan YYYY-MM-DD).", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Peminjaman p = item.getPeminjaman();
        int lateDays = Math.max(0, DateUtils.calculateDaysBetween(p.getTanggalJatuhTempo(), tglKembali));
        BigDecimal denda = BigDecimal.valueOf(lateDays * lateFeePerDay);
        String status = lateDays > 0 ? "Terlambat" : "Tepat Waktu";

        Pengembalian k = new Pengembalian(
            txtId.getText().trim(),
            p.getIdPeminjaman(),
            tglKembali,
            lateDays,
            denda,
            status,
            SessionManager.getLoggedStaffId()
        );

        try {
            if (pengembalianDAO.insert(k)) {
                int optPrint = JOptionPane.showConfirmDialog(this,
                    "Pengembalian buku berhasil diproses!\nStatus peminjaman diubah ke 'Dikembalikan' dan stok buku bertambah 1.\n\nApakah Anda ingin mencetak struk bukti pengembalian sekarang?",
                    "Cetak Struk Transaksi", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (optPrint == JOptionPane.YES_OPTION) {
                    k.setNamaAnggota(p.getNamaAnggota());
                    k.setJudulBuku(p.getJudulBuku());
                    k.setTanggalPinjam(p.getTanggalPinjam());
                    k.setTanggalJatuhTempo(p.getTanggalJatuhTempo());
                    new ReceiptDialog(SwingUtilities.getWindowAncestor(this), k).setVisible(true);
                }
                loadActiveBorrowings();
                resetForm();
                if (onChangeListener != null) {
                    onChangeListener.run();
                } else {
                    loadData();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memproses pengembalian: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteData() {
        String id = txtId.getText().trim();
        int opt = JOptionPane.showConfirmDialog(this,
            "Apakah Anda yakin ingin membatalkan pengembalian " + id + "?\nStatus peminjaman akan dikembalikan ke 'Dipinjam' dan stok buku akan dikurangi 1.",
            "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (opt == JOptionPane.YES_OPTION) {
            try {
                if (pengembalianDAO.delete(id)) {
                    JOptionPane.showMessageDialog(this, "Pengembalian berhasil dibatalkan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    loadActiveBorrowings();
                    resetForm();
                    if (onChangeListener != null) {
                        onChangeListener.run();
                    } else {
                        loadData();
                    }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus pengembalian: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void resetForm() {
        generateNewId();
        loadActiveBorrowings();
        txtTglKembali.setText(DateUtils.formatSql(DateUtils.today()));
        table.clearSelection();

        btnSave.setEnabled(true);
        btnDelete.setEnabled(false);
    }

    private void generateNewId() {
        try {
            txtId.setText(pengembalianDAO.generateNextId());
        } catch (Exception e) {
            txtId.setText("KBL-0001");
        }
    }

    private void cetakStrukTerpilih() {
        int row = table.getSelectedRow();
        String id = row != -1 ? table.getValueAt(row, 0).toString() : txtId.getText().trim();

        if (id == null || id.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Silakan pilih transaksi pengembalian pada tabel untuk mencetak struk.",
                "Pilih Transaksi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Pengembalian k = pengembalianDAO.getById(id);
            if (k != null) {
                new ReceiptDialog(SwingUtilities.getWindowAncestor(this), k).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Transaksi pengembalian tidak ditemukan di database.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error saat memuat data struk: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
