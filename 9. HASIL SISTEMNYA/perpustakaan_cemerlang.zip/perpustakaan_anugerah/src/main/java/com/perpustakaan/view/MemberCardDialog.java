package com.perpustakaan.view;

import com.perpustakaan.model.Anggota;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.print.*;

public class MemberCardDialog extends JDialog implements Printable {
    private Anggota anggota;
    private JPanel cardPanel;

    public MemberCardDialog(Window parent, Anggota anggota) {
        super(parent, "Kartu Tanda Anggota - Perpustakaan Cemerlang", ModalityType.APPLICATION_MODAL);
        this.anggota = anggota;
        setSize(520, 480);
        setLocationRelativeTo(parent);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setBackground(new Color(0xF4, 0xF7, 0xFC));
        content.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Header Title
        JLabel lblHeader = new JLabel("Kartu Tanda Anggota Resmi", JLabel.CENTER);
        lblHeader.setFont(UITheme.FONT_TITLE);
        lblHeader.setForeground(UITheme.TEXT_PRIMARY);
        content.add(lblHeader, BorderLayout.NORTH);

        // Card Canvas Panel
        cardPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // Card Base (Crisp White with rounded edges and soft border)
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, w, h, 20, 20));

                // Top Header Ribbon (Brand Blue Gradient)
                int headerH = 70;
                GradientPaint gp = new GradientPaint(0, 0, UITheme.PRIMARY, w, 0, UITheme.PRIMARY_DARK);
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(0, 0, w, headerH, 20, 20));
                g2.fillRect(0, headerH - 12, w, 12); // square bottom corners of ribbon

                // Library Logo on Header
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 17));
                g2.drawString("PERPUSTAKAAN CEMERLANG", 68, 34);

                g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                g2.setColor(new Color(255, 255, 255, 210));
                g2.drawString("KARTU TANDA ANGGOTA RESMI PERPUSTAKAAN", 68, 52);

                // Book Icon Graphic
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(22, 18, 34, 34, 8, 8);
                g2.setColor(UITheme.PRIMARY);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 20));
                g2.drawString("📚", 26, 42);

                // Avatar / Profile Box on the left
                int avatarX = 22;
                int avatarY = 90;
                int avatarW = 90;
                int avatarH = 110;
                g2.setColor(new Color(0xF1, 0xF5, 0xF9));
                g2.fill(new RoundRectangle2D.Float(avatarX, avatarY, avatarW, avatarH, 12, 12));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(avatarX, avatarY, avatarW, avatarH, 12, 12));

                // Avatar Icon Silhouette
                g2.setColor(new Color(0x94, 0xA3, 0xB8));
                g2.fillOval(avatarX + 30, avatarY + 22, 30, 30); // Head
                g2.fillArc(avatarX + 15, avatarY + 58, 60, 50, 0, 180); // Shoulders

                g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
                g2.setColor(UITheme.PRIMARY);
                g2.drawString("MEMBER", avatarX + 24, avatarY + 102);

                // Member Information Details (Right side)
                int infoX = 130;
                int infoY = 100;

                // Member ID Badge
                g2.setColor(UITheme.PRIMARY_LIGHT);
                g2.fill(new RoundRectangle2D.Float(infoX, infoY - 14, 110, 24, 6, 6));
                g2.setColor(UITheme.PRIMARY_DARK);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 13));
                String idText = anggota != null ? anggota.getIdAnggota() : "AGT-000";
                g2.drawString(idText, infoX + 12, infoY + 3);

                // Member Name
                infoY += 34;
                g2.setFont(new Font("Segoe UI", Font.BOLD, 16));
                g2.setColor(UITheme.TEXT_PRIMARY);
                String nama = anggota != null ? anggota.getNamaLengkap() : "-";
                if (nama.length() > 24) nama = nama.substring(0, 22) + "...";
                g2.drawString(nama, infoX, infoY);

                // Gender & Phone
                infoY += 22;
                g2.setFont(UITheme.FONT_SMALL);
                g2.setColor(UITheme.TEXT_SECONDARY);
                String telp = anggota != null && anggota.getNoTelepon() != null ? anggota.getNoTelepon() : "-";
                String gender = anggota != null && anggota.getJenisKelamin() != null ? anggota.getJenisKelamin() : "-";
                g2.drawString("Gender: " + gender + "   |   Telp: " + telp, infoX, infoY);

                // Email
                infoY += 18;
                String email = anggota != null && anggota.getEmail() != null ? anggota.getEmail() : "-";
                g2.drawString("Email: " + email, infoX, infoY);

                // Registration Date
                infoY += 18;
                String tgl = anggota != null && anggota.getTanggalDaftar() != null ?
                             DateUtils.formatDisplay(anggota.getTanggalDaftar()) : "-";
                g2.drawString("Terdaftar: " + tgl, infoX, infoY);

                // Barcode Aesthetic Simulation (Bottom)
                int barY = 222;
                int barX = 22;
                int barW = 240;
                int barH = 26;

                // Draw Barcode Lines
                int curX = barX;
                int[] barWidths = {2, 1, 3, 1, 2, 4, 1, 2, 1, 3, 2, 1, 4, 2, 1, 3, 1, 2, 3, 1, 2, 4, 1, 2, 3, 1, 2, 1, 3, 2, 4, 1, 2, 1, 3, 2, 1, 4, 2};
                g2.setColor(Color.BLACK);
                for (int bw : barWidths) {
                    if (curX + bw > barX + barW) break;
                    g2.fillRect(curX, barY, bw, barH);
                    curX += bw + 2;
                }
                g2.setFont(new Font("Monospaced", Font.PLAIN, 10));
                g2.setColor(UITheme.TEXT_MUTED);
                g2.drawString("* " + idText + " *", barX + 50, barY + barH + 12);

                // Holographic Seal / Verified Badge
                int sealX = w - 120;
                int sealY = 216;
                g2.setColor(new Color(0x36, 0xB8, 0x79, 25));
                g2.fillOval(sealX, sealY, 44, 44);
                g2.setColor(UITheme.SUCCESS);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawOval(sealX, sealY, 44, 44);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 8));
                g2.drawString("VERIFIED", sealX + 4, sealY + 22);
                g2.drawString("MEMBER", sealX + 6, sealY + 32);

                // Card Border
                g2.setColor(UITheme.BORDER);
                g2.setStroke(new BasicStroke(1.0f));
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, 20, 20));

                g2.dispose();
            }
        };
        cardPanel.setPreferredSize(new Dimension(460, 270));
        cardPanel.setMinimumSize(new Dimension(460, 270));
        cardPanel.setOpaque(false);

        // Center Wrapper
        JPanel centerWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 16));
        centerWrapper.setOpaque(false);
        centerWrapper.add(cardPanel);
        content.add(centerWrapper, BorderLayout.CENTER);

        // Bottom Actions
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        actionPanel.setOpaque(false);

        ModernButton btnPrint = new ModernButton("🖨️ Cetak Kartu Anggota", ModernButton.Style.PRIMARY);
        btnPrint.setPreferredSize(new Dimension(200, 42));
        btnPrint.addActionListener(e -> printCard());

        ModernButton btnClose = new ModernButton("Tutup", ModernButton.Style.SECONDARY);
        btnClose.setPreferredSize(new Dimension(110, 42));
        btnClose.addActionListener(e -> dispose());

        actionPanel.add(btnPrint);
        actionPanel.add(btnClose);
        content.add(actionPanel, BorderLayout.SOUTH);

        setContentPane(content);
    }

    private void printCard() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Kartu Anggota - " + (anggota != null ? anggota.getNamaLengkap() : "Perpustakaan"));
        job.setPrintable(this);

        if (job.printDialog()) {
            try {
                job.print();
                JOptionPane.showMessageDialog(this,
                    "Perintah cetak kartu anggota berhasil dikirim ke printer!",
                    "Sukses Cetak", JOptionPane.INFORMATION_MESSAGE);
            } catch (PrinterException ex) {
                JOptionPane.showMessageDialog(this,
                    "Gagal mencetak kartu anggota: " + ex.getMessage(),
                    "Error Cetak", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {
        if (pageIndex > 0) return NO_SUCH_PAGE;

        Graphics2D g2 = (Graphics2D) graphics;
        g2.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        // Center card on printed page
        double scale = Math.min(pageFormat.getImageableWidth() / cardPanel.getWidth(),
                                pageFormat.getImageableHeight() / cardPanel.getHeight());
        if (scale > 1.0) scale = 1.0;
        g2.scale(scale, scale);

        cardPanel.printAll(g2);
        return PAGE_EXISTS;
    }
}
