package com.perpustakaan.view;

import com.perpustakaan.model.Peminjaman;
import com.perpustakaan.model.Pengembalian;
import com.perpustakaan.utils.CurrencyUtils;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.print.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReceiptDialog extends JDialog implements Printable {
    public enum Type {
        PEMINJAMAN, PENGEMBALIAN
    }

    private Type type;
    private Peminjaman peminjaman;
    private Pengembalian pengembalian;
    private JPanel receiptPanel;

    public ReceiptDialog(Window parent, Peminjaman peminjaman) {
        super(parent, "Struk Bukti Peminjaman Buku", ModalityType.APPLICATION_MODAL);
        this.type = Type.PEMINJAMAN;
        this.peminjaman = peminjaman;
        init();
    }

    public ReceiptDialog(Window parent, Pengembalian pengembalian) {
        super(parent, "Struk Bukti Pengembalian Buku", ModalityType.APPLICATION_MODAL);
        this.type = Type.PENGEMBALIAN;
        this.pengembalian = pengembalian;
        init();
    }

    private void init() {
        setSize(500, 720);
        setLocationRelativeTo(getOwner());
        setResizable(true);
        initUI();
    }

    private void initUI() {
        JPanel content = new JPanel(new BorderLayout(0, 14));
        content.setBackground(new Color(0xF4, 0xF7, 0xFC));
        content.setBorder(new EmptyBorder(14, 16, 14, 16));

        // Receipt Canvas Panel
        receiptPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // White paper background with soft border & subtle shadow
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, w, h, 14, 14));
                g2.setColor(UITheme.BORDER);
                g2.setStroke(new BasicStroke(1.0f));
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, 14, 14));

                int y = 30;

                // Library Header
                g2.setColor(UITheme.PRIMARY_DARK);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 17));
                drawCenteredString(g2, "PERPUSTAKAAN CEMERLANG", y, w);

                y += 18;
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                g2.setColor(UITheme.TEXT_SECONDARY);
                drawCenteredString(g2, "Layanan Otomasi & Sirkulasi Perpustakaan Modern", y, w);

                y += 14;
                drawCenteredString(g2, "Jl. Merdeka No. 10, Jakarta Pusat | Telp: (021) 1234567", y, w);

                // Dashed separator
                y += 16;
                drawDashedLine(g2, 20, y, w - 20);

                // Receipt Title
                y += 20;
                g2.setFont(new Font("Segoe UI", Font.BOLD, 13));
                g2.setColor(UITheme.TEXT_PRIMARY);
                String title = type == Type.PEMINJAMAN ? "BUKTI PEMINJAMAN BUKU" : "BUKTI PENGEMBALIAN BUKU";
                drawCenteredString(g2, title, y, w);

                y += 16;
                drawDashedLine(g2, 20, y, w - 20);

                // Print Date / Time
                y += 22;
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                g2.setColor(UITheme.TEXT_MUTED);
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                g2.drawString("Waktu Cetak: " + sdf.format(new Date()), 25, y);

                // Transaction Rows
                y += 24;
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                g2.setColor(UITheme.TEXT_PRIMARY);

                if (type == Type.PEMINJAMAN && peminjaman != null) {
                    y = drawReceiptRow(g2, "No. Transaksi", peminjaman.getIdPeminjaman(), y, w);
                    y = drawReceiptRow(g2, "ID Anggota", peminjaman.getIdAnggota(), y, w);
                    y = drawReceiptRow(g2, "Nama Anggota", peminjaman.getNamaAnggota(), y, w);
                    y = drawReceiptRow(g2, "ID Buku", peminjaman.getIdBuku(), y, w);
                    y = drawReceiptRow(g2, "Judul Buku", peminjaman.getJudulBuku(), y, w);
                    y = drawReceiptRow(g2, "Tgl Pinjam", DateUtils.formatDisplay(peminjaman.getTanggalPinjam()), y, w);
                    y = drawReceiptRow(g2, "Jatuh Tempo", DateUtils.formatDisplay(peminjaman.getTanggalJatuhTempo()), y, w);
                    y = drawReceiptRow(g2, "Petugas", peminjaman.getNamaPetugas() != null ? peminjaman.getNamaPetugas() : peminjaman.getIdPetugas(), y, w);
                    y = drawReceiptRow(g2, "Status", peminjaman.getStatusPeminjaman(), y, w);
                } else if (type == Type.PENGEMBALIAN && pengembalian != null) {
                    y = drawReceiptRow(g2, "No. Pengembalian", pengembalian.getIdPengembalian(), y, w);
                    y = drawReceiptRow(g2, "No. Peminjaman", pengembalian.getIdPeminjaman(), y, w);
                    y = drawReceiptRow(g2, "Nama Peminjam", pengembalian.getNamaAnggota(), y, w);
                    y = drawReceiptRow(g2, "Judul Buku", pengembalian.getJudulBuku(), y, w);
                    y = drawReceiptRow(g2, "Tgl Pinjam", DateUtils.formatDisplay(pengembalian.getTanggalPinjam()), y, w);
                    y = drawReceiptRow(g2, "Jatuh Tempo", DateUtils.formatDisplay(pengembalian.getTanggalJatuhTempo()), y, w);
                    y = drawReceiptRow(g2, "Tgl Kembali", DateUtils.formatDisplay(pengembalian.getTanggalKembali()), y, w);
                    y = drawReceiptRow(g2, "Keterlambatan", pengembalian.getTerlambatHari() + " Hari", y, w);
                    y = drawReceiptRow(g2, "Denda", CurrencyUtils.formatRupiah(pengembalian.getDenda()), y, w);
                    y = drawReceiptRow(g2, "Status", pengembalian.getStatusPengembalian(), y, w);
                    y = drawReceiptRow(g2, "Petugas", pengembalian.getNamaPetugas() != null ? pengembalian.getNamaPetugas() : "-", y, w);
                }

                // Dashed separator
                y += 8;
                drawDashedLine(g2, 20, y, w - 20);

                // Notes / Terms
                y += 20;
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                g2.setColor(UITheme.TEXT_SECONDARY);
                if (type == Type.PEMINJAMAN) {
                    drawCenteredString(g2, "* Harap kembalikan buku tepat waktu sebelum jatuh tempo.", y, w);
                    y += 14;
                    drawCenteredString(g2, "* Keterlambatan dikenakan denda Rp 1.000 / hari.", y, w);
                    y += 14;
                    drawCenteredString(g2, "* Jagalah buku dengan baik agar tidak rusak atau hilang.", y, w);
                } else {
                    drawCenteredString(g2, "* Buku telah diterima kembali oleh pihak perpustakaan.", y, w);
                    y += 14;
                    drawCenteredString(g2, "* Terima kasih telah mengembalikan koleksi buku tepat waktu.", y, w);
                }

                // Signature block
                y += 34;
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                g2.drawString("Peminjam,", 40, y);
                g2.drawString("Petugas Perpustakaan,", w - 160, y);

                y += 42;
                g2.drawString("(..................................)", 30, y);
                g2.drawString("(..................................)", w - 170, y);

                // Footer greeting
                y += 26;
                g2.setFont(new Font("Segoe UI", Font.ITALIC, 10));
                g2.setColor(UITheme.TEXT_MUTED);
                drawCenteredString(g2, "-- Terima kasih atas kunjungan Anda di Perpustakaan Cemerlang --", y, w);

                g2.dispose();
            }
        };
        receiptPanel.setPreferredSize(new Dimension(400, 570));
        receiptPanel.setMinimumSize(new Dimension(400, 570));
        receiptPanel.setOpaque(false);

        // Center Wrapper inside ScrollPane to guarantee receipt is never collapsed by layout
        JPanel centerWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        centerWrapper.setOpaque(false);
        centerWrapper.add(receiptPanel);

        JScrollPane scrollPane = new JScrollPane(centerWrapper);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        content.add(scrollPane, BorderLayout.CENTER);

        // Action Buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        actionPanel.setOpaque(false);

        ModernButton btnPrint = new ModernButton("🖨️ Cetak Struk Fisik", ModernButton.Style.PRIMARY);
        btnPrint.setPreferredSize(new Dimension(190, 42));
        btnPrint.addActionListener(e -> printReceipt());

        ModernButton btnClose = new ModernButton("Tutup", ModernButton.Style.SECONDARY);
        btnClose.setPreferredSize(new Dimension(110, 42));
        btnClose.addActionListener(e -> dispose());

        actionPanel.add(btnPrint);
        actionPanel.add(btnClose);
        content.add(actionPanel, BorderLayout.SOUTH);

        setContentPane(content);
    }

    private int drawReceiptRow(Graphics2D g2, String label, String value, int y, int w) {
        g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        g2.setColor(UITheme.TEXT_SECONDARY);
        g2.drawString(label, 25, y);

        g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
        g2.setColor(UITheme.TEXT_PRIMARY);

        String val = value != null ? value : "-";
        if (val.length() > 30) val = val.substring(0, 28) + "...";

        FontMetrics fm = g2.getFontMetrics();
        int valW = fm.stringWidth(val);
        g2.drawString(val, w - 25 - valW, y);

        return y + 20;
    }

    private void drawCenteredString(Graphics2D g2, String text, int y, int width) {
        FontMetrics fm = g2.getFontMetrics();
        int x = (width - fm.stringWidth(text)) / 2;
        g2.drawString(text, x, y);
    }

    private void drawDashedLine(Graphics2D g2, int x1, int y, int x2) {
        Stroke oldStroke = g2.getStroke();
        Stroke dashed = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{4, 4}, 0);
        g2.setStroke(dashed);
        g2.setColor(new Color(0xD1, 0xD5, 0xDB));
        g2.drawLine(x1, y, x2, y);
        g2.setStroke(oldStroke);
    }

    private void printReceipt() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Struk Transaksi - Perpustakaan Cemerlang");
        job.setPrintable(this);

        if (job.printDialog()) {
            try {
                job.print();
                JOptionPane.showMessageDialog(this,
                    "Struk transaksi berhasil dikirim ke printer!",
                    "Sukses Cetak", JOptionPane.INFORMATION_MESSAGE);
            } catch (PrinterException ex) {
                JOptionPane.showMessageDialog(this,
                    "Gagal mencetak struk: " + ex.getMessage(),
                    "Error Cetak", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {
        if (pageIndex > 0) return NO_SUCH_PAGE;

        Graphics2D g2 = (Graphics2D) graphics;
        g2.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        double scale = Math.min(pageFormat.getImageableWidth() / receiptPanel.getWidth(),
                                pageFormat.getImageableHeight() / receiptPanel.getHeight());
        if (scale > 1.0) scale = 1.0;
        g2.scale(scale, scale);

        receiptPanel.printAll(g2);
        return PAGE_EXISTS;
    }
}
