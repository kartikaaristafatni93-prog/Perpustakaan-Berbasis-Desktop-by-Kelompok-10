package com.perpustakaan.view.panels;

import com.perpustakaan.dao.RakDAO;
import com.perpustakaan.model.Rak;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.ModernTable;
import com.perpustakaan.view.components.ModernTextField;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

public class RakPanel extends JPanel {
    private RakDAO rakDAO = new RakDAO();

    // Form inputs
    private ModernTextField txtId;
    private ModernTextField txtNama;
    private ModernTextField txtLokasi;
    private ModernTextField txtKeterangan;

    // Search & Table
    private ModernTextField txtSearch;
    private ModernTable table;
    private DefaultTableModel tableModel;

    // Buttons
    private ModernButton btnSave;
    private ModernButton btnUpdate;
    private ModernButton btnDelete;
    private ModernButton btnReset;
    private ModernButton btnRefresh;

    private Runnable onChangeListener;

    public RakPanel(Runnable onChangeListener) {
        this.onChangeListener = onChangeListener;
        setOpaque(false);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        initUI();
        loadData();
        generateNewId();
    }

    private void initUI() {
        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titleGrp = new JPanel(new GridLayout(2, 1, 0, 4));
        titleGrp.setOpaque(false);
        JLabel lblTitle = new JLabel("Manajemen Data Rak Perpustakaan");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel("Atur penempatan buku, lokasi rak, dan klasifikasi ruang penyimpanan.");
        lblSub.setFont(UITheme.FONT_SUBTITLE);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);

        titleGrp.add(lblTitle);
        titleGrp.add(lblSub);
        headerPanel.add(titleGrp, BorderLayout.CENTER);

        // Search Bar & Refresh
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBar.setOpaque(false);

        txtSearch = new ModernTextField("Cari ID / Nama / Lokasi...");
        txtSearch.setPreferredSize(new Dimension(240, 38));
        txtSearch.addActionListener(e -> searchData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> searchData());

        btnRefresh = new ModernButton("Refresh", IconFactory.createIcon("refresh", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            loadData();
            resetForm();
        });

        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnRefresh);

        headerPanel.add(searchBar, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Center Split: Left = Input Form (360px), Right = Data Table
        JPanel mainContent = new JPanel(new BorderLayout(20, 0));
        mainContent.setOpaque(false);

        // 1. Form Card
        JPanel formCard = createFormCard();
        mainContent.add(formCard, BorderLayout.WEST);

        // 2. Table Container
        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setOpaque(false);

        tableModel = new DefaultTableModel(
            new String[]{"ID Rak", "Nama Rak", "Lokasi Rak", "Keterangan"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new ModernTable(tableModel);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                populateFormFromSelectedRow();
            }
        });

        tableContainer.add(ModernTable.wrap(table), BorderLayout.CENTER);
        mainContent.add(tableContainer, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createFormCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 12, 12));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(360, 420));
        card.setLayout(new BorderLayout(0, 16));
        card.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel lblFormTitle = new JLabel("Form Data Rak");
        lblFormTitle.setFont(UITheme.FONT_HEADER);
        lblFormTitle.setForeground(UITheme.TEXT_PRIMARY);
        card.add(lblFormTitle, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel();
        fieldsPanel.setOpaque(false);
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));

        txtId = new ModernTextField();
        txtId.setEditable(false);
        txtId.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtNama = new ModernTextField("Nama / kategori rak");
        txtNama.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtLokasi = new ModernTextField("Lokasi (contoh: Lantai 1 Sayap Kiri)");
        txtLokasi.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtKeterangan = new ModernTextField("Keterangan tambahan");
        txtKeterangan.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        fieldsPanel.add(createFieldLabel("ID Rak"));
        fieldsPanel.add(txtId);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Nama Rak *"));
        fieldsPanel.add(txtNama);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Lokasi Rak *"));
        fieldsPanel.add(txtLokasi);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Keterangan"));
        fieldsPanel.add(txtKeterangan);

        card.add(fieldsPanel, BorderLayout.CENTER);

        // Action Buttons Grid
        JPanel btnGrid = new JPanel(new GridLayout(2, 2, 8, 8));
        btnGrid.setOpaque(false);

        btnSave = new ModernButton("Simpan", IconFactory.createIcon("add", 14, Color.WHITE), ModernButton.Style.PRIMARY);
        btnSave.addActionListener(e -> saveData());

        btnUpdate = new ModernButton("Ubah", IconFactory.createIcon("edit", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnUpdate.setEnabled(false);
        btnUpdate.addActionListener(e -> updateData());

        btnDelete = new ModernButton("Hapus", IconFactory.createIcon("delete", 14, Color.WHITE), ModernButton.Style.DANGER);
        btnDelete.setEnabled(false);
        btnDelete.addActionListener(e -> deleteData());

        btnReset = new ModernButton("Batal / Baru", ModernButton.Style.SECONDARY);
        btnReset.addActionListener(e -> resetForm());

        btnGrid.add(btnSave);
        btnGrid.add(btnUpdate);
        btnGrid.add(btnDelete);
        btnGrid.add(btnReset);

        card.add(btnGrid, BorderLayout.SOUTH);
        return card;
    }

    private JLabel createFieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UITheme.FONT_SMALL);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    public void loadData() {
        SwingWorker<List<Rak>, Void> worker = new SwingWorker<List<Rak>, Void>() {
            @Override
            protected List<Rak> doInBackground() throws Exception {
                return rakDAO.getAll();
            }

            @Override
            protected void done() {
                try {
                    List<Rak> list = get();
                    tableModel.setRowCount(0);
                    for (Rak r : list) {
                        tableModel.addRow(new Object[]{
                            r.getIdRak(),
                            r.getNamaRak(),
                            r.getLokasiRak(),
                            r.getKeterangan() != null ? r.getKeterangan() : "-"
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(RakPanel.this,
                        "Gagal memuat data rak: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void searchData() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) {
            loadData();
            return;
        }

        SwingWorker<List<Rak>, Void> worker = new SwingWorker<List<Rak>, Void>() {
            @Override
            protected List<Rak> doInBackground() throws Exception {
                return rakDAO.search(keyword);
            }

            @Override
            protected void done() {
                try {
                    List<Rak> list = get();
                    tableModel.setRowCount(0);
                    for (Rak r : list) {
                        tableModel.addRow(new Object[]{
                            r.getIdRak(),
                            r.getNamaRak(),
                            r.getLokasiRak(),
                            r.getKeterangan()
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(RakPanel.this,
                        "Gagal mencari data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void populateFormFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row != -1) {
            String id = table.getValueAt(row, 0).toString();
            try {
                Rak r = rakDAO.getById(id);
                if (r != null) {
                    txtId.setText(r.getIdRak());
                    txtNama.setText(r.getNamaRak());
                    txtLokasi.setText(r.getLokasiRak());
                    txtKeterangan.setText(r.getKeterangan());

                    btnSave.setEnabled(false);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void saveData() {
        String nama = txtNama.getText().trim();
        String lokasi = txtLokasi.getText().trim();

        if (nama.isEmpty() || lokasi.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama rak dan lokasi wajib diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Rak r = new Rak(
            txtId.getText().trim(),
            nama,
            lokasi,
            txtKeterangan.getText().trim()
        );

        try {
            if (rakDAO.insert(r)) {
                JOptionPane.showMessageDialog(this, "Rak berhasil disimpan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                resetForm();
                if (onChangeListener != null) onChangeListener.run();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan rak: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateData() {
        String nama = txtNama.getText().trim();
        String lokasi = txtLokasi.getText().trim();

        if (nama.isEmpty() || lokasi.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama rak dan lokasi wajib diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Rak r = new Rak(
            txtId.getText().trim(),
            nama,
            lokasi,
            txtKeterangan.getText().trim()
        );

        try {
            if (rakDAO.update(r)) {
                JOptionPane.showMessageDialog(this, "Data rak berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                resetForm();
                if (onChangeListener != null) onChangeListener.run();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memperbarui rak: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteData() {
        String id = txtId.getText().trim();
        int opt = JOptionPane.showConfirmDialog(this,
            "Apakah Anda yakin ingin menghapus rak " + id + "?",
            "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (opt == JOptionPane.YES_OPTION) {
            try {
                if (rakDAO.delete(id)) {
                    JOptionPane.showMessageDialog(this, "Rak berhasil dihapus!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    loadData();
                    resetForm();
                    if (onChangeListener != null) onChangeListener.run();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus rak. Pastikan tidak ada buku yang terdaftar pada rak ini:\n" + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void resetForm() {
        generateNewId();
        txtNama.setText("");
        txtLokasi.setText("");
        txtKeterangan.setText("");
        table.clearSelection();

        btnSave.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }

    private void generateNewId() {
        try {
            txtId.setText(rakDAO.generateNextId());
        } catch (Exception e) {
            txtId.setText("RAK-001");
        }
    }
}
