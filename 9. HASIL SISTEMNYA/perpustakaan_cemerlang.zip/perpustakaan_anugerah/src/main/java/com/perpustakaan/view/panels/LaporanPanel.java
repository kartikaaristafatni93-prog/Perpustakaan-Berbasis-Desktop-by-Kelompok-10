package com.perpustakaan.view.panels;

import com.perpustakaan.dao.*;
import com.perpustakaan.model.*;
import com.perpustakaan.utils.*;
import com.perpustakaan.view.MemberCardDialog;
import com.perpustakaan.view.components.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.util.List;

public class LaporanPanel extends JPanel {
    private AnggotaDAO anggotaDAO = new AnggotaDAO();
    private BukuDAO bukuDAO = new BukuDAO();
    private PeminjamanDAO peminjamanDAO = new PeminjamanDAO();
    private PengembalianDAO pengembalianDAO = new PengembalianDAO();

    // Tab sub-panels
    private JTabbedPane tabbedPane;

    // Member Report
    private ModernTable tblAnggota;
    private DefaultTableModel mdlAnggota;
    private ModernTextField txtSearchAnggota;

    // Book Report
    private ModernTable tblBuku;
    private DefaultTableModel mdlBuku;
    private ModernTextField txtSearchBuku;

    // Borrow Report
    private ModernTable tblPinjam;
    private DefaultTableModel mdlPinjam;
    private ModernTextField txtSearchPinjam;
    private JComboBox<String> cmbFilterPinjam;

    // Return Report
    private ModernTable tblKembali;
    private DefaultTableModel mdlKembali;
    private ModernTextField txtSearchKembali;

    public LaporanPanel() {
        setOpaque(false);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        initUI();
        loadAllReports();
    }

    private void initUI() {
        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titleGrp = new JPanel(new GridLayout(2, 1, 0, 4));
        titleGrp.setOpaque(false);
        JLabel lblTitle = new JLabel("Pusat Laporan & Ekspor Dokumen");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel("Cetak laporan resmi perpustakaan dan ekspor data ke format PDF & Microsoft Excel (.xlsx).");
        lblSub.setFont(UITheme.FONT_SUBTITLE);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);

        titleGrp.add(lblTitle);
        titleGrp.add(lblSub);
        headerPanel.add(titleGrp, BorderLayout.CENTER);

        ModernButton btnRefreshAll = new ModernButton("Refresh Semua", IconFactory.createIcon("refresh", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnRefreshAll.addActionListener(e -> loadAllReports());
        headerPanel.add(btnRefreshAll, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        // Modern Tabbed Pane
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UITheme.FONT_BOLD);
        tabbedPane.setBackground(UITheme.BG_DARK);
        tabbedPane.setForeground(UITheme.TEXT_PRIMARY);

        tabbedPane.addTab("Laporan Anggota", IconFactory.createIcon("anggota", 16, UITheme.TEXT_SECONDARY), createMemberReportTab());
        tabbedPane.addTab("Laporan Buku", IconFactory.createIcon("buku", 16, UITheme.TEXT_SECONDARY), createBookReportTab());
        tabbedPane.addTab("Laporan Peminjaman", IconFactory.createIcon("peminjaman", 16, UITheme.TEXT_SECONDARY), createBorrowReportTab());
        tabbedPane.addTab("Laporan Pengembalian", IconFactory.createIcon("return", 16, UITheme.TEXT_SECONDARY), createReturnReportTab());

        add(tabbedPane, BorderLayout.CENTER);
    }

    // 1. Member Report Tab
    private JPanel createMemberReportTab() {
        JPanel p = new JPanel(new BorderLayout(0, 12));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(14, 4, 4, 4));

        // Toolbar: Search + Export Actions
        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setOpaque(false);

        JPanel leftSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        leftSearch.setOpaque(false);
        txtSearchAnggota = new ModernTextField("Cari ID / Nama anggota...");
        txtSearchAnggota.setPreferredSize(new Dimension(240, 36));
        txtSearchAnggota.addActionListener(e -> loadMemberData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 14, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> loadMemberData());
        leftSearch.add(txtSearchAnggota);
        leftSearch.add(btnSearch);

        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightActions.setOpaque(false);

        ModernButton btnPrint = new ModernButton("Cetak", IconFactory.createIcon("print", 14, Color.WHITE), ModernButton.Style.SECONDARY);
        btnPrint.addActionListener(e -> TablePrinter.printTable(tblAnggota, "Laporan Data Anggota"));

        ModernButton btnCard = new ModernButton("🖨️ Cetak Kartu Anggota", ModernButton.Style.PRIMARY);
        btnCard.addActionListener(e -> {
            int row = tblAnggota.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this,
                    "Pilih salah satu anggota di tabel terlebih dahulu untuk mencetak kartu anggota.",
                    "Pilih Anggota", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String id = (String) mdlAnggota.getValueAt(row, 0);
            try {
                Anggota a = anggotaDAO.getById(id);
                if (a != null) {
                    new MemberCardDialog(SwingUtilities.getWindowAncestor(this), a).setVisible(true);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        ModernButton btnPdf = new ModernButton("Ekspor PDF", IconFactory.createIcon("pdf", 14, Color.WHITE), ModernButton.Style.PRIMARY);
        btnPdf.addActionListener(e -> exportPdf(tblAnggota, "Laporan Data Anggota", "Laporan_Anggota.pdf"));

        ModernButton btnExcel = new ModernButton("Ekspor Excel", IconFactory.createIcon("excel", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnExcel.addActionListener(e -> exportExcel(tblAnggota, "Laporan Anggota", "Laporan_Anggota.xlsx"));

        rightActions.add(btnPrint);
        rightActions.add(btnCard);
        rightActions.add(btnPdf);
        rightActions.add(btnExcel);
        toolbar.add(leftSearch, BorderLayout.WEST);
        toolbar.add(rightActions, BorderLayout.EAST);
        p.add(toolbar, BorderLayout.NORTH);

        mdlAnggota = new DefaultTableModel(
            new String[]{"ID Anggota", "Nama Lengkap", "Jenis Kelamin", "No. Telepon", "Email", "Alamat", "Tanggal Daftar"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblAnggota = new ModernTable(mdlAnggota);
        p.add(ModernTable.wrap(tblAnggota), BorderLayout.CENTER);

        return p;
    }

    // 2. Book Report Tab
    private JPanel createBookReportTab() {
        JPanel p = new JPanel(new BorderLayout(0, 12));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(14, 4, 4, 4));

        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setOpaque(false);

        JPanel leftSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        leftSearch.setOpaque(false);
        txtSearchBuku = new ModernTextField("Cari ID / Judul / Pengarang / Kategori...");
        txtSearchBuku.setPreferredSize(new Dimension(280, 36));
        txtSearchBuku.addActionListener(e -> loadBookData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 14, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> loadBookData());
        leftSearch.add(txtSearchBuku);
        leftSearch.add(btnSearch);

        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightActions.setOpaque(false);

        ModernButton btnPrint = new ModernButton("Cetak", IconFactory.createIcon("print", 14, Color.WHITE), ModernButton.Style.SECONDARY);
        btnPrint.addActionListener(e -> TablePrinter.printTable(tblBuku, "Laporan Katalog Buku"));

        ModernButton btnPdf = new ModernButton("Ekspor PDF", IconFactory.createIcon("pdf", 14, Color.WHITE), ModernButton.Style.PRIMARY);
        btnPdf.addActionListener(e -> exportPdf(tblBuku, "Laporan Katalog Buku", "Laporan_Buku.pdf"));

        ModernButton btnExcel = new ModernButton("Ekspor Excel", IconFactory.createIcon("excel", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnExcel.addActionListener(e -> exportExcel(tblBuku, "Laporan Buku", "Laporan_Buku.xlsx"));

        rightActions.add(btnPrint);
        rightActions.add(btnPdf);
        rightActions.add(btnExcel);
        toolbar.add(leftSearch, BorderLayout.WEST);
        toolbar.add(rightActions, BorderLayout.EAST);
        p.add(toolbar, BorderLayout.NORTH);

        mdlBuku = new DefaultTableModel(
            new String[]{"ID Buku", "Judul Buku", "Pengarang", "Penerbit", "Tahun", "Kategori", "Lokasi Rak", "Total Stok", "Tersedia", "Dipinjam"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblBuku = new ModernTable(mdlBuku);
        p.add(ModernTable.wrap(tblBuku), BorderLayout.CENTER);

        return p;
    }

    // 3. Borrow Report Tab
    private JPanel createBorrowReportTab() {
        JPanel p = new JPanel(new BorderLayout(0, 12));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(14, 4, 4, 4));

        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setOpaque(false);

        JPanel leftSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        leftSearch.setOpaque(false);

        cmbFilterPinjam = new JComboBox<>(new String[]{"Semua Status", "Dipinjam", "Dikembalikan"});
        cmbFilterPinjam.setFont(UITheme.FONT_SMALL);
        cmbFilterPinjam.setBackground(UITheme.BG_INPUT);
        cmbFilterPinjam.setForeground(UITheme.TEXT_PRIMARY);
        cmbFilterPinjam.setPreferredSize(new Dimension(130, 36));
        cmbFilterPinjam.addActionListener(e -> loadBorrowData());

        txtSearchPinjam = new ModernTextField("Cari ID / Anggota / Buku / Tanggal...");
        txtSearchPinjam.setPreferredSize(new Dimension(240, 36));
        txtSearchPinjam.addActionListener(e -> loadBorrowData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 14, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> loadBorrowData());

        leftSearch.add(cmbFilterPinjam);
        leftSearch.add(txtSearchPinjam);
        leftSearch.add(btnSearch);

        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightActions.setOpaque(false);

        ModernButton btnPrint = new ModernButton("Cetak", IconFactory.createIcon("print", 14, Color.WHITE), ModernButton.Style.SECONDARY);
        btnPrint.addActionListener(e -> TablePrinter.printTable(tblPinjam, "Laporan Transaksi Peminjaman"));

        ModernButton btnPdf = new ModernButton("Ekspor PDF", IconFactory.createIcon("pdf", 14, Color.WHITE), ModernButton.Style.PRIMARY);
        btnPdf.addActionListener(e -> exportPdf(tblPinjam, "Laporan Transaksi Peminjaman", "Laporan_Peminjaman.pdf"));

        ModernButton btnExcel = new ModernButton("Ekspor Excel", IconFactory.createIcon("excel", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnExcel.addActionListener(e -> exportExcel(tblPinjam, "Laporan Peminjaman", "Laporan_Peminjaman.xlsx"));

        rightActions.add(btnPrint);
        rightActions.add(btnPdf);
        rightActions.add(btnExcel);
        toolbar.add(leftSearch, BorderLayout.WEST);
        toolbar.add(rightActions, BorderLayout.EAST);
        p.add(toolbar, BorderLayout.NORTH);

        mdlPinjam = new DefaultTableModel(
            new String[]{"ID Pinjam", "Anggota", "Judul Buku", "Petugas", "Tgl Pinjam", "Jatuh Tempo", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblPinjam = new ModernTable(mdlPinjam);
        tblPinjam.getColumnModel().getColumn(6).setCellRenderer(new StatusBadgeRenderer());
        p.add(ModernTable.wrap(tblPinjam), BorderLayout.CENTER);

        return p;
    }

    // 4. Return Report Tab
    private JPanel createReturnReportTab() {
        JPanel p = new JPanel(new BorderLayout(0, 12));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(14, 4, 4, 4));

        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setOpaque(false);

        JPanel leftSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        leftSearch.setOpaque(false);
        txtSearchKembali = new ModernTextField("Cari ID Kembali / Pinjam / Anggota / Buku...");
        txtSearchKembali.setPreferredSize(new Dimension(280, 36));
        txtSearchKembali.addActionListener(e -> loadReturnData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 14, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> loadReturnData());
        leftSearch.add(txtSearchKembali);
        leftSearch.add(btnSearch);

        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightActions.setOpaque(false);

        ModernButton btnPrint = new ModernButton("Cetak", IconFactory.createIcon("print", 14, Color.WHITE), ModernButton.Style.SECONDARY);
        btnPrint.addActionListener(e -> TablePrinter.printTable(tblKembali, "Laporan Transaksi Pengembalian"));

        ModernButton btnPdf = new ModernButton("Ekspor PDF", IconFactory.createIcon("pdf", 14, Color.WHITE), ModernButton.Style.PRIMARY);
        btnPdf.addActionListener(e -> exportPdf(tblKembali, "Laporan Transaksi Pengembalian", "Laporan_Pengembalian.pdf"));

        ModernButton btnExcel = new ModernButton("Ekspor Excel", IconFactory.createIcon("excel", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnExcel.addActionListener(e -> exportExcel(tblKembali, "Laporan Pengembalian", "Laporan_Pengembalian.xlsx"));

        rightActions.add(btnPrint);
        rightActions.add(btnPdf);
        rightActions.add(btnExcel);
        toolbar.add(leftSearch, BorderLayout.WEST);
        toolbar.add(rightActions, BorderLayout.EAST);
        p.add(toolbar, BorderLayout.NORTH);

        mdlKembali = new DefaultTableModel(
            new String[]{"ID Kembali", "ID Pinjam", "Anggota", "Judul Buku", "Tgl Pinjam", "Jatuh Tempo", "Tgl Kembali", "Terlambat", "Denda", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblKembali = new ModernTable(mdlKembali);
        tblKembali.getColumnModel().getColumn(9).setCellRenderer(new StatusBadgeRenderer());
        p.add(ModernTable.wrap(tblKembali), BorderLayout.CENTER);

        return p;
    }

    public void loadAllReports() {
        loadMemberData();
        loadBookData();
        loadBorrowData();
        loadReturnData();
    }

    public void loadMemberData() {
        String keyword = txtSearchAnggota.getText().trim();
        SwingWorker<List<Anggota>, Void> worker = new SwingWorker<List<Anggota>, Void>() {
            @Override
            protected List<Anggota> doInBackground() throws Exception {
                return keyword.isEmpty() ? anggotaDAO.getAll() : anggotaDAO.search(keyword);
            }

            @Override
            protected void done() {
                try {
                    List<Anggota> list = get();
                    mdlAnggota.setRowCount(0);
                    for (Anggota a : list) {
                        mdlAnggota.addRow(new Object[]{
                            a.getIdAnggota(),
                            a.getNamaLengkap(),
                            a.getJenisKelamin(),
                            a.getNoTelepon() != null ? a.getNoTelepon() : "-",
                            a.getEmail() != null ? a.getEmail() : "-",
                            a.getAlamat() != null ? a.getAlamat() : "-",
                            DateUtils.formatDisplay(a.getTanggalDaftar())
                        });
                    }
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    public void loadBookData() {
        String keyword = txtSearchBuku.getText().trim();
        SwingWorker<List<Buku>, Void> worker = new SwingWorker<List<Buku>, Void>() {
            @Override
            protected List<Buku> doInBackground() throws Exception {
                return keyword.isEmpty() ? bukuDAO.getAll() : bukuDAO.search(keyword);
            }

            @Override
            protected void done() {
                try {
                    List<Buku> list = get();
                    mdlBuku.setRowCount(0);
                    for (Buku b : list) {
                        mdlBuku.addRow(new Object[]{
                            b.getIdBuku(),
                            b.getJudulBuku(),
                            b.getPengarang(),
                            b.getPenerbit(),
                            b.getTahunTerbit(),
                            b.getKategori(),
                            b.getNamaRak() != null ? b.getNamaRak() : b.getIdRak(),
                            b.getTotalStok(),
                            b.getSisaStok(),
                            b.getDipinjamStok()
                        });
                    }
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    public void loadBorrowData() {
        String keyword = txtSearchPinjam.getText().trim();
        String status = (String) cmbFilterPinjam.getSelectedItem();
        if (status != null && status.startsWith("Semua")) status = null;

        String finalStatus = status;

        SwingWorker<List<Peminjaman>, Void> worker = new SwingWorker<List<Peminjaman>, Void>() {
            @Override
            protected List<Peminjaman> doInBackground() throws Exception {
                return (keyword.isEmpty() && finalStatus == null) ? peminjamanDAO.getAll() : peminjamanDAO.search(keyword, finalStatus);
            }

            @Override
            protected void done() {
                try {
                    List<Peminjaman> list = get();
                    mdlPinjam.setRowCount(0);
                    for (Peminjaman p : list) {
                        mdlPinjam.addRow(new Object[]{
                            p.getIdPeminjaman(),
                            p.getNamaAnggota(),
                            p.getJudulBuku(),
                            p.getNamaPetugas(),
                            DateUtils.formatDisplay(p.getTanggalPinjam()),
                            DateUtils.formatDisplay(p.getTanggalJatuhTempo()),
                            p.getStatusPeminjaman()
                        });
                    }
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    public void loadReturnData() {
        String keyword = txtSearchKembali.getText().trim();

        SwingWorker<List<Pengembalian>, Void> worker = new SwingWorker<List<Pengembalian>, Void>() {
            @Override
            protected List<Pengembalian> doInBackground() throws Exception {
                return keyword.isEmpty() ? pengembalianDAO.getAll() : pengembalianDAO.search(keyword);
            }

            @Override
            protected void done() {
                try {
                    List<Pengembalian> list = get();
                    mdlKembali.setRowCount(0);
                    for (Pengembalian k : list) {
                        mdlKembali.addRow(new Object[]{
                            k.getIdPengembalian(),
                            k.getIdPeminjaman(),
                            k.getNamaAnggota(),
                            k.getJudulBuku(),
                            DateUtils.formatDisplay(k.getTanggalPinjam()),
                            DateUtils.formatDisplay(k.getTanggalJatuhTempo()),
                            DateUtils.formatDisplay(k.getTanggalKembali()),
                            k.getTerlambatHari() + " Hari",
                            CurrencyUtils.formatRupiah(k.getDenda()),
                            k.getStatusPengembalian()
                        });
                    }
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    private void exportPdf(JTable table, String title, String defaultFileName) {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(defaultFileName));
        chooser.setFileFilter(new FileNameExtensionFilter("PDF Document (*.pdf)", "pdf"));

        int res = chooser.showSaveDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();
            if (!f.getName().toLowerCase().endsWith(".pdf")) {
                f = new File(f.getAbsolutePath() + ".pdf");
            }
            if (PdfExporter.exportTable(table, title, f)) {
                JOptionPane.showMessageDialog(this,
                    "Laporan PDF berhasil disimpan ke:\n" + f.getAbsolutePath(),
                    "Ekspor Berhasil", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void exportExcel(JTable table, String title, String defaultFileName) {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(defaultFileName));
        chooser.setFileFilter(new FileNameExtensionFilter("Excel Workbook (*.xlsx)", "xlsx"));

        int res = chooser.showSaveDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();
            if (!f.getName().toLowerCase().endsWith(".xlsx")) {
                f = new File(f.getAbsolutePath() + ".xlsx");
            }
            if (ExcelExporter.exportTable(table, title, f)) {
                JOptionPane.showMessageDialog(this,
                    "Laporan Excel berhasil disimpan ke:\n" + f.getAbsolutePath(),
                    "Ekspor Berhasil", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
}
