package com.perpustakaan.utils;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;

public class IconFactory {

    public static Icon createIcon(String name, int size, Color color) {
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g2.setColor(color);

        float s = size / 24.0f;
        g2.scale(s, s);
        g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        switch (name.toLowerCase()) {
            case "dashboard":
                // 4 squares dashboard icon
                g2.draw(new RoundRectangle2D.Float(3, 3, 7.5f, 7.5f, 2, 2));
                g2.draw(new RoundRectangle2D.Float(13.5f, 3, 7.5f, 7.5f, 2, 2));
                g2.draw(new RoundRectangle2D.Float(3, 13.5f, 7.5f, 7.5f, 2, 2));
                g2.draw(new RoundRectangle2D.Float(13.5f, 13.5f, 7.5f, 7.5f, 2, 2));
                break;

            case "book":
            case "buku":
                // Open book
                Path2D book = new Path2D.Float();
                book.moveTo(12, 6);
                book.curveTo(8, 4, 4, 4, 2, 5);
                book.lineTo(2, 19);
                book.curveTo(4, 18, 8, 18, 12, 20);
                book.curveTo(16, 18, 20, 18, 22, 19);
                book.lineTo(22, 5);
                book.curveTo(20, 4, 16, 4, 12, 6);
                book.closePath();
                g2.draw(book);
                g2.draw(new Line2D.Float(12, 6, 12, 20));
                break;

            case "user":
            case "users":
            case "anggota":
                // Person icon
                g2.draw(new Ellipse2D.Float(8, 3, 8, 8));
                Path2D body = new Path2D.Float();
                body.moveTo(4, 21);
                body.curveTo(4, 16, 8, 14, 12, 14);
                body.curveTo(16, 14, 20, 16, 20, 21);
                g2.draw(body);
                break;

            case "staff":
            case "petugas":
                // Badge/ID staff icon
                g2.draw(new RoundRectangle2D.Float(4, 3, 16, 18, 3, 3));
                g2.draw(new Ellipse2D.Float(9, 6, 6, 6));
                g2.draw(new Line2D.Float(7, 16, 17, 16));
                g2.draw(new Line2D.Float(9, 18, 15, 18));
                break;

            case "shelf":
            case "rak":
                // Shelf icon (stacked horizontal levels with vertical supports)
                g2.draw(new Line2D.Float(3, 7, 21, 7));
                g2.draw(new Line2D.Float(3, 13, 21, 13));
                g2.draw(new Line2D.Float(3, 19, 21, 19));
                g2.draw(new Line2D.Float(4, 3, 4, 21));
                g2.draw(new Line2D.Float(20, 3, 20, 21));
                // books standing
                g2.draw(new Line2D.Float(7, 8, 7, 12));
                g2.draw(new Line2D.Float(10, 8, 10, 12));
                g2.draw(new Line2D.Float(14, 14, 14, 18));
                break;

            case "borrow":
            case "peminjaman":
                // Arrow pointing out / book with arrow
                g2.draw(new RoundRectangle2D.Float(3, 5, 11, 15, 2, 2));
                Path2D arrOut = new Path2D.Float();
                arrOut.moveTo(13, 12);
                arrOut.lineTo(21, 12);
                arrOut.moveTo(18, 9);
                arrOut.lineTo(21, 12);
                arrOut.lineTo(18, 15);
                g2.draw(arrOut);
                break;

            case "return":
            case "pengembalian":
                // Book with arrow returning
                g2.draw(new RoundRectangle2D.Float(10, 5, 11, 15, 2, 2));
                Path2D arrIn = new Path2D.Float();
                arrIn.moveTo(11, 12);
                arrIn.lineTo(3, 12);
                arrIn.moveTo(6, 9);
                arrIn.lineTo(3, 12);
                arrIn.lineTo(6, 15);
                g2.draw(arrIn);
                break;

            case "report":
            case "laporan":
                // Document / Bar chart report icon
                g2.draw(new RoundRectangle2D.Float(4, 2, 16, 20, 2, 2));
                g2.draw(new Line2D.Float(8, 17, 8, 13));
                g2.draw(new Line2D.Float(12, 17, 12, 9));
                g2.draw(new Line2D.Float(16, 17, 16, 6));
                break;

            case "logout":
                // Door exit icon
                g2.draw(new Line2D.Float(9, 3, 4, 3));
                g2.draw(new Line2D.Float(4, 3, 4, 21));
                g2.draw(new Line2D.Float(4, 21, 9, 21));
                g2.draw(new Line2D.Float(11, 12, 20, 12));
                g2.draw(new Line2D.Float(16, 8, 20, 12));
                g2.draw(new Line2D.Float(16, 16, 20, 12));
                break;

            case "search":
                // Magnifying glass
                g2.draw(new Ellipse2D.Float(4, 4, 11, 11));
                g2.draw(new Line2D.Float(13, 13, 20, 20));
                break;

            case "add":
            case "plus":
                // Plus sign in circle
                g2.draw(new Ellipse2D.Float(3, 3, 18, 18));
                g2.draw(new Line2D.Float(12, 7, 12, 17));
                g2.draw(new Line2D.Float(7, 12, 17, 12));
                break;

            case "edit":
                // Pencil icon
                Path2D pencil = new Path2D.Float();
                pencil.moveTo(17, 3);
                pencil.lineTo(21, 7);
                pencil.lineTo(9, 19);
                pencil.lineTo(4, 20);
                pencil.lineTo(5, 15);
                pencil.closePath();
                g2.draw(pencil);
                break;

            case "delete":
            case "trash":
                // Trash can
                g2.draw(new Line2D.Float(3, 6, 21, 6));
                g2.draw(new Line2D.Float(8, 6, 8, 3));
                g2.draw(new Line2D.Float(8, 3, 16, 3));
                g2.draw(new Line2D.Float(16, 3, 16, 6));
                Path2D can = new Path2D.Float();
                can.moveTo(5, 6);
                can.lineTo(6, 20);
                can.curveTo(6, 21, 7, 21, 8, 21);
                can.lineTo(16, 21);
                can.curveTo(17, 21, 18, 21, 18, 20);
                can.lineTo(19, 6);
                g2.draw(can);
                g2.draw(new Line2D.Float(10, 10, 10, 17));
                g2.draw(new Line2D.Float(14, 10, 14, 17));
                break;

            case "refresh":
                // Circular arrows
                g2.draw(new Arc2D.Float(4, 4, 16, 16, 45, 270, Arc2D.OPEN));
                Path2D arrowHead = new Path2D.Float();
                arrowHead.moveTo(18, 4);
                arrowHead.lineTo(20, 9);
                arrowHead.lineTo(15, 9);
                arrowHead.closePath();
                g2.fill(arrowHead);
                break;

            case "excel":
                // Spreadsheet grid icon
                g2.draw(new RoundRectangle2D.Float(3, 3, 18, 18, 2, 2));
                g2.draw(new Line2D.Float(3, 9, 21, 9));
                g2.draw(new Line2D.Float(9, 3, 9, 21));
                g2.draw(new Line2D.Float(15, 9, 15, 21));
                g2.draw(new Line2D.Float(3, 15, 21, 15));
                break;

            case "pdf":
                // PDF document icon
                g2.draw(new RoundRectangle2D.Float(4, 2, 16, 20, 2, 2));
                g2.setFont(new Font("SansSerif", Font.BOLD, 7));
                g2.drawString("PDF", 5, 14);
                break;

            case "print":
                // Printer icon
                g2.draw(new RoundRectangle2D.Float(5, 7, 14, 10, 2, 2));
                g2.draw(new Line2D.Float(7, 7, 7, 3));
                g2.draw(new Line2D.Float(7, 3, 17, 3));
                g2.draw(new Line2D.Float(17, 3, 17, 7));
                g2.draw(new RoundRectangle2D.Float(7, 13, 10, 7, 1, 1));
                break;

            case "library":
                // Greek classical pillars / library temple icon
                g2.draw(new Line2D.Float(3, 8, 21, 8));
                Path2D roof = new Path2D.Float();
                roof.moveTo(2, 8);
                roof.lineTo(12, 2);
                roof.lineTo(22, 8);
                roof.closePath();
                g2.draw(roof);
                // 4 columns
                g2.draw(new Line2D.Float(5, 8, 5, 18));
                g2.draw(new Line2D.Float(9, 8, 9, 18));
                g2.draw(new Line2D.Float(15, 8, 15, 18));
                g2.draw(new Line2D.Float(19, 8, 19, 18));
                g2.draw(new Line2D.Float(2, 18, 22, 18));
                g2.draw(new Line2D.Float(1, 21, 23, 21));
                break;

            default:
                g2.draw(new RoundRectangle2D.Float(3, 3, 18, 18, 4, 4));
                break;
        }

        g2.dispose();
        return new ImageIcon(image);
    }
}
