package com.perpustakaan.dao;

import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.model.Anggota;
import com.perpustakaan.model.Petugas;
import com.perpustakaan.model.User;
import com.perpustakaan.utils.PasswordUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

    public User authenticate(String username, String plainPassword) throws SQLException {
        if (username == null || plainPassword == null) return null;

        // Ensure id_anggota column exists
        String sql = "SELECT u.id_user, u.username, u.password, u.role, u.id_petugas, u.id_anggota, u.created_at " +
                     "FROM users u WHERE u.username = ?";

        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String storedHash = rs.getString("password");
                    if (PasswordUtils.checkPassword(plainPassword, storedHash)) {
                        User user = new User();
                        user.setIdUser(rs.getInt("id_user"));
                        user.setUsername(rs.getString("username"));
                        user.setPassword(storedHash);
                        user.setRole(rs.getString("role"));
                        user.setIdPetugas(rs.getString("id_petugas"));
                        try {
                            user.setIdAnggota(rs.getString("id_anggota"));
                        } catch (Exception ignored) {}
                        user.setCreatedAt(rs.getTimestamp("created_at"));
                        return user;
                    }
                }
            }
        }
        return null;
    }

    public boolean isUsernameTaken(String username) throws SQLException {
        if (username == null) return false;
        String sql = "SELECT COUNT(*) FROM users WHERE LOWER(username) = LOWER(?)";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    public Petugas getAssociatedPetugas(String idPetugas) throws SQLException {
        if (idPetugas == null) return null;
        String sql = "SELECT * FROM petugas WHERE id_petugas = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, idPetugas);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Petugas(
                        rs.getString("id_petugas"),
                        rs.getString("nama_lengkap"),
                        rs.getString("jenis_kelamin"),
                        rs.getString("alamat"),
                        rs.getString("no_telepon"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                    );
                }
            }
        }
        return null;
    }

    public Anggota getAssociatedAnggota(String idAnggota) throws SQLException {
        if (idAnggota == null) return null;
        String sql = "SELECT * FROM anggota WHERE id_anggota = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, idAnggota);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Anggota(
                        rs.getString("id_anggota"),
                        rs.getString("nama_lengkap"),
                        rs.getString("jenis_kelamin"),
                        rs.getString("alamat"),
                        rs.getString("no_telepon"),
                        rs.getString("email"),
                        rs.getDate("tanggal_daftar")
                    );
                }
            }
        }
        return null;
    }

    /**
     * Registers a new Member and creates their user credentials atomically
     */
    public boolean registerMemberUser(Anggota anggota, String username, String plainPassword) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean autoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);

            // 1. Insert into anggota
            String sqlAnggota = "INSERT INTO anggota (id_anggota, nama_lengkap, jenis_kelamin, alamat, no_telepon, email, tanggal_daftar) " +
                                "VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement psAnggota = conn.prepareStatement(sqlAnggota)) {
                psAnggota.setString(1, anggota.getIdAnggota());
                psAnggota.setString(2, anggota.getNamaLengkap());
                psAnggota.setString(3, anggota.getJenisKelamin());
                psAnggota.setString(4, anggota.getAlamat());
                psAnggota.setString(5, anggota.getNoTelepon());
                psAnggota.setString(6, anggota.getEmail());
                psAnggota.setDate(7, anggota.getTanggalDaftar());
                psAnggota.executeUpdate();
            }

            // 2. Insert into users table
            String hashedPassword = PasswordUtils.hashPassword(plainPassword);
            String sqlUser = "INSERT INTO users (username, password, role, id_anggota) VALUES (?, ?, 'PENGGUNA', ?)";
            try (PreparedStatement psUser = conn.prepareStatement(sqlUser)) {
                psUser.setString(1, username.trim());
                psUser.setString(2, hashedPassword);
                psUser.setString(3, anggota.getIdAnggota());
                psUser.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(autoCommit);
        }
    }
}
