package com.perpustakaan.utils;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DateUtils {
    private static final SimpleDateFormat DISPLAY_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
    private static final SimpleDateFormat SQL_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    public static String formatDisplay(Date date) {
        if (date == null) return "-";
        return DISPLAY_FORMAT.format(date);
    }

    public static String formatSql(java.util.Date date) {
        if (date == null) return null;
        return SQL_FORMAT.format(date);
    }

    public static Date parseSqlDate(String str) {
        if (str == null || str.trim().isEmpty()) return null;
        try {
            return new Date(SQL_FORMAT.parse(str.trim()).getTime());
        } catch (ParseException e) {
            try {
                return new Date(DISPLAY_FORMAT.parse(str.trim()).getTime());
            } catch (ParseException ex) {
                return null;
            }
        }
    }

    public static Date today() {
        return new Date(System.currentTimeMillis());
    }

    public static Date addDays(Date date, int days) {
        if (date == null) return null;
        LocalDate local = date.toLocalDate();
        return Date.valueOf(local.plusDays(days));
    }

    public static int calculateDaysBetween(Date start, Date end) {
        if (start == null || end == null) return 0;
        LocalDate s = start.toLocalDate();
        LocalDate e = end.toLocalDate();
        long days = ChronoUnit.DAYS.between(s, e);
        return (int) days;
    }
}
