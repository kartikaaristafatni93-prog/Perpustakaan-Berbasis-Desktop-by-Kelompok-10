package com.perpustakaan.view;

import com.perpustakaan.dao.UserDAO;
import com.perpustakaan.model.Anggota;
import com.perpustakaan.model.Petugas;
import com.perpustakaan.model.User;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.utils.SessionManager;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.ModernPasswordField;
import com.perpustakaan.view.components.ModernTextField;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.RoundRectangle2D;

public class LoginFrame extends JFrame {
    private ModernTextField txtUsername;
    private ModernPasswordField txtPassword;
    private JCheckBox chkShowPassword;
    private ModernButton btnLogin;
    private ModernButton btnRegister;
    private JLabel lblError;
    private UserDAO userDAO = new UserDAO();

    public LoginFrame() {
        super("Perpustakaan Cemerlang - Masuk Sistem");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 640);
        setLocationRelativeTo(null);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Soft pastel gradient background (#F4F7FC to #EBF1F9)
                GradientPaint gp = new GradientPaint(0, 0, UITheme.BG_MAIN_TOP,
                                                     0, getHeight(), UITheme.BG_MAIN_BOTTOM);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(32, 36, 32, 36));

        // Center White Card Panel
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 18, 18));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 18, 18));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(28, 28, 26, 28));

        // 1. Library Icon & Header
        JLabel iconLabel = new JLabel(IconFactory.createIcon("library", 44, UITheme.PRIMARY));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblTitle = new JLabel("Perpustakaan Cemerlang");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSubtitle = new JLabel("Sistem Otomasi & Manajemen Perpustakaan");
        lblSubtitle.setFont(UITheme.FONT_SMALL);
        lblSubtitle.setForeground(UITheme.TEXT_SECONDARY);
        lblSubtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(iconLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(lblTitle);
        card.add(Box.createVerticalStrut(4));
        card.add(lblSubtitle);
        card.add(Box.createVerticalStrut(20));

        // 2. Error message label
        lblError = new JLabel(" ");
        lblError.setFont(UITheme.FONT_SMALL);
        lblError.setForeground(UITheme.DANGER);
        lblError.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblError);
        card.add(Box.createVerticalStrut(6));

        // 3. Username Field
        JLabel lblUser = new JLabel("Username / ID Pengguna");
        lblUser.setFont(UITheme.FONT_BOLD);
        lblUser.setForeground(UITheme.TEXT_SECONDARY);
        lblUser.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtUsername = new ModernTextField("Masukkan username");
        txtUsername.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        txtUsername.setPreferredSize(new Dimension(320, 40));
        txtUsername.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(lblUser);
        card.add(Box.createVerticalStrut(6));
        card.add(txtUsername);
        card.add(Box.createVerticalStrut(12));

        // 4. Password Field
        JLabel lblPass = new JLabel("Kata Sandi");
        lblPass.setFont(UITheme.FONT_BOLD);
        lblPass.setForeground(UITheme.TEXT_SECONDARY);
        lblPass.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtPassword = new ModernPasswordField("Masukkan kata sandi");
        txtPassword.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        txtPassword.setPreferredSize(new Dimension(320, 40));
        txtPassword.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(lblPass);
        card.add(Box.createVerticalStrut(6));
        card.add(txtPassword);
        card.add(Box.createVerticalStrut(8));

        // 5. Show/Hide Password Checkbox
        chkShowPassword = new JCheckBox("Tampilkan kata sandi");
        chkShowPassword.setFont(UITheme.FONT_SMALL);
        chkShowPassword.setForeground(UITheme.TEXT_SECONDARY);
        chkShowPassword.setOpaque(false);
        chkShowPassword.setFocusPainted(false);
        chkShowPassword.setAlignmentX(Component.LEFT_ALIGNMENT);
        chkShowPassword.addActionListener(e -> {
            if (chkShowPassword.isSelected()) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('\u2022');
            }
        });
        card.add(chkShowPassword);
        card.add(Box.createVerticalStrut(18));

        // 6. Login Button
        btnLogin = new ModernButton("Masuk ke Sistem", ModernButton.Style.PRIMARY);
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnLogin.setPreferredSize(new Dimension(320, 42));
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogin.addActionListener(e -> processLogin());

        KeyAdapter enterKeyListener = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    processLogin();
                }
            }
        };
        txtUsername.addKeyListener(enterKeyListener);
        txtPassword.addKeyListener(enterKeyListener);

        card.add(btnLogin);
        card.add(Box.createVerticalStrut(10));

        // 7. Register Button for Member Users
        btnRegister = new ModernButton("Daftar sebagai Anggota Baru", ModernButton.Style.SECONDARY);
        btnRegister.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btnRegister.setPreferredSize(new Dimension(320, 40));
        btnRegister.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnRegister.addActionListener(e -> {
            new RegisterDialog(this).setVisible(true);
        });
        card.add(btnRegister);
        card.add(Box.createVerticalStrut(12));

        // 8. DB Configuration Shortcut
        JButton btnDbConfig = new JButton("⚙ Konfigurasi Database MySQL");
        btnDbConfig.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btnDbConfig.setForeground(UITheme.TEXT_MUTED);
        btnDbConfig.setOpaque(false);
        btnDbConfig.setContentAreaFilled(false);
        btnDbConfig.setBorderPainted(false);
        btnDbConfig.setFocusPainted(false);
        btnDbConfig.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnDbConfig.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnDbConfig.addActionListener(e -> {
            new DatabaseConfigDialog(this).setVisible(true);
        });
        card.add(btnDbConfig);

        mainPanel.add(card, BorderLayout.CENTER);
        setContentPane(mainPanel);
    }

    private void processLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (username.isEmpty()) {
            showError("Silakan masukkan username.");
            txtUsername.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            showError("Silakan masukkan kata sandi.");
            txtPassword.requestFocus();
            return;
        }

        lblError.setText("Memverifikasi kredensial...");
        lblError.setForeground(UITheme.TEXT_SECONDARY);
        btnLogin.setEnabled(false);

        SwingWorker<User, Void> worker = new SwingWorker<User, Void>() {
            private String exceptionMessage = null;

            @Override
            protected User doInBackground() {
                try {
                    return userDAO.authenticate(username, password);
                } catch (Exception e) {
                    exceptionMessage = e.getMessage();
                    return null;
                }
            }

            @Override
            protected void done() {
                btnLogin.setEnabled(true);
                try {
                    User user = get();
                    if (user != null) {
                        Petugas petugas = null;
                        Anggota anggota = null;

                        if (user.getIdPetugas() != null) {
                            try {
                                petugas = userDAO.getAssociatedPetugas(user.getIdPetugas());
                            } catch (Exception ignored) {}
                        }
                        if (user.getIdAnggota() != null) {
                            try {
                                anggota = userDAO.getAssociatedAnggota(user.getIdAnggota());
                            } catch (Exception ignored) {}
                        }

                        if ("PENGGUNA".equalsIgnoreCase(user.getRole())) {
                            SessionManager.setMemberSession(user, anggota);
                        } else {
                            SessionManager.setSession(user, petugas);
                        }

                        // Launch Dashboard / MainFrame
                        dispose();
                        SwingUtilities.invokeLater(() -> {
                            new MainFrame().setVisible(true);
                        });
                    } else if (exceptionMessage != null) {
                        showError("Gagal terhubung ke MySQL: " + exceptionMessage);
                    } else {
                        showError("Username atau kata sandi tidak cocok!");
                        txtPassword.setText("");
                        txtPassword.requestFocus();
                    }
                } catch (Exception e) {
                    showError("Terjadi kesalahan sistem: " + e.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void showError(String msg) {
        lblError.setText(msg);
        lblError.setForeground(UITheme.DANGER);
    }
}
