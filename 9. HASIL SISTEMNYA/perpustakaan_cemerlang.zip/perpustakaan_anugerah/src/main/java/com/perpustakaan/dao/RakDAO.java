package com.perpustakaan.dao;

import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.model.Rak;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RakDAO {

    public List<Rak> getAll() throws SQLException {
        List<Rak> list = new ArrayList<>();
        String sql = "SELECT * FROM rak ORDER BY id_rak ASC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    public Rak getById(String id) throws SQLException {
        String sql = "SELECT * FROM rak WHERE id_rak = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSet(rs);
                }
            }
        }
        return null;
    }

    public List<Rak> search(String keyword) throws SQLException {
        List<Rak> list = new ArrayList<>();
        String sql = "SELECT * FROM rak WHERE id_rak LIKE ? OR nama_rak LIKE ? OR lokasi_rak LIKE ? ORDER BY id_rak ASC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String param = "%" + keyword + "%";
            ps.setString(1, param);
            ps.setString(2, param);
            ps.setString(3, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    public boolean insert(Rak r) throws SQLException {
        String sql = "INSERT INTO rak (id_rak, nama_rak, lokasi_rak, keterangan) VALUES (?, ?, ?, ?)";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, r.getIdRak());
            ps.setString(2, r.getNamaRak());
            ps.setString(3, r.getLokasiRak());
            ps.setString(4, r.getKeterangan());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(Rak r) throws SQLException {
        String sql = "UPDATE rak SET nama_rak = ?, lokasi_rak = ?, keterangan = ? WHERE id_rak = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, r.getNamaRak());
            ps.setString(2, r.getLokasiRak());
            ps.setString(3, r.getKeterangan());
            ps.setString(4, r.getIdRak());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(String id) throws SQLException {
        String sql = "DELETE FROM rak WHERE id_rak = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextId() throws SQLException {
        String sql = "SELECT id_rak FROM rak WHERE id_rak LIKE 'RAK-%' ORDER BY id_rak DESC LIMIT 1";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String lastId = rs.getString("id_rak");
                try {
                    int num = Integer.parseInt(lastId.substring(4));
                    return String.format("RAK-%03d", num + 1);
                } catch (Exception e) {}
            }
        }
        return "RAK-001";
    }

    private Rak mapResultSet(ResultSet rs) throws SQLException {
        return new Rak(
            rs.getString("id_rak"),
            rs.getString("nama_rak"),
            rs.getString("lokasi_rak"),
            rs.getString("keterangan")
        );
    }
}
