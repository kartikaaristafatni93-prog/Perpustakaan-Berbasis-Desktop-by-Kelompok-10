package com.perpustakaan.view.components;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.LinkedHashMap;
import java.util.Map;

public class ActivityChartPanel extends JPanel {
    private Map<String, int[]> data = new LinkedHashMap<>();

    public ActivityChartPanel() {
        setOpaque(false);
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setPreferredSize(new Dimension(500, 260));
    }

    public void setData(Map<String, int[]> data) {
        this.data = data != null ? data : new LinkedHashMap<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Card container background (White SaaS Card)
        g2.setColor(UITheme.BG_CARD);
        g2.fill(new RoundRectangle2D.Float(0, 0, width, height, 12, 12));
        g2.setColor(UITheme.BORDER);
        g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, width - 1, height - 1, 12, 12));

        // Header: Title & Legend
        g2.setFont(UITheme.FONT_HEADER);
        g2.setColor(UITheme.TEXT_PRIMARY);
        g2.drawString("Tren Aktivitas Peminjaman & Pengembalian", 20, 32);

        // Legend: Peminjaman (Blue #3478E5) & Pengembalian (Emerald #36B879)
        int legendX = width - 260;
        int legendY = 22;

        g2.setColor(UITheme.PRIMARY);
        g2.fill(new RoundRectangle2D.Float(legendX, legendY, 12, 12, 3, 3));
        g2.setFont(UITheme.FONT_SMALL);
        g2.setColor(UITheme.TEXT_SECONDARY);
        g2.drawString("Peminjaman", legendX + 16, legendY + 10);

        g2.setColor(UITheme.SUCCESS);
        g2.fill(new RoundRectangle2D.Float(legendX + 110, legendY, 12, 12, 3, 3));
        g2.setColor(UITheme.TEXT_SECONDARY);
        g2.drawString("Pengembalian", legendX + 126, legendY + 10);

        // Chart plot area
        int padLeft = 45;
        int padRight = 25;
        int padTop = 60;
        int padBottom = 40;

        int plotW = width - padLeft - padRight;
        int plotH = height - padTop - padBottom;

        if (plotW <= 0 || plotH <= 0) {
            g2.dispose();
            return;
        }

        // Determine max value
        int maxVal = 5;
        for (int[] counts : data.values()) {
            if (counts[0] > maxVal) maxVal = counts[0];
            if (counts[1] > maxVal) maxVal = counts[1];
        }
        maxVal = ((maxVal + 4) / 5) * 5; // round to multiple of 5

        // Horizontal grid lines
        int steps = 5;
        g2.setFont(UITheme.FONT_SMALL);
        for (int i = 0; i <= steps; i++) {
            int y = padTop + plotH - (i * plotH / steps);
            int val = i * maxVal / steps;

            g2.setColor(new Color(0xEE, 0xF2, 0xF6));
            g2.drawLine(padLeft, y, width - padRight, y);

            g2.setColor(UITheme.TEXT_MUTED);
            String label = String.valueOf(val);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(label, padLeft - fm.stringWidth(label) - 8, y + 4);
        }

        if (data.isEmpty()) {
            g2.setColor(UITheme.TEXT_MUTED);
            g2.drawString("Belum ada data aktivitas transaksi", width / 2 - 90, height / 2 + 10);
            g2.dispose();
            return;
        }

        // Draw bars
        int n = data.size();
        int groupWidth = plotW / n;
        int barWidth = Math.max(8, Math.min(22, (groupWidth - 20) / 2));
        int barGap = 4;

        int idx = 0;
        for (Map.Entry<String, int[]> entry : data.entrySet()) {
            String month = entry.getKey();
            int pinjamCount = entry.getValue()[0];
            int kembaliCount = entry.getValue()[1];

            int groupCenterX = padLeft + (idx * groupWidth) + (groupWidth / 2);

            // Bar 1: Pinjam
            int h1 = (int) (((double) pinjamCount / maxVal) * plotH);
            int x1 = groupCenterX - barWidth - (barGap / 2);
            int y1 = padTop + plotH - h1;

            g2.setColor(UITheme.PRIMARY);
            g2.fill(new RoundRectangle2D.Float(x1, y1, barWidth, h1, 4, 4));

            // Bar 2: Kembali
            int h2 = (int) (((double) kembaliCount / maxVal) * plotH);
            int x2 = groupCenterX + (barGap / 2);
            int y2 = padTop + plotH - h2;

            g2.setColor(UITheme.SUCCESS);
            g2.fill(new RoundRectangle2D.Float(x2, y2, barWidth, h2, 4, 4));

            // X-Axis Month label
            g2.setColor(UITheme.TEXT_SECONDARY);
            FontMetrics fm = g2.getFontMetrics();
            int lblW = fm.stringWidth(month);
            g2.drawString(month, groupCenterX - (lblW / 2), padTop + plotH + 20);

            idx++;
        }

        g2.dispose();
        super.paintComponent(g);
    }
}
