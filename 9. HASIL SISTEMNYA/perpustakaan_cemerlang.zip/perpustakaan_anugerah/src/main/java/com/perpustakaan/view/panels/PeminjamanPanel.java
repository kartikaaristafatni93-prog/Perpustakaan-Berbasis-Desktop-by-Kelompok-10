package com.perpustakaan.view.panels;

import com.perpustakaan.dao.AnggotaDAO;
import com.perpustakaan.dao.BukuDAO;
import com.perpustakaan.dao.PeminjamanDAO;
import com.perpustakaan.model.Anggota;
import com.perpustakaan.model.Buku;
import com.perpustakaan.model.Peminjaman;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.utils.SessionManager;
import com.perpustakaan.view.ReceiptDialog;
import com.perpustakaan.view.components.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.Date;
import java.util.List;

public class PeminjamanPanel extends JPanel {
    private PeminjamanDAO peminjamanDAO = new PeminjamanDAO();
    private AnggotaDAO anggotaDAO = new AnggotaDAO();
    private BukuDAO bukuDAO = new BukuDAO();

    // Form inputs
    private ModernTextField txtId;
    private JComboBox<AnggotaItem> cmbAnggota;
    private JComboBox<BukuItem> cmbBuku;
    private ModernTextField txtPetugas;
    private ModernTextField txtTanggalPinjam;
    private ModernTextField txtTanggalJatuhTempo;
    private JComboBox<String> cmbStatus;

    // Search & Filter & Table
    private ModernTextField txtSearch;
    private JComboBox<String> cmbFilterStatus;
    private ModernTable table;
    private DefaultTableModel tableModel;

    // Buttons
    private ModernButton btnSave;
    private ModernButton btnUpdate;
    private ModernButton btnDelete;
    private ModernButton btnReset;
    private ModernButton btnRefresh;

    private Runnable onChangeListener;

    public static class AnggotaItem {
        private String id;
        private String name;

        public AnggotaItem(String id, String name) {
            this.id = id;
            this.name = name;
        }

        public String getId() { return id; }
        public String getName() { return name; }

        @Override
        public String toString() {
            return id + " - " + name;
        }
    }

    public static class BukuItem {
        private String id;
        private String title;
        private int sisaStok;

        public BukuItem(String id, String title, int sisaStok) {
            this.id = id;
            this.title = title;
            this.sisaStok = sisaStok;
        }

        public String getId() { return id; }
        public String getTitle() { return title; }
        public int getSisaStok() { return sisaStok; }

        @Override
        public String toString() {
            return id + " - " + title + " (Sisa: " + sisaStok + ")";
        }
    }

    public PeminjamanPanel(Runnable onChangeListener) {
        this.onChangeListener = onChangeListener;
        setOpaque(false);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        initUI();
        loadDropdowns();
        loadData();
        generateNewId();
    }

    private void initUI() {
        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titleGrp = new JPanel(new GridLayout(2, 1, 0, 4));
        titleGrp.setOpaque(false);
        JLabel lblTitle = new JLabel("Transaksi Peminjaman Buku");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel("Pencatatan sirkulasi peminjaman buku, batas pengembalian, dan validasi stok otomatis.");
        lblSub.setFont(UITheme.FONT_SUBTITLE);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);

        titleGrp.add(lblTitle);
        titleGrp.add(lblSub);
        headerPanel.add(titleGrp, BorderLayout.CENTER);

        // Search Bar & Filter on Header Right
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBar.setOpaque(false);

        cmbFilterStatus = new JComboBox<>(new String[]{"Semua Status", "Dipinjam", "Dikembalikan"});
        cmbFilterStatus.setFont(UITheme.FONT_SMALL);
        cmbFilterStatus.setBackground(UITheme.BG_INPUT);
        cmbFilterStatus.setForeground(UITheme.TEXT_PRIMARY);
        cmbFilterStatus.setPreferredSize(new Dimension(130, 38));
        java.awt.event.ActionListener filterStatusListener = e -> searchData();
        cmbFilterStatus.addActionListener(filterStatusListener);

        txtSearch = new ModernTextField("Cari ID / Anggota / Buku...");
        txtSearch.setPreferredSize(new Dimension(220, 38));
        txtSearch.addActionListener(e -> searchData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> searchData());

        btnRefresh = new ModernButton("Refresh", IconFactory.createIcon("refresh", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            cmbFilterStatus.removeActionListener(filterStatusListener);
            cmbFilterStatus.setSelectedIndex(0);
            cmbFilterStatus.addActionListener(filterStatusListener);
            loadDropdowns();
            loadData();
            resetForm();
        });

        ModernButton btnCetakStruk = new ModernButton("🖨️ Cetak Struk", ModernButton.Style.PRIMARY);
        btnCetakStruk.addActionListener(e -> cetakStrukTerpilih());

        searchBar.add(cmbFilterStatus);
        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnRefresh);
        searchBar.add(btnCetakStruk);

        headerPanel.add(searchBar, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Center Split: Left = Input Form (380px), Right = Data Table
        JPanel mainContent = new JPanel(new BorderLayout(20, 0));
        mainContent.setOpaque(false);

        // 1. Form Card
        JPanel formCard = createFormCard();
        mainContent.add(formCard, BorderLayout.WEST);

        // 2. Table Container
        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setOpaque(false);

        tableModel = new DefaultTableModel(
            new String[]{"ID Pinjam", "Anggota", "Judul Buku", "Petugas", "Tgl Pinjam", "Jatuh Tempo", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new ModernTable(tableModel);
        table.getColumnModel().getColumn(6).setCellRenderer(new StatusBadgeRenderer());
        table.getColumnModel().getColumn(0).setPreferredWidth(120);
        table.getColumnModel().getColumn(1).setPreferredWidth(130);
        table.getColumnModel().getColumn(2).setPreferredWidth(170);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                populateFormFromSelectedRow();
            }
        });

        tableContainer.add(ModernTable.wrap(table), BorderLayout.CENTER);
        mainContent.add(tableContainer, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createFormCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 12, 12));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(380, 520));
        card.setLayout(new BorderLayout(0, 16));
        card.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel lblFormTitle = new JLabel("Form Peminjaman Buku");
        lblFormTitle.setFont(UITheme.FONT_HEADER);
        lblFormTitle.setForeground(UITheme.TEXT_PRIMARY);
        card.add(lblFormTitle, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel();
        fieldsPanel.setOpaque(false);
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));

        txtId = new ModernTextField();
        txtId.setEditable(false);
        txtId.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        cmbAnggota = new JComboBox<>();
        cmbAnggota.setFont(UITheme.FONT_REGULAR);
        cmbAnggota.setBackground(UITheme.BG_INPUT);
        cmbAnggota.setForeground(UITheme.TEXT_PRIMARY);
        cmbAnggota.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        cmbBuku = new JComboBox<>();
        cmbBuku.setFont(UITheme.FONT_REGULAR);
        cmbBuku.setBackground(UITheme.BG_INPUT);
        cmbBuku.setForeground(UITheme.TEXT_PRIMARY);
        cmbBuku.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtPetugas = new ModernTextField();
        txtPetugas.setEditable(false);
        txtPetugas.setText(SessionManager.getLoggedStaffId() + " - " + SessionManager.getLoggedStaffName());
        txtPetugas.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtTanggalPinjam = new ModernTextField("YYYY-MM-DD");
        txtTanggalPinjam.setText(DateUtils.formatSql(DateUtils.today()));
        txtTanggalPinjam.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        txtTanggalJatuhTempo = new ModernTextField("YYYY-MM-DD");
        txtTanggalJatuhTempo.setText(DateUtils.formatSql(DateUtils.addDays(DateUtils.today(), 7)));
        txtTanggalJatuhTempo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        cmbStatus = new JComboBox<>(new String[]{"Dipinjam", "Dikembalikan"});
        cmbStatus.setFont(UITheme.FONT_REGULAR);
        cmbStatus.setBackground(UITheme.BG_INPUT);
        cmbStatus.setForeground(UITheme.TEXT_PRIMARY);
        cmbStatus.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        fieldsPanel.add(createFieldLabel("ID Peminjaman"));
        fieldsPanel.add(txtId);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Pilih Anggota Peminjam *"));
        fieldsPanel.add(cmbAnggota);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Pilih Buku (Stok Tersedia) *"));
        fieldsPanel.add(cmbBuku);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Petugas Pencatat"));
        fieldsPanel.add(txtPetugas);
        fieldsPanel.add(Box.createVerticalStrut(10));

        // Two dates side-by-side
        JPanel dateRow = new JPanel(new GridLayout(1, 2, 8, 0));
        dateRow.setOpaque(false);
        dateRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        JPanel pnlPjm = new JPanel(new BorderLayout(0, 4));
        pnlPjm.setOpaque(false);
        pnlPjm.add(createFieldLabel("Tanggal Pinjam *"), BorderLayout.NORTH);
        pnlPjm.add(txtTanggalPinjam, BorderLayout.CENTER);

        JPanel pnlJth = new JPanel(new BorderLayout(0, 4));
        pnlJth.setOpaque(false);
        pnlJth.add(createFieldLabel("Jatuh Tempo (+7) *"), BorderLayout.NORTH);
        pnlJth.add(txtTanggalJatuhTempo, BorderLayout.CENTER);

        dateRow.add(pnlPjm);
        dateRow.add(pnlJth);
        fieldsPanel.add(dateRow);
        fieldsPanel.add(Box.createVerticalStrut(10));

        fieldsPanel.add(createFieldLabel("Status Peminjaman"));
        fieldsPanel.add(cmbStatus);

        card.add(fieldsPanel, BorderLayout.CENTER);

        // Action Buttons Grid
        JPanel btnGrid = new JPanel(new GridLayout(2, 2, 8, 8));
        btnGrid.setOpaque(false);

        btnSave = new ModernButton("Simpan Pinjam", IconFactory.createIcon("add", 14, Color.WHITE), ModernButton.Style.PRIMARY);
        btnSave.addActionListener(e -> saveData());

        btnUpdate = new ModernButton("Ubah", IconFactory.createIcon("edit", 14, Color.WHITE), ModernButton.Style.SUCCESS);
        btnUpdate.setEnabled(false);
        btnUpdate.addActionListener(e -> updateData());

        btnDelete = new ModernButton("Hapus", IconFactory.createIcon("delete", 14, Color.WHITE), ModernButton.Style.DANGER);
        btnDelete.setEnabled(false);
        btnDelete.addActionListener(e -> deleteData());

        btnReset = new ModernButton("Batal / Baru", ModernButton.Style.SECONDARY);
        btnReset.addActionListener(e -> resetForm());

        btnGrid.add(btnSave);
        btnGrid.add(btnUpdate);
        btnGrid.add(btnDelete);
        btnGrid.add(btnReset);

        card.add(btnGrid, BorderLayout.SOUTH);
        return card;
    }

    private JLabel createFieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UITheme.FONT_SMALL);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    public void loadDropdowns() {
        cmbAnggota.removeAllItems();
        try {
            List<Anggota> members = anggotaDAO.getAll();
            for (Anggota a : members) {
                cmbAnggota.addItem(new AnggotaItem(a.getIdAnggota(), a.getNamaLengkap()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        cmbBuku.removeAllItems();
        try {
            List<Buku> books = bukuDAO.getAll();
            for (Buku b : books) {
                cmbBuku.addItem(new BukuItem(b.getIdBuku(), b.getJudulBuku(), b.getSisaStok()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        txtPetugas.setText(SessionManager.getLoggedStaffId() + " - " + SessionManager.getLoggedStaffName());
    }

    public void loadData() {
        SwingWorker<List<Peminjaman>, Void> worker = new SwingWorker<List<Peminjaman>, Void>() {
            @Override
            protected List<Peminjaman> doInBackground() throws Exception {
                return peminjamanDAO.getAll();
            }

            @Override
            protected void done() {
                try {
                    List<Peminjaman> list = get();
                    tableModel.setRowCount(0);
                    for (Peminjaman p : list) {
                        tableModel.addRow(new Object[]{
                            p.getIdPeminjaman(),
                            p.getNamaAnggota(),
                            p.getJudulBuku(),
                            p.getNamaPetugas(),
                            DateUtils.formatDisplay(p.getTanggalPinjam()),
                            DateUtils.formatDisplay(p.getTanggalJatuhTempo()),
                            p.getStatusPeminjaman()
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(PeminjamanPanel.this,
                        "Gagal memuat transaksi peminjaman: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void searchData() {
        String keyword = txtSearch.getText().trim();
        String statusFilter = (String) cmbFilterStatus.getSelectedItem();
        if (statusFilter != null && statusFilter.startsWith("Semua")) {
            statusFilter = null;
        }

        String finalStatusFilter = statusFilter;

        SwingWorker<List<Peminjaman>, Void> worker = new SwingWorker<List<Peminjaman>, Void>() {
            @Override
            protected List<Peminjaman> doInBackground() throws Exception {
                return peminjamanDAO.search(keyword, finalStatusFilter);
            }

            @Override
            protected void done() {
                try {
                    List<Peminjaman> list = get();
                    tableModel.setRowCount(0);
                    for (Peminjaman p : list) {
                        tableModel.addRow(new Object[]{
                            p.getIdPeminjaman(),
                            p.getNamaAnggota(),
                            p.getJudulBuku(),
                            p.getNamaPetugas(),
                            DateUtils.formatDisplay(p.getTanggalPinjam()),
                            DateUtils.formatDisplay(p.getTanggalJatuhTempo()),
                            p.getStatusPeminjaman()
                        });
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(PeminjamanPanel.this,
                        "Gagal mencari transaksi: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void populateFormFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row != -1) {
            String id = table.getValueAt(row, 0).toString();
            try {
                Peminjaman p = peminjamanDAO.getById(id);
                if (p != null) {
                    txtId.setText(p.getIdPeminjaman());

                    for (int i = 0; i < cmbAnggota.getItemCount(); i++) {
                        if (cmbAnggota.getItemAt(i).getId().equals(p.getIdAnggota())) {
                            cmbAnggota.setSelectedIndex(i);
                            break;
                        }
                    }

                    for (int i = 0; i < cmbBuku.getItemCount(); i++) {
                        if (cmbBuku.getItemAt(i).getId().equals(p.getIdBuku())) {
                            cmbBuku.setSelectedIndex(i);
                            break;
                        }
                    }

                    txtPetugas.setText(p.getIdPetugas() + " - " + p.getNamaPetugas());
                    txtTanggalPinjam.setText(DateUtils.formatSql(p.getTanggalPinjam()));
                    txtTanggalJatuhTempo.setText(DateUtils.formatSql(p.getTanggalJatuhTempo()));
                    cmbStatus.setSelectedItem(p.getStatusPeminjaman());

                    btnSave.setEnabled(false);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void saveData() {
        AnggotaItem anggota = (AnggotaItem) cmbAnggota.getSelectedItem();
        BukuItem buku = (BukuItem) cmbBuku.getSelectedItem();

        if (anggota == null || buku == null) {
            JOptionPane.showMessageDialog(this, "Anggota dan Buku wajib dipilih!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (buku.getSisaStok() <= 0) {
            JOptionPane.showMessageDialog(this,
                "Stok buku \"" + buku.title + "\" habis (0 tersedia)!\nPeminjaman tidak dapat dilakukan.",
                "Stok Tidak Tersedia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Date tglPinjam = DateUtils.parseSqlDate(txtTanggalPinjam.getText());
        Date tglTempo = DateUtils.parseSqlDate(txtTanggalJatuhTempo.getText());

        if (tglPinjam == null || tglTempo == null) {
            JOptionPane.showMessageDialog(this, "Format tanggal tidak valid (gunakan YYYY-MM-DD).", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Peminjaman p = new Peminjaman(
            txtId.getText().trim(),
            anggota.getId(),
            buku.getId(),
            SessionManager.getLoggedStaffId(),
            tglPinjam,
            tglTempo,
            (String) cmbStatus.getSelectedItem()
        );

        try {
            if (peminjamanDAO.insert(p)) {
                int optPrint = JOptionPane.showConfirmDialog(this,
                    "Transaksi peminjaman berhasil disimpan!\nStok buku otomatis berkurang 1.\n\nApakah Anda ingin mencetak struk bukti peminjaman sekarang?",
                    "Cetak Struk Transaksi", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (optPrint == JOptionPane.YES_OPTION) {
                    p.setNamaAnggota(anggota.getName());
                    p.setJudulBuku(buku.getTitle());
                    new ReceiptDialog(SwingUtilities.getWindowAncestor(this), p).setVisible(true);
                }
                loadDropdowns();
                resetForm();
                if (onChangeListener != null) {
                    onChangeListener.run();
                } else {
                    loadData();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan peminjaman: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateData() {
        AnggotaItem anggota = (AnggotaItem) cmbAnggota.getSelectedItem();
        BukuItem buku = (BukuItem) cmbBuku.getSelectedItem();

        if (anggota == null || buku == null) {
            JOptionPane.showMessageDialog(this, "Anggota dan Buku wajib dipilih!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Date tglPinjam = DateUtils.parseSqlDate(txtTanggalPinjam.getText());
        Date tglTempo = DateUtils.parseSqlDate(txtTanggalJatuhTempo.getText());

        if (tglPinjam == null || tglTempo == null) {
            JOptionPane.showMessageDialog(this, "Format tanggal tidak valid.", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Peminjaman p = new Peminjaman(
            txtId.getText().trim(),
            anggota.getId(),
            buku.getId(),
            SessionManager.getLoggedStaffId(),
            tglPinjam,
            tglTempo,
            (String) cmbStatus.getSelectedItem()
        );

        try {
            if (peminjamanDAO.update(p)) {
                JOptionPane.showMessageDialog(this, "Data peminjaman berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadDropdowns();
                resetForm();
                if (onChangeListener != null) {
                    onChangeListener.run();
                } else {
                    loadData();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memperbarui peminjaman: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteData() {
        String id = txtId.getText().trim();
        int opt = JOptionPane.showConfirmDialog(this,
            "Apakah Anda yakin ingin menghapus transaksi peminjaman " + id + "?\nJika status 'Dipinjam', stok buku akan dikembalikan otomatis.",
            "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (opt == JOptionPane.YES_OPTION) {
            try {
                if (peminjamanDAO.delete(id)) {
                    JOptionPane.showMessageDialog(this, "Transaksi peminjaman berhasil dihapus!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    loadDropdowns();
                    resetForm();
                    if (onChangeListener != null) {
                        onChangeListener.run();
                    } else {
                        loadData();
                    }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus transaksi: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void resetForm() {
        generateNewId();
        if (cmbAnggota.getItemCount() > 0) cmbAnggota.setSelectedIndex(0);
        if (cmbBuku.getItemCount() > 0) cmbBuku.setSelectedIndex(0);
        txtPetugas.setText(SessionManager.getLoggedStaffId() + " - " + SessionManager.getLoggedStaffName());
        txtTanggalPinjam.setText(DateUtils.formatSql(DateUtils.today()));
        txtTanggalJatuhTempo.setText(DateUtils.formatSql(DateUtils.addDays(DateUtils.today(), 7)));
        cmbStatus.setSelectedIndex(0);
        table.clearSelection();

        btnSave.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }

    private void generateNewId() {
        try {
            txtId.setText(peminjamanDAO.generateNextId());
        } catch (Exception e) {
            txtId.setText("PJM-0001");
        }
    }

    private void cetakStrukTerpilih() {
        int row = table.getSelectedRow();
        String id = row != -1 ? table.getValueAt(row, 0).toString() : txtId.getText().trim();

        if (id == null || id.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Silakan pilih transaksi peminjaman pada tabel untuk mencetak struk.",
                "Pilih Transaksi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Peminjaman p = peminjamanDAO.getById(id);
            if (p != null) {
                new ReceiptDialog(SwingUtilities.getWindowAncestor(this), p).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Transaksi peminjaman tidak ditemukan di database.",
                    "Peringatan", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error saat memuat data struk: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
