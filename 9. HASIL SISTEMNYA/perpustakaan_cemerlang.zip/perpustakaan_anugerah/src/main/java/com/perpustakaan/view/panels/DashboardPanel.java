package com.perpustakaan.view.panels;

import com.perpustakaan.dao.DashboardDAO;
import com.perpustakaan.model.DashboardStats;
import com.perpustakaan.model.Peminjaman;
import com.perpustakaan.model.Pengembalian;
import com.perpustakaan.utils.CurrencyUtils;
import com.perpustakaan.utils.DateUtils;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.view.components.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class DashboardPanel extends JPanel {
    private DashboardDAO dashboardDAO = new DashboardDAO();

    // Summary Cards
    private StatCard cardTotalBuku;
    private StatCard cardBukuTersedia;
    private StatCard cardBukuDipinjam;
    private StatCard cardTotalAnggota;
    private StatCard cardTotalPetugas;
    private StatCard cardTotalRak;

    // Activity Chart
    private ActivityChartPanel chartPanel;

    // Recent Tables
    private ModernTable tableBorrowings;
    private DefaultTableModel modelBorrowings;
    private ModernTable tableReturns;
    private DefaultTableModel modelReturns;

    public DashboardPanel() {
        setOpaque(false);
        setLayout(new BorderLayout(0, 20));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        initUI();
        refreshData();
    }

    private void initUI() {
        // Top Header with Refresh Button
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titleGrp = new JPanel(new GridLayout(2, 1, 0, 4));
        titleGrp.setOpaque(false);
        JLabel lblTitle = new JLabel("Ringkasan & Statistik Perpustakaan");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel("Pantau sirkulasi buku, anggota, dan aktivitas peminjaman secara langsung.");
        lblSub.setFont(UITheme.FONT_SUBTITLE);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);

        titleGrp.add(lblTitle);
        titleGrp.add(lblSub);
        headerPanel.add(titleGrp, BorderLayout.CENTER);

        ModernButton btnRefresh = new ModernButton("Perbarui Data", IconFactory.createIcon("refresh", 16, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnRefresh.addActionListener(e -> refreshData());
        headerPanel.add(btnRefresh, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        // Scrollable content area
        JPanel contentPanel = new JPanel();
        contentPanel.setOpaque(false);
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        // 1. Grid of 6 Stat Cards
        JPanel cardsGrid = new JPanel(new GridLayout(2, 3, 16, 16));
        cardsGrid.setOpaque(false);
        cardsGrid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));

        cardTotalBuku = new StatCard("TOTAL BUKU", "0", "Total eksemplar terdaftar", "buku", UITheme.PRIMARY);
        cardBukuTersedia = new StatCard("BUKU TERSEDIA", "0", "Siap untuk dipinjam", "buku", UITheme.SUCCESS);
        cardBukuDipinjam = new StatCard("BUKU DIPINJAM", "0", "Sedang dalam sirkulasi", "peminjaman", UITheme.WARNING);
        cardTotalAnggota = new StatCard("TOTAL ANGGOTA", "0", "Anggota aktif perpustakaan", "anggota", UITheme.ACCENT_CYAN);
        cardTotalPetugas = new StatCard("TOTAL PETUGAS", "0", "Staff & admin pengelola", "petugas", UITheme.TEXT_SECONDARY);
        cardTotalRak = new StatCard("TOTAL RAK BUKU", "0", "Kategori & lokasi rak", "rak", UITheme.ACCENT_PURPLE);

        cardsGrid.add(cardTotalBuku);
        cardsGrid.add(cardBukuTersedia);
        cardsGrid.add(cardBukuDipinjam);
        cardsGrid.add(cardTotalAnggota);
        cardsGrid.add(cardTotalPetugas);
        cardsGrid.add(cardTotalRak);

        contentPanel.add(cardsGrid);
        contentPanel.add(Box.createVerticalStrut(20));

        // 2. Activity Chart Panel
        chartPanel = new ActivityChartPanel();
        chartPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 260));
        contentPanel.add(chartPanel);
        contentPanel.add(Box.createVerticalStrut(20));

        // 3. Two side-by-side recent tables
        JPanel tablesGrid = new JPanel(new GridLayout(1, 2, 16, 0));
        tablesGrid.setOpaque(false);
        tablesGrid.setPreferredSize(new Dimension(800, 260));

        // Left Table: Recent Borrowings
        JPanel pnlRecentBorrows = createTableContainer("Peminjaman Terbaru", "buku");
        modelBorrowings = new DefaultTableModel(new String[]{"ID Pinjam", "Anggota", "Judul Buku", "Tgl Pinjam", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tableBorrowings = new ModernTable(modelBorrowings);
        tableBorrowings.getColumnModel().getColumn(4).setCellRenderer(new StatusBadgeRenderer());
        tableBorrowings.getColumnModel().getColumn(0).setPreferredWidth(90);
        tableBorrowings.getColumnModel().getColumn(1).setPreferredWidth(100);
        tableBorrowings.getColumnModel().getColumn(2).setPreferredWidth(130);
        pnlRecentBorrows.add(ModernTable.wrap(tableBorrowings), BorderLayout.CENTER);

        // Right Table: Recent Returns
        JPanel pnlRecentReturns = createTableContainer("Pengembalian Terbaru", "return");
        modelReturns = new DefaultTableModel(new String[]{"ID Kembali", "Peminjam", "Judul Buku", "Tgl Kembali", "Denda"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tableReturns = new ModernTable(modelReturns);
        tableReturns.getColumnModel().getColumn(0).setPreferredWidth(90);
        tableReturns.getColumnModel().getColumn(1).setPreferredWidth(100);
        tableReturns.getColumnModel().getColumn(2).setPreferredWidth(130);
        pnlRecentReturns.add(ModernTable.wrap(tableReturns), BorderLayout.CENTER);

        tablesGrid.add(pnlRecentBorrows);
        tablesGrid.add(pnlRecentReturns);
        contentPanel.add(tablesGrid);

        JScrollPane scroll = new JScrollPane(contentPanel);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        add(scroll, BorderLayout.CENTER);
    }

    private JPanel createTableContainer(String title, String iconName) {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setOpaque(false);

        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        header.setOpaque(false);
        JLabel icon = new JLabel(IconFactory.createIcon(iconName, 18, UITheme.TEXT_SECONDARY));
        JLabel lbl = new JLabel(title);
        lbl.setFont(UITheme.FONT_HEADER);
        lbl.setForeground(UITheme.TEXT_PRIMARY);
        header.add(icon);
        header.add(lbl);

        p.add(header, BorderLayout.NORTH);
        return p;
    }

    public void refreshData() {
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            private DashboardStats stats;
            private List<Peminjaman> recentBorrowings;
            private List<Pengembalian> recentReturns;

            @Override
            protected Void doInBackground() throws Exception {
                stats = dashboardDAO.getStats();
                recentBorrowings = dashboardDAO.getRecentBorrowings(6);
                recentReturns = dashboardDAO.getRecentReturns(6);
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    if (stats != null) {
                        cardTotalBuku.setValue(String.valueOf(stats.getTotalBuku()));
                        cardBukuTersedia.setValue(String.valueOf(stats.getBukuTersedia()));
                        cardBukuDipinjam.setValue(String.valueOf(stats.getBukuDipinjam()));
                        cardTotalAnggota.setValue(String.valueOf(stats.getTotalAnggota()));
                        cardTotalPetugas.setValue(String.valueOf(stats.getTotalPetugas()));
                        cardTotalRak.setValue(String.valueOf(stats.getTotalRak()));
                        chartPanel.setData(stats.getAktivitasBulanan());
                    }

                    // Populate recent borrowings table
                    modelBorrowings.setRowCount(0);
                    if (recentBorrowings != null) {
                        for (Peminjaman p : recentBorrowings) {
                            modelBorrowings.addRow(new Object[]{
                                p.getIdPeminjaman(),
                                p.getNamaAnggota(),
                                p.getJudulBuku(),
                                DateUtils.formatDisplay(p.getTanggalPinjam()),
                                p.getStatusPeminjaman()
                            });
                        }
                    }

                    // Populate recent returns table
                    modelReturns.setRowCount(0);
                    if (recentReturns != null) {
                        for (Pengembalian k : recentReturns) {
                            modelReturns.addRow(new Object[]{
                                k.getIdPengembalian(),
                                k.getNamaAnggota(),
                                k.getJudulBuku(),
                                DateUtils.formatDisplay(k.getTanggalKembali()),
                                CurrencyUtils.formatRupiah(k.getDenda())
                            });
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Dashboard refresh error: " + e.getMessage());
                }
            }
        };
        worker.execute();
    }
}
