package com.perpustakaan.dao;

import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.model.Anggota;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AnggotaDAO {

    public List<Anggota> getAll() throws SQLException {
        List<Anggota> list = new ArrayList<>();
        String sql = "SELECT * FROM anggota ORDER BY id_anggota DESC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    public Anggota getById(String id) throws SQLException {
        String sql = "SELECT * FROM anggota WHERE id_anggota = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSet(rs);
                }
            }
        }
        return null;
    }

    public List<Anggota> search(String keyword) throws SQLException {
        List<Anggota> list = new ArrayList<>();
        String sql = "SELECT * FROM anggota WHERE id_anggota LIKE ? OR nama_lengkap LIKE ? OR email LIKE ? ORDER BY id_anggota DESC";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String param = "%" + keyword + "%";
            ps.setString(1, param);
            ps.setString(2, param);
            ps.setString(3, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    public boolean insert(Anggota a) throws SQLException {
        String sql = "INSERT INTO anggota (id_anggota, nama_lengkap, jenis_kelamin, alamat, no_telepon, email, tanggal_daftar) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getIdAnggota());
            ps.setString(2, a.getNamaLengkap());
            ps.setString(3, a.getJenisKelamin());
            ps.setString(4, a.getAlamat());
            ps.setString(5, a.getNoTelepon());
            ps.setString(6, a.getEmail());
            ps.setDate(7, a.getTanggalDaftar());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(Anggota a) throws SQLException {
        String sql = "UPDATE anggota SET nama_lengkap = ?, jenis_kelamin = ?, alamat = ?, " +
                     "no_telepon = ?, email = ?, tanggal_daftar = ? WHERE id_anggota = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getNamaLengkap());
            ps.setString(2, a.getJenisKelamin());
            ps.setString(3, a.getAlamat());
            ps.setString(4, a.getNoTelepon());
            ps.setString(5, a.getEmail());
            ps.setDate(6, a.getTanggalDaftar());
            ps.setString(7, a.getIdAnggota());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(String id) throws SQLException {
        String sql = "DELETE FROM anggota WHERE id_anggota = ?";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextId() throws SQLException {
        String sql = "SELECT id_anggota FROM anggota WHERE id_anggota LIKE 'AGT-%' ORDER BY id_anggota DESC LIMIT 1";
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String lastId = rs.getString("id_anggota");
                try {
                    int num = Integer.parseInt(lastId.substring(4));
                    return String.format("AGT-%03d", num + 1);
                } catch (Exception e) {
                    // fallback
                }
            }
        }
        return "AGT-001";
    }

    public String generateNewId() throws SQLException {
        return generateNextId();
    }

    private Anggota mapResultSet(ResultSet rs) throws SQLException {
        return new Anggota(
            rs.getString("id_anggota"),
            rs.getString("nama_lengkap"),
            rs.getString("jenis_kelamin"),
            rs.getString("alamat"),
            rs.getString("no_telepon"),
            rs.getString("email"),
            rs.getDate("tanggal_daftar")
        );
    }
}
