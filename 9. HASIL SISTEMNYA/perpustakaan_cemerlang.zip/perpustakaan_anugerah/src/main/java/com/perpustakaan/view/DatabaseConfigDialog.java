package com.perpustakaan.view;

import com.perpustakaan.config.DatabaseConfig;
import com.perpustakaan.config.DatabaseConnection;
import com.perpustakaan.config.DatabaseInitializer;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.ModernPasswordField;
import com.perpustakaan.view.components.ModernTextField;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class DatabaseConfigDialog extends JDialog {
    private ModernTextField txtHost;
    private ModernTextField txtPort;
    private ModernTextField txtDatabase;
    private ModernTextField txtUser;
    private ModernPasswordField txtPassword;
    private JLabel lblStatus;

    public DatabaseConfigDialog(Frame owner) {
        super(owner, "Konfigurasi Database MySQL", true);
        setSize(460, 480);
        setLocationRelativeTo(owner);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        JPanel contentPane = new JPanel(new BorderLayout(0, 16));
        contentPane.setBackground(UITheme.BG_DARK);
        contentPane.setBorder(new EmptyBorder(24, 28, 24, 28));

        // Header
        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        headerPanel.setOpaque(false);
        JLabel lblTitle = new JLabel("Pengaturan Koneksi MySQL");
        lblTitle.setFont(UITheme.FONT_HEADER);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel("Sesuaikan konfigurasi server MySQL lokal atau jaringan Anda.");
        lblSub.setFont(UITheme.FONT_SMALL);
        lblSub.setForeground(UITheme.TEXT_MUTED);

        headerPanel.add(lblTitle);
        headerPanel.add(lblSub);
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Form Fields
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 12, 12));
        formPanel.setOpaque(false);

        txtHost = new ModernTextField("localhost");
        txtHost.setText(DatabaseConfig.getHost());

        txtPort = new ModernTextField("3306");
        txtPort.setText(DatabaseConfig.getPort());

        txtDatabase = new ModernTextField("perpustakaan_anugerah");
        txtDatabase.setText(DatabaseConfig.getDatabase());

        txtUser = new ModernTextField("root");
        txtUser.setText(DatabaseConfig.getUsername());

        txtPassword = new ModernPasswordField("");
        txtPassword.setText(DatabaseConfig.getPassword());

        formPanel.add(createLabel("Host MySQL:"));
        formPanel.add(txtHost);

        formPanel.add(createLabel("Port:"));
        formPanel.add(txtPort);

        formPanel.add(createLabel("Nama Database:"));
        formPanel.add(txtDatabase);

        formPanel.add(createLabel("Username:"));
        formPanel.add(txtUser);

        formPanel.add(createLabel("Password:"));
        formPanel.add(txtPassword);

        contentPane.add(formPanel, BorderLayout.CENTER);

        // Footer Actions & Status
        JPanel footer = new JPanel(new BorderLayout(0, 12));
        footer.setOpaque(false);

        lblStatus = new JLabel(" ");
        lblStatus.setFont(UITheme.FONT_SMALL);
        lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
        footer.add(lblStatus, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);

        ModernButton btnTest = new ModernButton("Uji Koneksi", ModernButton.Style.SECONDARY);
        btnTest.addActionListener(e -> testConn());

        ModernButton btnSave = new ModernButton("Simpan & Hubungkan", ModernButton.Style.PRIMARY);
        btnSave.addActionListener(e -> saveConn());

        btnPanel.add(btnTest);
        btnPanel.add(btnSave);
        footer.add(btnPanel, BorderLayout.SOUTH);

        contentPane.add(footer, BorderLayout.SOUTH);
        setContentPane(contentPane);
    }

    private JLabel createLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UITheme.FONT_BOLD);
        l.setForeground(UITheme.TEXT_SECONDARY);
        return l;
    }

    private void testConn() {
        String host = txtHost.getText().trim();
        String port = txtPort.getText().trim();
        String db = txtDatabase.getText().trim();
        String user = txtUser.getText().trim();
        String pass = new String(txtPassword.getPassword());

        lblStatus.setText("Menguji koneksi ke MySQL...");
        lblStatus.setForeground(UITheme.TEXT_SECONDARY);

        SwingUtilities.invokeLater(() -> {
            boolean ok = DatabaseConnection.testConnection(host, port, db, user, pass);
            if (ok) {
                lblStatus.setText("✓ Koneksi ke server MySQL berhasil!");
                lblStatus.setForeground(UITheme.SUCCESS);
            } else {
                lblStatus.setText("✗ Gagal terhubung ke MySQL pada " + host + ":" + port);
                lblStatus.setForeground(UITheme.DANGER);
            }
        });
    }

    private void saveConn() {
        String host = txtHost.getText().trim();
        String port = txtPort.getText().trim();
        String db = txtDatabase.getText().trim();
        String user = txtUser.getText().trim();
        String pass = new String(txtPassword.getPassword());

        DatabaseConfig.saveConfig(host, port, db, user, pass);
        DatabaseConnection.closeConnection();
        DatabaseInitializer.initializeDatabase();

        JOptionPane.showMessageDialog(this,
            "Pengaturan database berhasil disimpan.",
            "Berhasil", JOptionPane.INFORMATION_MESSAGE);
        dispose();
    }
}
