package com.perpustakaan.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static Connection connection = null;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found: " + e.getMessage());
        }
    }

    public static synchronized Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed() || !connection.isValid(2)) {
            try {
                connection = DriverManager.getConnection(
                    DatabaseConfig.getJdbcUrl(),
                    DatabaseConfig.getUsername(),
                    DatabaseConfig.getPassword()
                );
            } catch (SQLException e) {
                // If database might not exist yet, attempt initialization
                DatabaseInitializer.initializeDatabase();
                connection = DriverManager.getConnection(
                    DatabaseConfig.getJdbcUrl(),
                    DatabaseConfig.getUsername(),
                    DatabaseConfig.getPassword()
                );
            }
        }
        return connection;
    }

    public static boolean testConnection(String host, String port, String dbName, String user, String pass) {
        String url = String.format(
            "jdbc:mysql://%s:%s/%s?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Jakarta&connectTimeout=3000",
            host, port, dbName
        );
        try (Connection testConn = DriverManager.getConnection(url, user, pass)) {
            return testConn != null && !testConn.isClosed();
        } catch (SQLException e) {
            // Also test if server is reachable without db name
            String serverUrl = String.format(
                "jdbc:mysql://%s:%s/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Jakarta&connectTimeout=3000",
                host, port
            );
            try (Connection serverConn = DriverManager.getConnection(serverUrl, user, pass)) {
                return serverConn != null && !serverConn.isClosed();
            } catch (SQLException ex) {
                return false;
            }
        }
    }

    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            } finally {
                connection = null;
            }
        }
    }
}
