package com.perpustakaan.model;

import java.sql.Timestamp;

public class User {
    private int idUser;
    private String username;
    private String password;
    private String role;
    private String idPetugas;
    private String idAnggota;
    private Timestamp createdAt;

    public User() {}

    public User(int idUser, String username, String password, String role, String idPetugas, String idAnggota, Timestamp createdAt) {
        this.idUser = idUser;
        this.username = username;
        this.password = password;
        this.role = role;
        this.idPetugas = idPetugas;
        this.idAnggota = idAnggota;
        this.createdAt = createdAt;
    }

    public int getIdUser() { return idUser; }
    public void setIdUser(int idUser) { this.idUser = idUser; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getIdPetugas() { return idPetugas; }
    public void setIdPetugas(String idPetugas) { this.idPetugas = idPetugas; }

    public String getIdAnggota() { return idAnggota; }
    public void setIdAnggota(String idAnggota) { this.idAnggota = idAnggota; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
