package com.perpustakaan.utils;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class PdfExporter {

    public static boolean exportTable(JTable table, String reportTitle, File targetFile) {
        try {
            TableModel model = table.getModel();
            int colCount = model.getColumnCount();
            int rowCount = model.getRowCount();

            // Page dimensions (A4 Landscape: 842 x 595 points)
            float pageWidth = 842;
            float pageHeight = 595;
            float margin = 40;
            float contentWidth = pageWidth - (margin * 2);

            // Compute column widths proportionally
            float[] colWidths = new float[colCount];
            float totalCalculated = 0;
            for (int c = 0; c < colCount; c++) {
                int maxLen = model.getColumnName(c).length();
                for (int r = 0; r < Math.min(rowCount, 20); r++) {
                    Object val = model.getValueAt(r, c);
                    if (val != null) {
                        maxLen = Math.max(maxLen, val.toString().length());
                    }
                }
                colWidths[c] = Math.max(30, maxLen * 7f);
                totalCalculated += colWidths[c];
            }
            for (int c = 0; c < colCount; c++) {
                colWidths[c] = (colWidths[c] / totalCalculated) * contentWidth;
            }

            // Paginate rows
            float rowHeight = 20;
            float headerHeight = 22;
            float startY = pageHeight - margin - 60; // leave room for title
            float availableHeight = startY - margin - 30; // leave room for footer
            int rowsPerPage = (int) (availableHeight / rowHeight);
            if (rowsPerPage < 1) rowsPerPage = 1;

            int totalPages = (int) Math.ceil((double) rowCount / rowsPerPage);
            if (totalPages == 0) totalPages = 1;

            // Generate PDF Objects
            List<byte[]> pdfObjects = new ArrayList<>();
            List<Integer> pageObjIndices = new ArrayList<>();

            // We will assign object numbers:
            // 1: Catalog
            // 2: Pages
            // 3: Font Helvetica
            // 4: Font Helvetica-Bold
            // 5..(4+totalPages*2): Page and ContentStream objects

            int currentObjNum = 5;
            List<String> pageContents = new ArrayList<>();

            for (int pageIdx = 0; pageIdx < totalPages; pageIdx++) {
                StringBuilder cs = new StringBuilder();

                // Draw header background (Dark bar)
                cs.append("0.15 0.15 0.18 rg\n"); // #26262e
                cs.append(String.format("%.2f %.2f %.2f 35 re f\n", margin, pageHeight - margin - 35, contentWidth));

                // Title Text
                cs.append("1 1 1 rg\n"); // White
                cs.append("BT\n/F2 14 Tf\n");
                cs.append(String.format("%.2f %.2f Td\n", margin + 15, pageHeight - margin - 22));
                cs.append("(").append(escapePdf("PERPUSTAKAAN CEMERLANG - " + (reportTitle != null ? reportTitle.toUpperCase() : "LAPORAN"))).append(") Tj\n");
                cs.append("ET\n");

                // Subtitle: Date
                cs.append("0.3 0.3 0.3 rg\n");
                cs.append("BT\n/F1 9 Tf\n");
                cs.append(String.format("%.2f %.2f Td\n", margin, pageHeight - margin - 48));
                cs.append("(").append(escapePdf("Dicetak pada: " + DateUtils.formatDisplay(DateUtils.today()) + "  |  Total Data: " + rowCount)).append(") Tj\n");
                cs.append("ET\n");

                // Table Header background
                float tableTop = pageHeight - margin - 60;
                cs.append("0.2 0.2 0.25 rg\n");
                cs.append(String.format("%.2f %.2f %.2f %.2f re f\n", margin, tableTop - headerHeight, contentWidth, headerHeight));

                // Table Header Text
                cs.append("1 1 1 rg\n");
                float curX = margin;
                for (int c = 0; c < colCount; c++) {
                    cs.append("BT\n/F2 9 Tf\n");
                    cs.append(String.format("%.2f %.2f Td\n", curX + 5, tableTop - headerHeight + 6));
                    String colName = model.getColumnName(c);
                    if (colName.length() > 25) colName = colName.substring(0, 22) + "...";
                    cs.append("(").append(escapePdf(colName)).append(") Tj\n");
                    cs.append("ET\n");
                    curX += colWidths[c];
                }

                // Table Rows
                int startRow = pageIdx * rowsPerPage;
                int endRow = Math.min(startRow + rowsPerPage, rowCount);
                float curY = tableTop - headerHeight;

                for (int r = startRow; r < endRow; r++) {
                    curY -= rowHeight;
                    boolean isAlt = ((r - startRow) % 2 == 1);
                    if (isAlt) {
                        cs.append("0.94 0.94 0.96 rg\n");
                    } else {
                        cs.append("0.98 0.98 1.0 rg\n");
                    }
                    cs.append(String.format("%.2f %.2f %.2f %.2f re f\n", margin, curY, contentWidth, rowHeight));

                    // Border line below row
                    cs.append("0.85 0.85 0.88 RG\n");
                    cs.append(String.format("%.2f %.2f m %.2f %.2f l S\n", margin, curY, margin + contentWidth, curY));

                    // Cell Text
                    cs.append("0.1 0.1 0.1 rg\n");
                    float cellX = margin;
                    for (int c = 0; c < colCount; c++) {
                        Object val = model.getValueAt(r, c);
                        String str = val != null ? val.toString() : "-";
                        if (str.length() > 30) str = str.substring(0, 27) + "...";

                        cs.append("BT\n/F1 8.5 Tf\n");
                        cs.append(String.format("%.2f %.2f Td\n", cellX + 5, curY + 6));
                        cs.append("(").append(escapePdf(str)).append(") Tj\n");
                        cs.append("ET\n");
                        cellX += colWidths[c];
                    }
                }

                // Table outer border
                cs.append("0.7 0.7 0.75 RG\n");
                cs.append(String.format("%.2f %.2f %.2f %.2f re S\n", margin, curY, contentWidth, tableTop - curY));

                // Footer
                cs.append("0.5 0.5 0.5 rg\n");
                cs.append("BT\n/F1 8 Tf\n");
                cs.append(String.format("%.2f %.2f Td\n", margin, margin - 15));
                cs.append("(").append(escapePdf("Perpustakaan Cemerlang - Sistem Informasi Manajemen Perpustakaan")).append(") Tj\n");
                cs.append("ET\n");

                cs.append("BT\n/F1 8 Tf\n");
                cs.append(String.format("%.2f %.2f Td\n", pageWidth - margin - 80, margin - 15));
                cs.append("(").append(escapePdf("Halaman " + (pageIdx + 1) + " dari " + totalPages)).append(") Tj\n");
                cs.append("ET\n");

                pageContents.add(cs.toString());
            }

            // Write PDF structure to file
            try (FileOutputStream fos = new FileOutputStream(targetFile)) {
                ByteArrayOutputStream doc = new ByteArrayOutputStream();
                List<Integer> offsets = new ArrayList<>();

                doc.write("%PDF-1.4\n%\u00E2\u00E3\u00CF\u00D3\n".getBytes(StandardCharsets.US_ASCII));

                int pageListObjNum = 2;
                int f1ObjNum = 3;
                int f2ObjNum = 4;

                int pageFirstObj = 5;

                // 1 0 obj Catalog
                offsets.add(doc.size());
                doc.write("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n".getBytes(StandardCharsets.US_ASCII));

                // 2 0 obj Pages (placeholder, will write kids)
                StringBuilder kids = new StringBuilder();
                for (int i = 0; i < totalPages; i++) {
                    kids.append((pageFirstObj + (i * 2))).append(" 0 R ");
                }
                offsets.add(doc.size());
                String pagesObj = String.format("2 0 obj\n<< /Type /Pages /Kids [%s] /Count %d >>\nendobj\n", kids.toString().trim(), totalPages);
                doc.write(pagesObj.getBytes(StandardCharsets.US_ASCII));

                // 3 0 obj Font F1 (Helvetica)
                offsets.add(doc.size());
                doc.write("3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n".getBytes(StandardCharsets.US_ASCII));

                // 4 0 obj Font F2 (Helvetica-Bold)
                offsets.add(doc.size());
                doc.write("4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n".getBytes(StandardCharsets.US_ASCII));

                // Page objects and Content stream objects
                for (int i = 0; i < totalPages; i++) {
                    int pageObjId = pageFirstObj + (i * 2);
                    int contentObjId = pageObjId + 1;
                    byte[] contentBytes = pageContents.get(i).getBytes(StandardCharsets.UTF_8);

                    // Page Object
                    offsets.add(doc.size());
                    String pageStr = String.format(
                        "%d 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] /Contents %d 0 R /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>\nendobj\n",
                        pageObjId, pageWidth, pageHeight, contentObjId
                    );
                    doc.write(pageStr.getBytes(StandardCharsets.US_ASCII));

                    // Content Stream Object
                    offsets.add(doc.size());
                    String streamHeader = String.format("%d 0 obj\n<< /Length %d >>\nstream\n", contentObjId, contentBytes.length);
                    doc.write(streamHeader.getBytes(StandardCharsets.US_ASCII));
                    doc.write(contentBytes);
                    doc.write("\nendstream\nendobj\n".getBytes(StandardCharsets.US_ASCII));
                }

                // XRef table
                int xrefOffset = doc.size();
                int totalObjects = 4 + (totalPages * 2);
                StringBuilder xref = new StringBuilder();
                xref.append("xref\n0 ").append(totalObjects + 1).append("\n");
                xref.append("0000000000 65535 f \n");
                for (int offset : offsets) {
                    xref.append(String.format("%010d 00000 n \n", offset));
                }
                xref.append("trailer\n<< /Size ").append(totalObjects + 1).append(" /Root 1 0 R >>\n");
                xref.append("startxref\n").append(xrefOffset).append("\n%%EOF\n");

                doc.write(xref.toString().getBytes(StandardCharsets.US_ASCII));
                doc.writeTo(fos);
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Gagal mengekspor data ke PDF:\n" + e.getMessage(),
                "Kesalahan Ekspor", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private static String escapePdf(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
    }
}
