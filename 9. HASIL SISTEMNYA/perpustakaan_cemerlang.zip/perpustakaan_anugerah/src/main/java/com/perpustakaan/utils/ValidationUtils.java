package com.perpustakaan.utils;

import java.sql.Date;
import java.util.regex.Pattern;

public class ValidationUtils {
    private static final Pattern EMAIL_PATTERN =
        Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    public static boolean isValidEmail(String email) {
        if (isEmpty(email)) return false;
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    public static boolean isValidPhone(String phone) {
        if (isEmpty(phone)) return false;
        return phone.trim().matches("^[0-9+()\\-\\s]{6,20}$");
    }

    public static boolean isNumeric(String str) {
        if (isEmpty(str)) return false;
        return str.trim().matches("^[0-9]+$");
    }

    public static boolean isPositiveInteger(String str) {
        if (isEmpty(str)) return false;
        try {
            int val = Integer.parseInt(str.trim());
            return val >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isValidDate(String dateStr) {
        if (isEmpty(dateStr)) return false;
        try {
            Date.valueOf(dateStr.trim());
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
