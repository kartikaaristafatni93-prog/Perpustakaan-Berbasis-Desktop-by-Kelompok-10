package com.perpustakaan.view.panels;

import com.perpustakaan.dao.BukuDAO;
import com.perpustakaan.dao.RakDAO;
import com.perpustakaan.model.Buku;
import com.perpustakaan.model.Rak;
import com.perpustakaan.utils.IconFactory;
import com.perpustakaan.utils.SessionManager;
import com.perpustakaan.utils.ValidationUtils;
import com.perpustakaan.view.components.ModernButton;
import com.perpustakaan.view.components.ModernTable;
import com.perpustakaan.view.components.ModernTextField;
import com.perpustakaan.view.components.StatusBadgeRenderer;
import com.perpustakaan.view.components.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

public class BukuPanel extends JPanel {
    private BukuDAO bukuDAO = new BukuDAO();
    private RakDAO rakDAO = new RakDAO();

    // Form inputs
    private ModernTextField txtId;
    private ModernTextField txtJudul;
    private ModernTextField txtPengarang;
    private ModernTextField txtPenerbit;
    private ModernTextField txtTahun;
    private JComboBox<String> cmbKategori;
    private JComboBox<RakItem> cmbRak;
    private ModernTextField txtTotalStok;
    private ModernTextField txtSisaStok;

    // Search & Filter & Table
    private ModernTextField txtSearch;
    private JComboBox<String> cmbFilterKategori;
    private ModernTable table;
    private DefaultTableModel tableModel;

    // Buttons (Staff / Admin)
    private ModernButton btnSave;
    private ModernButton btnUpdate;
    private ModernButton btnDelete;
    private ModernButton btnReset;
    private ModernButton btnRefresh;

    // Detail status label for member
    private JLabel lblStockBadge;

    private Runnable onChangeListener;

    public static class RakItem {
        private String id;
        private String name;

        public RakItem(String id, String name) {
            this.id = id;
            this.name = name;
        }

        public String getId() { return id; }

        @Override
        public String toString() {
            return id + " - " + name;
        }
    }

    public BukuPanel(Runnable onChangeListener) {
        this.onChangeListener = onChangeListener;
        setOpaque(false);
        setLayout(new BorderLayout(0, 18));
        setBorder(new EmptyBorder(24, 28, 24, 28));

        initUI();
        loadShelves();
        loadData();
        if (!SessionManager.isPengguna()) {
            generateNewId();
        }
    }

    private void initUI() {
        boolean isPengguna = SessionManager.isPengguna();

        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titleGrp = new JPanel(new GridLayout(2, 1, 0, 4));
        titleGrp.setOpaque(false);
        JLabel lblTitle = new JLabel(isPengguna ? "Katalog Koleksi Buku & Informasi Stok" : "Manajemen Data Buku");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblSub = new JLabel(isPengguna ?
            "Cari koleksi buku perpustakaan, periksa detail informasi pengarang, kategori, dan ketersediaan stok." :
            "Kelola katalog buku, stok fisik, ketersediaan pinjam, dan klasifikasi rak.");
        lblSub.setFont(UITheme.FONT_SUBTITLE);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);

        titleGrp.add(lblTitle);
        titleGrp.add(lblSub);
        headerPanel.add(titleGrp, BorderLayout.CENTER);

        // Search Bar & Filter & Refresh
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBar.setOpaque(false);

        cmbFilterKategori = new JComboBox<>(new String[]{
            "Semua Kategori", "Teknologi Informasi", "Sains & Matematika", "Sastra & Fiksi",
            "Filsafat & Pengembangan Diri", "Ekonomi & Bisnis", "Sejarah & Budaya", "Kamus & Referensi", "Umum"
        });
        cmbFilterKategori.setPreferredSize(new Dimension(160, 38));
        cmbFilterKategori.addActionListener(e -> searchData());

        txtSearch = new ModernTextField("Cari ID / Judul / Pengarang / Kategori...");
        txtSearch.setPreferredSize(new Dimension(240, 38));
        txtSearch.addActionListener(e -> searchData());

        ModernButton btnSearch = new ModernButton("Cari", IconFactory.createIcon("search", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnSearch.addActionListener(e -> searchData());

        btnRefresh = new ModernButton("Refresh", IconFactory.createIcon("refresh", 15, UITheme.TEXT_PRIMARY), ModernButton.Style.SECONDARY);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            cmbFilterKategori.setSelectedIndex(0);
            loadShelves();
            loadData();
            if (!isPengguna) resetForm();
        });

        searchBar.add(cmbFilterKategori);
        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnRefresh);

        headerPanel.add(searchBar, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Center Split: Left = Input Form / Detail Card (380px), Right = Data Table
        JPanel mainContent = new JPanel(new BorderLayout(20, 0));
        mainContent.setOpaque(false);

        // 1. Form Card / Detail Card
        JPanel formCard = createFormCard(isPengguna);
        mainContent.add(formCard, BorderLayout.WEST);

        // 2. Table Container
        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setOpaque(false);

        tableModel = new DefaultTableModel(
            new String[]{"ID Buku", "Judul Buku", "Pengarang", "Kategori", "Rak", "Total", "Tersedia", "Dipinjam", "Status Stok"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new ModernTable(tableModel);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(210);
        table.getColumnModel().getColumn(2).setPreferredWidth(140);
        table.getColumnModel().getColumn(3).setPreferredWidth(130);
        table.getColumnModel().getColumn(5).setPreferredWidth(50);
        table.getColumnModel().getColumn(6).setPreferredWidth(60);
        table.getColumnModel().getColumn(7).setPreferredWidth(60);
        table.getColumnModel().getColumn(8).setPreferredWidth(90);
        table.getColumnModel().getColumn(8).setCellRenderer(new StatusBadgeRenderer());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                populateFormFromSelectedRow();
            }
        });

        tableContainer.add(ModernTable.wrap(table), BorderLayout.CENTER);
        mainContent.add(tableContainer, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createFormCard(boolean isPengguna) {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(UITheme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 12, 12));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(380, 560));
        card.setLayout(new BorderLayout(0, 12));
        card.setBorder(new EmptyBorder(18, 20, 18, 20));

        JLabel lblFormTitle = new JLabel(isPengguna ? "Detail Informasi Buku & Stok" : "Form Data Buku");
        lblFormTitle.setFont(UITheme.FONT_HEADER);
        lblFormTitle.setForeground(UITheme.TEXT_PRIMARY);
        card.add(lblFormTitle, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel();
        fieldsPanel.setOpaque(false);
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));

        txtId = new ModernTextField();
        txtId.setEditable(false);
        txtId.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtJudul = new ModernTextField("Judul buku");
        txtJudul.setEditable(!isPengguna);
        txtJudul.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtPengarang = new ModernTextField("Nama pengarang / penulis");
        txtPengarang.setEditable(!isPengguna);
        txtPengarang.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtPenerbit = new ModernTextField("Nama penerbit");
        txtPenerbit.setEditable(!isPengguna);
        txtPenerbit.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtTahun = new ModernTextField("Tahun terbit (contoh: 2024)");
        txtTahun.setEditable(!isPengguna);
        txtTahun.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        cmbKategori = new JComboBox<>(new String[]{
            "Teknologi Informasi", "Sains & Matematika", "Sastra & Fiksi",
            "Filsafat & Pengembangan Diri", "Ekonomi & Bisnis", "Sejarah & Budaya", "Kamus & Referensi", "Umum"
        });
        cmbKategori.setFont(UITheme.FONT_REGULAR);
        cmbKategori.setBackground(UITheme.BG_INPUT);
        cmbKategori.setForeground(UITheme.TEXT_PRIMARY);
        cmbKategori.setEnabled(!isPengguna);
        cmbKategori.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        cmbRak = new JComboBox<>();
        cmbRak.setFont(UITheme.FONT_REGULAR);
        cmbRak.setBackground(UITheme.BG_INPUT);
        cmbRak.setForeground(UITheme.TEXT_PRIMARY);
        cmbRak.setEnabled(!isPengguna);
        cmbRak.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtTotalStok = new ModernTextField("10");
        txtTotalStok.setEditable(!isPengguna);
        txtTotalStok.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        txtSisaStok = new ModernTextField("10");
        txtSisaStok.setEditable(!isPengguna);
        txtSisaStok.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        fieldsPanel.add(createFieldLabel("ID Buku"));
        fieldsPanel.add(txtId);
        fieldsPanel.add(Box.createVerticalStrut(8));

        fieldsPanel.add(createFieldLabel("Judul Buku *"));
        fieldsPanel.add(txtJudul);
        fieldsPanel.add(Box.createVerticalStrut(8));

        fieldsPanel.add(createFieldLabel("Pengarang *"));
        fieldsPanel.add(txtPengarang);
        fieldsPanel.add(Box.createVerticalStrut(8));

        fieldsPanel.add(createFieldLabel("Penerbit"));
        fieldsPanel.add(txtPenerbit);
        fieldsPanel.add(Box.createVerticalStrut(8));

        // Row with 2 items: Tahun & Kategori
        JPanel rowThnKat = new JPanel(new GridLayout(1, 2, 8, 0));
        rowThnKat.setOpaque(false);
        rowThnKat.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        JPanel pnlThn = new JPanel(new BorderLayout(0, 4));
        pnlThn.setOpaque(false);
        pnlThn.add(createFieldLabel("Tahun Terbit"), BorderLayout.NORTH);
        pnlThn.add(txtTahun, BorderLayout.CENTER);

        JPanel pnlKat = new JPanel(new BorderLayout(0, 4));
        pnlKat.setOpaque(false);
        pnlKat.add(createFieldLabel("Kategori"), BorderLayout.NORTH);
        pnlKat.add(cmbKategori, BorderLayout.CENTER);

        rowThnKat.add(pnlThn);
        rowThnKat.add(pnlKat);
        fieldsPanel.add(rowThnKat);
        fieldsPanel.add(Box.createVerticalStrut(6));

        fieldsPanel.add(createFieldLabel("Lokasi Rak Buku *"));
        fieldsPanel.add(cmbRak);
        fieldsPanel.add(Box.createVerticalStrut(6));

        // Row with 2 items: Total Stok & Sisa Stok
        JPanel rowStok = new JPanel(new GridLayout(1, 2, 8, 0));
        rowStok.setOpaque(false);
        rowStok.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        JPanel pnlTot = new JPanel(new BorderLayout(0, 4));
        pnlTot.setOpaque(false);
        pnlTot.add(createFieldLabel("Total Stok Buku"), BorderLayout.NORTH);
        pnlTot.add(txtTotalStok, BorderLayout.CENTER);

        JPanel pnlSis = new JPanel(new BorderLayout(0, 4));
        pnlSis.setOpaque(false);
        pnlSis.add(createFieldLabel("Stok Tersedia (Bisa Dipinjam)"), BorderLayout.NORTH);
        pnlSis.add(txtSisaStok, BorderLayout.CENTER);

        rowStok.add(pnlTot);
        rowStok.add(pnlSis);
        fieldsPanel.add(rowStok);

        card.add(fieldsPanel, BorderLayout.CENTER);

        if (isPengguna) {
            // Pengguna view: Stock summary card & guidance note
            JPanel memberInfoBox = new JPanel();
            memberInfoBox.setLayout(new BoxLayout(memberInfoBox, BoxLayout.Y_AXIS));
            memberInfoBox.setOpaque(false);
            memberInfoBox.setBorder(new EmptyBorder(10, 0, 0, 0));

            lblStockBadge = new JLabel("Status: Pilih buku pada tabel untuk melihat detail");
            lblStockBadge.setFont(UITheme.FONT_BOLD);
            lblStockBadge.setForeground(UITheme.PRIMARY_DARK);

            JLabel lblHelp = new JLabel("<html><small>ℹ️ <i>Peminjaman buku dilakukan di meja layanan sirkulasi perpustakaan dengan menunjukkan ID Anggota Anda.</i></small></html>");
            lblHelp.setFont(UITheme.FONT_SMALL);
            lblHelp.setForeground(UITheme.TEXT_MUTED);

            memberInfoBox.add(lblStockBadge);
            memberInfoBox.add(Box.createVerticalStrut(6));
            memberInfoBox.add(lblHelp);
            card.add(memberInfoBox, BorderLayout.SOUTH);
        } else {
            // Staff/Admin view: CRUD Action Buttons Grid
            JPanel btnGrid = new JPanel(new GridLayout(2, 2, 8, 8));
            btnGrid.setOpaque(false);

            btnSave = new ModernButton("Simpan", IconFactory.createIcon("add", 14, Color.WHITE), ModernButton.Style.PRIMARY);
            btnSave.addActionListener(e -> saveData());

            btnUpdate = new ModernButton("Ubah", IconFactory.createIcon("edit", 14, Color.WHITE), ModernButton.Style.SUCCESS);
            btnUpdate.setEnabled(false);
            btnUpdate.addActionListener(e -> updateData());

            btnDelete = new ModernButton("Hapus", IconFactory.createIcon("delete", 14, Color.WHITE), ModernButton.Style.DANGER);
            btnDelete.setEnabled(false);
            btnDelete.addActionListener(e -> deleteData());

            btnReset = new ModernButton("Batal / Baru", ModernButton.Style.SECONDARY);
            btnReset.addActionListener(e -> resetForm());

            btnGrid.add(btnSave);
            btnGrid.add(btnUpdate);
            btnGrid.add(btnDelete);
            btnGrid.add(btnReset);

            card.add(btnGrid, BorderLayout.SOUTH);
        }

        return card;
    }

    private JLabel createFieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UITheme.FONT_SMALL);
        l.setForeground(UITheme.TEXT_SECONDARY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    public void loadShelves() {
        cmbRak.removeAllItems();
        try {
            List<Rak> shelves = rakDAO.getAll();
            for (Rak r : shelves) {
                cmbRak.addItem(new RakItem(r.getIdRak(), r.getNamaRak()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadData() {
        SwingWorker<List<Buku>, Void> worker = new SwingWorker<List<Buku>, Void>() {
            @Override
            protected List<Buku> doInBackground() throws Exception {
                return bukuDAO.getAll();
            }

            @Override
            protected void done() {
                try {
                    List<Buku> list = get();
                    tableModel.setRowCount(0);
                    for (Buku b : list) {
                        int borrowed = b.getTotalStok() - b.getSisaStok();
                        if (borrowed < 0) borrowed = 0;
                        String statusStok = b.getSisaStok() > 0 ? "Tersedia" : "Habis";
                        tableModel.addRow(new Object[]{
                            b.getIdBuku(),
                            b.getJudulBuku(),
                            b.getPengarang(),
                            b.getKategori(),
                            b.getNamaRak() != null ? b.getNamaRak() : b.getIdRak(),
                            b.getTotalStok(),
                            b.getSisaStok(),
                            borrowed,
                            statusStok
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    private void searchData() {
        String keyword = txtSearch.getText().trim();
        String kategori = (String) cmbFilterKategori.getSelectedItem();

        SwingWorker<List<Buku>, Void> worker = new SwingWorker<List<Buku>, Void>() {
            @Override
            protected List<Buku> doInBackground() throws Exception {
                List<Buku> list;
                if (keyword.isEmpty()) {
                    list = bukuDAO.getAll();
                } else {
                    list = bukuDAO.search(keyword);
                }

                if (kategori != null && !"Semua Kategori".equalsIgnoreCase(kategori)) {
                    list.removeIf(b -> !kategori.equalsIgnoreCase(b.getKategori()));
                }
                return list;
            }

            @Override
            protected void done() {
                try {
                    List<Buku> list = get();
                    tableModel.setRowCount(0);
                    for (Buku b : list) {
                        int borrowed = b.getTotalStok() - b.getSisaStok();
                        if (borrowed < 0) borrowed = 0;
                        String statusStok = b.getSisaStok() > 0 ? "Tersedia" : "Habis";
                        tableModel.addRow(new Object[]{
                            b.getIdBuku(),
                            b.getJudulBuku(),
                            b.getPengarang(),
                            b.getKategori(),
                            b.getNamaRak() != null ? b.getNamaRak() : b.getIdRak(),
                            b.getTotalStok(),
                            b.getSisaStok(),
                            borrowed,
                            statusStok
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    private void populateFormFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        String id = (String) tableModel.getValueAt(row, 0);
        try {
            Buku b = bukuDAO.getById(id);
            if (b != null) {
                txtId.setText(b.getIdBuku());
                txtJudul.setText(b.getJudulBuku());
                txtPengarang.setText(b.getPengarang());
                txtPenerbit.setText(b.getPenerbit());
                txtTahun.setText(String.valueOf(b.getTahunTerbit()));
                cmbKategori.setSelectedItem(b.getKategori());

                for (int i = 0; i < cmbRak.getItemCount(); i++) {
                    RakItem item = cmbRak.getItemAt(i);
                    if (item.getId().equals(b.getIdRak())) {
                        cmbRak.setSelectedIndex(i);
                        break;
                    }
                }

                txtTotalStok.setText(String.valueOf(b.getTotalStok()));
                txtSisaStok.setText(String.valueOf(b.getSisaStok()));

                if (lblStockBadge != null) {
                    if (b.getSisaStok() > 0) {
                        lblStockBadge.setText("Status: Tersedia (" + b.getSisaStok() + " buku dapat dipinjam)");
                        lblStockBadge.setForeground(new Color(0x15, 0x80, 0x3D));
                    } else {
                        lblStockBadge.setText("Status: Sedang Habis (Semua " + b.getTotalStok() + " buku sedang dipinjam)");
                        lblStockBadge.setForeground(UITheme.DANGER);
                    }
                }

                if (!SessionManager.isPengguna()) {
                    btnSave.setEnabled(false);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveData() {
        if (!validateInput()) return;

        try {
            RakItem rak = (RakItem) cmbRak.getSelectedItem();
            Buku b = new Buku(
                txtId.getText().trim(),
                txtId.getText().trim(),
                txtJudul.getText().trim(),
                txtPengarang.getText().trim(),
                txtPenerbit.getText().trim(),
                Integer.parseInt(txtTahun.getText().trim()),
                (String) cmbKategori.getSelectedItem(),
                rak != null ? rak.getId() : "RAK-001",
                Integer.parseInt(txtTotalStok.getText().trim()),
                Integer.parseInt(txtSisaStok.getText().trim())
            );

            boolean success = bukuDAO.insert(b);
            if (success) {
                JOptionPane.showMessageDialog(this, "Data buku berhasil ditambahkan ke katalog!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                resetForm();
                if (onChangeListener != null) onChangeListener.run();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menambahkan data buku ke database.", "Gagal", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saat menyimpan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateData() {
        if (!validateInput()) return;

        try {
            RakItem rak = (RakItem) cmbRak.getSelectedItem();
            Buku b = new Buku(
                txtId.getText().trim(),
                txtId.getText().trim(),
                txtJudul.getText().trim(),
                txtPengarang.getText().trim(),
                txtPenerbit.getText().trim(),
                Integer.parseInt(txtTahun.getText().trim()),
                (String) cmbKategori.getSelectedItem(),
                rak != null ? rak.getId() : "RAK-001",
                Integer.parseInt(txtTotalStok.getText().trim()),
                Integer.parseInt(txtSisaStok.getText().trim())
            );

            boolean success = bukuDAO.update(b);
            if (success) {
                JOptionPane.showMessageDialog(this, "Data buku berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadData();
                resetForm();
                if (onChangeListener != null) onChangeListener.run();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal memperbarui data buku.", "Gagal", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saat memperbarui: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteData() {
        String id = txtId.getText().trim();
        if (id.isEmpty()) return;

        int opt = JOptionPane.showConfirmDialog(this,
            "Apakah Anda yakin ingin menghapus buku '" + txtJudul.getText() + "' (" + id + ")?",
            "Konfirmasi Hapus Buku", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (opt == JOptionPane.YES_OPTION) {
            try {
                boolean success = bukuDAO.delete(id);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Data buku berhasil dihapus!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    loadData();
                    resetForm();
                    if (onChangeListener != null) onChangeListener.run();
                } else {
                    JOptionPane.showMessageDialog(this, "Buku tidak dapat dihapus karena masih terkait dengan transaksi peminjaman aktif.", "Gagal Menghapus", JOptionPane.WARNING_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error saat menghapus: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void resetForm() {
        txtJudul.setText("");
        txtPengarang.setText("");
        txtPenerbit.setText("");
        txtTahun.setText("");
        txtTotalStok.setText("10");
        txtSisaStok.setText("10");
        if (cmbKategori.getItemCount() > 0) cmbKategori.setSelectedIndex(0);
        if (cmbRak.getItemCount() > 0) cmbRak.setSelectedIndex(0);
        table.clearSelection();

        if (lblStockBadge != null) {
            lblStockBadge.setText("Status: Pilih buku pada tabel untuk melihat detail");
            lblStockBadge.setForeground(UITheme.PRIMARY_DARK);
        }

        if (!SessionManager.isPengguna()) {
            btnSave.setEnabled(true);
            btnUpdate.setEnabled(false);
            btnDelete.setEnabled(false);
            generateNewId();
        }
    }

    private void generateNewId() {
        try {
            txtId.setText(bukuDAO.generateNewId());
        } catch (Exception e) {
            txtId.setText("BK-001");
        }
    }

    private boolean validateInput() {
        if (ValidationUtils.isEmpty(txtJudul.getText())) {
            JOptionPane.showMessageDialog(this, "Judul buku tidak boleh kosong!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtJudul.requestFocus();
            return false;
        }
        if (ValidationUtils.isEmpty(txtPengarang.getText())) {
            JOptionPane.showMessageDialog(this, "Nama pengarang tidak boleh kosong!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtPengarang.requestFocus();
            return false;
        }
        if (!ValidationUtils.isNumeric(txtTahun.getText())) {
            JOptionPane.showMessageDialog(this, "Tahun terbit harus berupa angka 4 digit!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtTahun.requestFocus();
            return false;
        }
        if (!ValidationUtils.isNumeric(txtTotalStok.getText()) || Integer.parseInt(txtTotalStok.getText().trim()) < 0) {
            JOptionPane.showMessageDialog(this, "Total stok harus berupa angka >= 0!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtTotalStok.requestFocus();
            return false;
        }
        if (!ValidationUtils.isNumeric(txtSisaStok.getText()) || Integer.parseInt(txtSisaStok.getText().trim()) < 0) {
            JOptionPane.showMessageDialog(this, "Sisa stok harus berupa angka >= 0!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtSisaStok.requestFocus();
            return false;
        }
        int tot = Integer.parseInt(txtTotalStok.getText().trim());
        int sis = Integer.parseInt(txtSisaStok.getText().trim());
        if (sis > tot) {
            JOptionPane.showMessageDialog(this, "Sisa stok tersedia tidak boleh lebih besar dari total stok fisik!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtSisaStok.requestFocus();
            return false;
        }
        return true;
    }
}
