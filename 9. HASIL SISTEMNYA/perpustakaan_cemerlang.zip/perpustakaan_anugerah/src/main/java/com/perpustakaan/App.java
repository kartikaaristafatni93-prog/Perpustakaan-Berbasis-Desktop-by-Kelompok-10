package com.perpustakaan;

/**
 * Alternative launcher entry point for IDEs (such as NetBeans or Eclipse).
 */
public class App {
    public static void main(String[] args) {
        Main.main(args);
    }
}
