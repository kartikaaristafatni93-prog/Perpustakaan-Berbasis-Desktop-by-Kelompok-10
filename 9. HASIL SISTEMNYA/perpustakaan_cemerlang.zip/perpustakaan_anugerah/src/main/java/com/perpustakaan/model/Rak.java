package com.perpustakaan.model;

public class Rak {
    private String idRak;
    private String namaRak;
    private String lokasiRak;
    private String keterangan;

    public Rak() {}

    public Rak(String idRak, String namaRak, String lokasiRak, String keterangan) {
        this.idRak = idRak;
        this.namaRak = namaRak;
        this.lokasiRak = lokasiRak;
        this.keterangan = keterangan;
    }

    public String getIdRak() { return idRak; }
    public void setIdRak(String idRak) { this.idRak = idRak; }

    public String getNamaRak() { return namaRak; }
    public void setNamaRak(String namaRak) { this.namaRak = namaRak; }

    public String getLokasiRak() { return lokasiRak; }
    public void setLokasiRak(String lokasiRak) { this.lokasiRak = lokasiRak; }

    public String getKeterangan() { return keterangan; }
    public void setKeterangan(String keterangan) { this.keterangan = keterangan; }

    @Override
    public String toString() {
        return idRak + " - " + namaRak;
    }
}
