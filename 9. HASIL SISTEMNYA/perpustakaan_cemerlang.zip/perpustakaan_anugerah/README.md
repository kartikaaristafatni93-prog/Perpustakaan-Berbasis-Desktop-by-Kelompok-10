# Perpustakaan Cemerlang - Desktop Library Management System

A complete, modern, and elegant desktop-based library management system built with **Java Swing**, **MySQL Database**, **JDBC**, and **FlatLaf** following a modern **Clean SaaS Light Dashboard** design system.

---

## 📌 Akun Demo & Kredensial Pengguna

| Role | Username | Password | Hak Akses |
|---|---|---|---|
| **Administrator** | `admin` | `admin123` | Akses penuh seluruh sistem: Dashboard, Master Data (Anggota, Petugas, Buku, Rak), Transaksi, Laporan, Cetak Kartu, Konfigurasi Database |
| **Petugas Perpustakaan** | `petugas` | `petugas123` | Dashboard, Master Data (Anggota, Buku, Rak), Transaksi Sirkulasi, Cetak Struk, Laporan, Cetak Kartu Anggota |
| **Anggota / Pengguna** | `budi` | `user123` | Layanan Pengguna: Katalog Buku (Cari, Filter Kategori, Cek Stok Tersedia/Habis), Cetak Kartu Anggota Saya |

> *Pengguna baru juga dapat langsung mendaftar sendiri melalui tombol **"Daftar sebagai Anggota Baru"** di layar Login!*

---

## 🚀 Fitur Baru & Pembaruan Sistem

### 1. 🏷️ Rebranding Nama: "Perpustakaan Cemerlang"
- Nama perpustakaan resmi diperbarui menjadi **Perpustakaan Cemerlang** pada seluruh modul, kop dokumen laporan, struk transaksi, dan kartu anggota resmi.

### 2. 🎨 Redesign UI/UX Menjadi Modern Light SaaS
- Menggunakan tema **FlatLaf Light** yang bersih, cerah, dan profesional.
- **Palet Warna Modern SaaS:**
  - **Primary Blue:** `#3478E5`
  - **Dark Blue / Hover:** `#2563C5`
  - **Sidebar Background:** `#FFFFFF` (Lebar 240px, logo, navigasi dengan rounded blue highlight pada menu aktif)
  - **Main Content Background:** Soft pastel gradient (`#F4F7FC` ke `#EEF2F8`)
  - **Content Container / Card:** `#FFFFFF` dengan sudut membulat (*rounded corners*) dan *subtle borders* (`#EAEAEA`)
  - **Primary Text:** `#252525`
  - **Secondary Text:** `#666666` / `#888888`
  - **Status Badges:** Pastel soft pill background (Hijau Sukses `#EAF8F1`, Kuning Warning `#FEF7EC`, Merah Denda `#FDEDEF`, Biru Info `#EBF3FD`).
- **Top Header Modern:** Search bar, ikon notifikasi, avatar profil, nama staff/anggota, dan badge role aktif.

### 3. 👥 Akses Khusus Pengguna / Anggota (Role-Based Access)
- Pengguna (Member) yang login hanya memiliki akses ke:
  - **Katalog Buku & Informasi Stok:** Menjelajahi seluruh buku, mencari berdasarkan judul/pengarang/kategori, menyaring per kategori, serta memantau status ketersediaan stok fisik (*Tersedia / Habis dipinjam*).
  - Form penambahan, pengubahan, dan penghapusan buku otomatis disembunyikan/dijadikan *read-only* bagi pengguna umum.
  - Menu petugas, transaksi, dan laporan administrasi disembunyikan dari navigasi pengguna.

### 4. 📝 Registrasi Mandiri Anggota Baru & Dialog Notifikasi Email
- Pada layar login, terdapat tombol **"Daftar sebagai Anggota Baru"**.
- Pengguna mengisi form pendaftaran: Username, Kata Sandi, Konfirmasi Sandi, Nama Lengkap, Jenis Kelamin, Alamat, Email, dan No. HP.
- Sistem otomatis:
  1. Men-generate ID Anggota unik (`AGT-xxx`).
  2. Menyimpan data ke tabel `anggota`.
  3. Membuat akun login di tabel `users` dengan kata sandi ter-enkripsi SHA-256.
  4. Menampilkan dialog **Email Notifikasi Selamat Bergabung** lengkap dengan rincian data keanggotaan dan tombol **"🖨️ Cetak Kartu Anggota Sekarang"**.

### 5. 🖨️ Cetak Kartu Anggota Resmi (Member Card Printing)
- Fitur pencetakan kartu tanda anggota perpustakaan resmi berstandar ID card (rasio 85.6mm x 54mm):
  - Pita logo **PERPUSTAKAAN CEMERLANG** dengan gradasi biru.
  - Foto avatar profil member.
  - Detail ID Anggota, Nama, Email, Telepon, dan Tanggal Registrasi.
  - Simulasi kode batang (*aesthetic barcode*) dan cap verifikasi keanggotaan resmi (*Verified Member*).
- Dapat dicetak langsung ke printer fisik melalui Java Print API (`PrinterJob`).
- Tersedia pada:
  - Dialog email setelah registrasi baru.
  - Menu samping anggota: **"Kartu Anggota Saya"**.
  - Form **Data Anggota** (tombol *Cetak Kartu Anggota* untuk petugas).
  - Tab **Laporan Anggota** (tombol *Cetak Kartu Anggota* untuk mencetak kartu anggota terpilih).

### 6. 🧾 Cetak Struk Detail Transaksi (Receipt Printing)
- **Struk Peminjaman Buku:**
  - Menampilkan No. Peminjaman, Tanggal Pinjam, Tanggal Jatuh Tempo, ID & Nama Anggota, ID & Judul Buku, Petugas Pelayan, Ketentuan Denda, dan kolom tanda tangan.
  - Ditawarkan secara otomatis saat transaksi baru disimpan, atau dapat dicetak kapan saja melalui tombol **"🖨️ Cetak Struk"** pada tabel peminjaman.
- **Struk Pengembalian Buku:**
  - Menampilkan No. Pengembalian, No. Peminjaman, Nama Anggota, Judul Buku, Tanggal Kembali, Rincian Keterlambatan (hari), Denda yang dibayarkan, dan status pembayaran.

---

## 💻 Cara Menjalankan Aplikasi

### Cara 1: Menggunakan Batch Script (Paling Praktis)
1. Buka folder proyek: `C:\Users\Kartika\.gemini\antigravity\scratch\perpustakaan_anugerah`
2. Klik ganda file **`run.bat`**.
3. Aplikasi akan langsung terbuka seketika!

### Cara 2: Melalui NetBeans IDE
1. Buka proyek di NetBeans IDE.
2. Klik tombol **Run Project** (ikon ▶ hijau) atau tekan **F6**.
3. NetBeans akan menjalankan target `3.5.1` yang sudah terpasang offline melalui file `nbactions.xml`.
