@echo off
title Build Perpustakaan Anugerah
echo ============================================================
echo   KOMPILASI PROYEK PERPUSTAKAAN ANUGERAH
echo ============================================================
echo.

set JAVA_HOME=C:\Program Files\Java\jdk-26
set MVN="C:\Program Files\NetBeans-20\netbeans\java\maven\bin\mvn.cmd"

if exist %MVN% (
    call %MVN% compile
    "C:\Program Files\Java\jdk-26\bin\jar.exe" -cfm perpustakaan-anugerah.jar manifest.txt -C target\classes .
    copy perpustakaan-anugerah.jar target\ /Y
    echo.
    echo Kompilasi berhasil! File perpustakaan-anugerah.jar siap dijalankan.
) else (
    echo Maven tidak ditemukan pada NetBeans path.
)

pause
