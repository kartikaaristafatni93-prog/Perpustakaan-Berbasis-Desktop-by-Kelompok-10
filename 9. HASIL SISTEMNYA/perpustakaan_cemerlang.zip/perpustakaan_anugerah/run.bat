@echo off
cd /d "%~dp0"
title Perpustakaan Cemerlang - Desktop Library Management System
echo ============================================================
echo   MENJALANKAN PERPUSTAKAAN CEMERLANG
echo ============================================================
echo.

if exist "C:\Program Files\Java\jdk1.8.0_111\bin\java.exe" (
    "C:\Program Files\Java\jdk1.8.0_111\bin\java.exe" -jar perpustakaan-anugerah.jar
) else if exist "C:\Program Files\Java\jdk-26\bin\java.exe" (
    "C:\Program Files\Java\jdk-26\bin\java.exe" -jar perpustakaan-anugerah.jar
) else (
    java -jar perpustakaan-anugerah.jar
)

pause
