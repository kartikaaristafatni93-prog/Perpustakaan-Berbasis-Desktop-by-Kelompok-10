-- ====================================================================
-- Perpustakaan Cemerlang - Database Schema & Seed Data
-- Database: perpustakaan_anugerah
-- ====================================================================

CREATE DATABASE IF NOT EXISTS `perpustakaan_anugerah`
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `perpustakaan_anugerah`;

-- 1. Table: rak (Shelves)
CREATE TABLE IF NOT EXISTS `rak` (
    `id_rak` VARCHAR(20) NOT NULL,
    `nama_rak` VARCHAR(50) NOT NULL,
    `lokasi_rak` VARCHAR(100) NOT NULL,
    `keterangan` TEXT,
    PRIMARY KEY (`id_rak`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Table: petugas (Staff)
CREATE TABLE IF NOT EXISTS `petugas` (
    `id_petugas` VARCHAR(20) NOT NULL,
    `nama_lengkap` VARCHAR(100) NOT NULL,
    `jenis_kelamin` ENUM('Laki-laki', 'Perempuan') NOT NULL,
    `alamat` TEXT,
    `no_telepon` VARCHAR(20),
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` VARCHAR(20) NOT NULL DEFAULT 'Petugas',
    PRIMARY KEY (`id_petugas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Table: anggota (Members)
CREATE TABLE IF NOT EXISTS `anggota` (
    `id_anggota` VARCHAR(20) NOT NULL,
    `nama_lengkap` VARCHAR(100) NOT NULL,
    `jenis_kelamin` ENUM('Laki-laki', 'Perempuan') NOT NULL,
    `alamat` TEXT,
    `no_telepon` VARCHAR(20),
    `email` VARCHAR(100),
    `tanggal_daftar` DATE NOT NULL,
    PRIMARY KEY (`id_anggota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Table: users (Authentication Users)
CREATE TABLE IF NOT EXISTS `users` (
    `id_user` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` VARCHAR(20) NOT NULL DEFAULT 'Petugas',
    `id_petugas` VARCHAR(20) NULL,
    `id_anggota` VARCHAR(20) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_users_petugas` FOREIGN KEY (`id_petugas`)
        REFERENCES `petugas` (`id_petugas`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_users_anggota` FOREIGN KEY (`id_anggota`)
        REFERENCES `anggota` (`id_anggota`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Table: buku (Books)
CREATE TABLE IF NOT EXISTS `buku` (
    `id_buku` VARCHAR(20) NOT NULL,
    `isbn` VARCHAR(30) NOT NULL UNIQUE,
    `judul_buku` VARCHAR(150) NOT NULL,
    `pengarang` VARCHAR(100) NOT NULL,
    `penerbit` VARCHAR(100) NOT NULL,
    `tahun_terbit` INT NOT NULL,
    `kategori` VARCHAR(50) NOT NULL,
    `id_rak` VARCHAR(20) NOT NULL,
    `total_stok` INT NOT NULL DEFAULT 0,
    `sisa_stok` INT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id_buku`),
    CONSTRAINT `fk_buku_rak` FOREIGN KEY (`id_rak`)
        REFERENCES `rak` (`id_rak`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Table: peminjaman (Borrowing Transactions)
CREATE TABLE IF NOT EXISTS `peminjaman` (
    `id_peminjaman` VARCHAR(30) NOT NULL,
    `id_anggota` VARCHAR(20) NOT NULL,
    `id_buku` VARCHAR(20) NOT NULL,
    `id_petugas` VARCHAR(20) NOT NULL,
    `tanggal_pinjam` DATE NOT NULL,
    `tanggal_jatuh_tempo` DATE NOT NULL,
    `status_peminjaman` ENUM('Dipinjam', 'Dikembalikan') NOT NULL DEFAULT 'Dipinjam',
    PRIMARY KEY (`id_peminjaman`),
    CONSTRAINT `fk_peminjaman_anggota` FOREIGN KEY (`id_anggota`)
        REFERENCES `anggota` (`id_anggota`) ON UPDATE CASCADE,
    CONSTRAINT `fk_peminjaman_buku` FOREIGN KEY (`id_buku`)
        REFERENCES `buku` (`id_buku`) ON UPDATE CASCADE,
    CONSTRAINT `fk_peminjaman_petugas` FOREIGN KEY (`id_petugas`)
        REFERENCES `petugas` (`id_petugas`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Table: pengembalian (Return Transactions)
CREATE TABLE IF NOT EXISTS `pengembalian` (
    `id_pengembalian` VARCHAR(30) NOT NULL,
    `id_peminjaman` VARCHAR(30) NOT NULL UNIQUE,
    `tanggal_kembali` DATE NOT NULL,
    `terlambat_hari` INT NOT NULL DEFAULT 0,
    `denda` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `status_pengembalian` ENUM('Tepat Waktu', 'Terlambat') NOT NULL DEFAULT 'Tepat Waktu',
    `id_petugas` VARCHAR(20) NULL,
    PRIMARY KEY (`id_pengembalian`),
    CONSTRAINT `fk_pengembalian_peminjaman` FOREIGN KEY (`id_peminjaman`)
        REFERENCES `peminjaman` (`id_peminjaman`) ON UPDATE CASCADE,
    CONSTRAINT `fk_pengembalian_petugas` FOREIGN KEY (`id_petugas`)
        REFERENCES `petugas` (`id_petugas`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Table: pengaturan (System Settings e.g. Late Fee per day)
CREATE TABLE IF NOT EXISTS `pengaturan` (
    `kunci` VARCHAR(50) NOT NULL PRIMARY KEY,
    `nilai` VARCHAR(255) NOT NULL,
    `keterangan` VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- SEED DATA
-- ====================================================================

-- Default System Settings (Denda Rp 1.000 per hari)
INSERT INTO `pengaturan` (`kunci`, `nilai`, `keterangan`) VALUES
('denda_per_hari', '1000', 'Tarif denda keterlambatan pengembalian buku per hari (Rupiah)'),
('nama_perpustakaan', 'Perpustakaan Cemerlang', 'Nama resmi perpustakaan')
ON DUPLICATE KEY UPDATE `nilai`='Perpustakaan Cemerlang';

-- Initial Staff & Admin Accounts (password: 'admin123' & 'petugas123' hashed with SHA-256)
INSERT INTO `petugas` (`id_petugas`, `nama_lengkap`, `jenis_kelamin`, `alamat`, `no_telepon`, `username`, `password`, `role`) VALUES
('PTG-001', 'Administrator Perpustakaan', 'Laki-laki', 'Jl. Merdeka No. 10, Jakarta Pusat', '081234567890', 'admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'Admin'),
('PTG-002', 'Siti Rahmawati, S.Kom', 'Perempuan', 'Jl. Melati No. 45, Bandung', '085678901234', 'petugas', '1ee24707255f0ee8b53cfc9c7f66a6a161858a74e99f01aa6e2978051785de11', 'Petugas')
ON DUPLICATE KEY UPDATE `id_petugas`=`id_petugas`;

-- Initial Members (Anggota)
INSERT INTO `anggota` (`id_anggota`, `nama_lengkap`, `jenis_kelamin`, `alamat`, `no_telepon`, `email`, `tanggal_daftar`) VALUES
('AGT-001', 'Budi Santoso', 'Laki-laki', 'Jl. Sudirman No. 88, Jakarta Selatan', '081298765432', 'budi.santoso@email.com', '2026-01-15'),
('AGT-002', 'Dewi Lestari', 'Perempuan', 'Jl. Dago Asri No. 12, Bandung', '081345678912', 'dewi.lestari@email.com', '2026-02-10'),
('AGT-003', 'Ahmad Fadillah', 'Laki-laki', 'Jl. Kaliurang KM 5, Yogyakarta', '085712345678', 'ahmad.f@email.com', '2026-03-01'),
('AGT-004', 'Anisa Nuraini', 'Perempuan', 'Jl. Pahlawan No. 23, Surabaya', '081987654321', 'anisa.nur@email.com', '2026-04-18')
ON DUPLICATE KEY UPDATE `id_anggota`=`id_anggota`;

-- Users for Admin, Petugas, and Sample Member (user1 / user123)
-- user123 SHA-256: 0b63e8006b026601ea0ea9b253965582ff04c10c1f54cfdf1534ea9f2a7db6bc
INSERT INTO `users` (`username`, `password`, `role`, `id_petugas`, `id_anggota`) VALUES
('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'Admin', 'PTG-001', NULL),
('petugas', '1ee24707255f0ee8b53cfc9c7f66a6a161858a74e99f01aa6e2978051785de11', 'Petugas', 'PTG-002', NULL),
('budi', '0b63e8006b026601ea0ea9b253965582ff04c10c1f54cfdf1534ea9f2a7db6bc', 'PENGGUNA', NULL, 'AGT-001')
ON DUPLICATE KEY UPDATE `username`=`username`;

-- Initial Shelves (Rak)
INSERT INTO `rak` (`id_rak`, `nama_rak`, `lokasi_rak`, `keterangan`) VALUES
('RAK-001', 'Rak Pemrograman & TI', 'Lantai 1 - Sayap Kiri', 'Buku-buku seputar rekayasa perangkat lunak, web, dan database'),
('RAK-002', 'Rak Sains & Matematika', 'Lantai 1 - Sayap Kanan', 'Buku fisika, kimia, biologi, kalkulus, dan statistika'),
('RAK-003', 'Rak Sastra & Fiksi', 'Lantai 2 - Ruang 201', 'Novel, antologi puisi, cerita pendek, dan drama'),
('RAK-004', 'Rak Ekonomi & Bisnis', 'Lantai 2 - Ruang 204', 'Manajemen, akuntansi, pemasaran, dan kewirausahaan')
ON DUPLICATE KEY UPDATE `id_rak`=`id_rak`;

-- Initial Books (Buku)
INSERT INTO `buku` (`id_buku`, `isbn`, `judul_buku`, `pengarang`, `penerbit`, `tahun_terbit`, `kategori`, `id_rak`, `total_stok`, `sisa_stok`) VALUES
('BK-001', '978-602-04-9876-1', 'Pemrograman Java Fundamental hingga Lanjut', 'Dr. Eng. Rinaldi Munir', 'Informatika Bandung', 2023, 'Teknologi Informasi', 'RAK-001', 10, 8),
('BK-002', '978-602-29-1234-5', 'Basis Data Relasional & MySQL Mastery', 'Fathansyah, Ir.', 'Informatika', 2022, 'Teknologi Informasi', 'RAK-001', 8, 7),
('BK-003', '978-979-30-5678-9', 'Kalkulus Lanjut dan Aplikasinya', 'Dale Varberg & Edwin Purcell', 'Erlangga', 2021, 'Sains & Matematika', 'RAK-002', 12, 12),
('BK-004', '978-602-03-2476-0', 'Bumi Manusia', 'Pramoedya Ananta Toer', 'Lentera Dipantara', 2020, 'Sastra & Fiksi', 'RAK-003', 15, 14),
('BK-005', '978-602-06-3123-4', 'Filosofi Teras: Stoisisme Kehidupan Modern', 'Henry Manampiring', 'Kompas Gramedia', 2023, 'Filsafat & Pengembangan Diri', 'RAK-003', 10, 10),
('BK-006', '978-979-06-1789-2', 'Manajemen Keuangan Perusahaan Teori & Praktik', 'Prof. Dr. Eduardus Tandelilin', 'Salemba Empat', 2022, 'Ekonomi & Bisnis', 'RAK-004', 6, 6)
ON DUPLICATE KEY UPDATE `id_buku`=`id_buku`;

-- Initial Borrowing Transactions (Peminjaman)
INSERT INTO `peminjaman` (`id_peminjaman`, `id_anggota`, `id_buku`, `id_petugas`, `tanggal_pinjam`, `tanggal_jatuh_tempo`, `status_peminjaman`) VALUES
('PJM-20261025-0001', 'AGT-001', 'BK-001', 'PTG-001', '2026-10-25', '2026-11-01', 'Dikembalikan'),
('PJM-20261028-0002', 'AGT-002', 'BK-002', 'PTG-002', '2026-10-28', '2026-11-04', 'Dikembalikan'),
('PJM-20261101-0003', 'AGT-003', 'BK-001', 'PTG-001', '2026-11-01', '2026-11-08', 'Dipinjam'),
('PJM-20261103-0004', 'AGT-004', 'BK-004', 'PTG-002', '2026-11-03', '2026-11-10', 'Dipinjam'),
('PJM-20261105-0005', 'AGT-001', 'BK-002', 'PTG-001', '2026-11-05', '2026-11-12', 'Dipinjam')
ON DUPLICATE KEY UPDATE `id_peminjaman`=`id_peminjaman`;

-- Initial Return Transactions (Pengembalian)
INSERT INTO `pengembalian` (`id_pengembalian`, `id_peminjaman`, `tanggal_kembali`, `terlambat_hari`, `denda`, `status_pengembalian`, `id_petugas`) VALUES
('KBL-20261102-0001', 'PJM-20261025-0001', '2026-11-02', 1, 1000.00, 'Terlambat', 'PTG-001'),
('KBL-20261104-0002', 'PJM-20261028-0002', '2026-11-04', 0, 0.00, 'Tepat Waktu', 'PTG-002')
ON DUPLICATE KEY UPDATE `id_pengembalian`=`id_pengembalian`;
