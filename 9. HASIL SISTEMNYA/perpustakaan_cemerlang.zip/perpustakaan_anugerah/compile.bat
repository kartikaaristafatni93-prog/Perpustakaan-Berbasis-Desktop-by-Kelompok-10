@echo off
cd /d "%~dp0"

echo [1/4] Menyiapkan direktori output target/classes dan build/classes...
if exist "target\classes" rmdir /s /q "target\classes"
if exist "build\classes" rmdir /s /q "build\classes"
mkdir "target\classes"
mkdir "build\classes"

echo [2/4] Melakukan kompilasi seluruh source code dengan JDK 8...
set "CP=lib\*"
"C:\Program Files\Java\jdk1.8.0_111\bin\javac.exe" -encoding UTF-8 -cp "%CP%" -d target\classes src\main\java\com\perpustakaan\*.java src\main\java\com\perpustakaan\config\*.java src\main\java\com\perpustakaan\model\*.java src\main\java\com\perpustakaan\dao\*.java src\main\java\com\perpustakaan\utils\*.java src\main\java\com\perpustakaan\view\*.java src\main\java\com\perpustakaan\view\components\*.java src\main\java\com\perpustakaan\view\panels\*.java

if %ERRORLEVEL% neq 0 (
    echo Gagal melakukan kompilasi! Silakan periksa error di atas.
    pause
    exit /b %ERRORLEVEL%
)

echo [3/4] Menyalin resources dan menyinkronkan build/classes untuk NetBeans...
copy /Y src\main\resources\* target\classes\ >nul 2>&1
xcopy /E /I /Y target\classes\* build\classes\ >nul 2>&1

echo [4/4] Membangun file JAR perpustakaan-anugerah.jar...
"C:\Program Files\Java\jdk1.8.0_111\bin\jar.exe" -cfm perpustakaan-anugerah.jar manifest.txt -C target\classes .
if not exist "dist" mkdir "dist"
copy /Y perpustakaan-anugerah.jar dist\ >nul 2>&1
copy /Y perpustakaan-anugerah.jar target\ >nul 2>&1

echo.
echo =========================================================================
echo   SUKSES: Seluruh pembaruan UI/UX, Anggota, Register, dan Struk telah
echo   berhasil dikompilasi ke target\classes, build\classes, dan JAR!
echo =========================================================================
